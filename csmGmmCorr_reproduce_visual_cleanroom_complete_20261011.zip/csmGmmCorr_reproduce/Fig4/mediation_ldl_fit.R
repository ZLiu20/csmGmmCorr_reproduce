args <- commandArgs(trailingOnly = TRUE)
index <- if (length(args)) as.integer(args[[1L]]) else as.integer(Sys.getenv("LSB_JOBINDEX", "1"))
source(file.path("SupportingCode", "load_all.R"))
load_kernels()
if (index < 1L || index > nrow(MEDLDL_JOBS)) stop("Mediation array index is outside the job table.", call. = FALSE)
job <- MEDLDL_JOBS[index]
run_mediation_ldl(job$set, job$variant, job$a_mu)
