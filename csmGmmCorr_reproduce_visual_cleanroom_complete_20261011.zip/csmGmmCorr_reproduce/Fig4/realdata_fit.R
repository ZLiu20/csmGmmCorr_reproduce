args <- commandArgs(trailingOnly = TRUE)
index <- if (length(args)) as.integer(args[[1L]]) else as.integer(Sys.getenv("LSB_JOBINDEX", "1"))
source(file.path("SupportingCode", "load_all.R"))
load_kernels()
if (index < 1L || index > nrow(RD_JOBS)) stop("Real-data array index is outside 1:13.", call. = FALSE)
job <- RD_JOBS[index, ]
run_realdata(job$analysis, job$variant, a_mu = job$a_mu)
