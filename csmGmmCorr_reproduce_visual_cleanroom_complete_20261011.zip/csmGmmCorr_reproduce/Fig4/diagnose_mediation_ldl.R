suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
root <- file.path("Fig4", "output", "mediation_ldl")
input <- file.path("Data", "mediation", "mediation_ldl_liver_noshare.tsv.gz")
data <- freadgz(input)
z <- as.matrix(data[, ..MEDLDL_COLS])
diagnostic <- rbindlist(list(
  data.table(quantity = "features", value = nrow(data)),
  data.table(quantity = "complete_features", value = sum(complete.cases(z))),
  data.table(quantity = "unique_gene_triplets", value = uniqueN(data[, .(gene1, gene2, gene3)])),
  data.table(quantity = "shared_model_features", value = sum(data$shared %in% TRUE, na.rm = TRUE)),
  data.table(quantity = paste0("iqr_sd_", MEDLDL_COLS), value = apply(z, 2, function(x) IQR(x, na.rm = TRUE) / 1.349))
))
dir.create(root, recursive = TRUE, showWarnings = FALSE)
fwrite(diagnostic, file.path(root, "diagnostic.tsv"), sep = "\t")
print(diagnostic)
