suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
collected <- rd_collect()
summary <- collected$summary
if (!nrow(summary)) stop("No real-data summaries found.", call. = FALSE)
fwrite(summary, file.path("Fig4", "Tab3.csv"))
lines <- c("\\begin{table}[!htbp]", "\\centering", "\\caption{Genome-wide application results.}", "\\label{tab:realdata}",
  "\\begin{tabular}{lllrrrr}", "\\toprule", "Analysis & Variant & $t$ & Raw discoveries & Adjusted discoveries & Raw loci & Adjusted loci\\\\", "\\midrule")
for (i in seq_len(nrow(summary))) lines <- c(lines, sprintf("%s & %s & %d & %s & %s & %s & %s\\\\",
  tex_escape(summary$analysis[i]), tex_escape(summary$variant[i]), summary$t[i], fcomma(summary$R_raw[i]),
  fcomma(summary$R_adj[i]), fcomma(summary$loci_raw[i]), fcomma(summary$loci_adj[i])))
write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("Fig4", "Tab3.tex"))
