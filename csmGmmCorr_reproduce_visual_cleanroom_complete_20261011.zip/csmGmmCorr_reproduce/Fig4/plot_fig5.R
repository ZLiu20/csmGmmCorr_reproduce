suppressPackageStartupMessages({library(data.table); library(ggplot2); library(cowplot)})
source(file.path("SupportingCode", "load_all.R"))

read_discoveries <- function(directory, threshold) {
  path <- file.path(directory, sprintf("discoveries_t%d.tsv.gz", threshold))
  if (!file.exists(path)) return(NULL)
  value <- freadgz(path)
  value[, analysis := basename(directory)]
  value[, t := threshold]
  value
}
directories <- rd_fit_dirs()
directories <- directories[grepl("_(main|main_amu15)$", directories)]
replication <- rbindlist(lapply(directories[grepl("glgc_replication", directories)], read_discoveries, threshold = 1L), fill = TRUE)
pleiotropy <- rbindlist(lapply(directories[grepl("pleiotropy", directories)], function(d) {
  rbindlist(list(read_discoveries(d, 1L), read_discoveries(d, 2L)), fill = TRUE)
}), fill = TRUE)

manhattan_panel <- function(data, title) {
  if (!nrow(data)) return(ggplot() + labs(title = title) + theme_void())
  data[, chr_numeric := as.integer(chr)]
  offsets <- data[, .(maximum = max(pos, na.rm = TRUE)), by = chr_numeric][order(chr_numeric)]
  offsets[, start := c(0, cumsum(head(maximum, -1L)))]
  data <- merge(data, offsets[, .(chr_numeric, start)], by = "chr_numeric")
  data[, genome := pos + start]
  ggplot(data, aes(genome, -log10(pmax(lfdr, 1e-12)), color = factor(chr_numeric %% 2L))) +
    geom_point(alpha = 0.75, size = 1.3) + facet_wrap(~t, scales = "free_y") +
    scale_color_manual(values = c("#2F4858", "#D95F59"), guide = "none") +
    labs(title = title, x = "Genomic position", y = expression(-log[10](lfdr))) + theme_paper(12)
}
p1 <- manhattan_panel(replication, "Replication discoveries")
p2 <- manhattan_panel(pleiotropy, "Pleiotropy discoveries")
figure <- plot_grid(p1, p2, labels = c("A", "B"), ncol = 1L)
ggsave(file.path("Fig4", "Fig5.pdf"), figure, device = PDF_DEVICE, width = 16, height = 11.5)
