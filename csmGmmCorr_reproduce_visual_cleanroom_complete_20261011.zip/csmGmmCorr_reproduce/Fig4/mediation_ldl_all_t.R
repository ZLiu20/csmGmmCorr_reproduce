suppressPackageStartupMessages(library(data.table))
args <- commandArgs(trailingOnly = TRUE)
index <- if (length(args)) as.integer(args[[1L]]) else as.integer(Sys.getenv("LSB_JOBINDEX", "1"))
source(file.path("SupportingCode", "load_all.R"))
load_kernels()

directories <- list.dirs(file.path("Fig4", "output", "mediation_ldl"), recursive = FALSE, full.names = TRUE)
directories <- directories[file.exists(file.path(directories, "fit.rds"))]
tasks <- expand.grid(directory = directories, t = 1:5, stringsAsFactors = FALSE)
if (index < 1L || index > nrow(tasks)) quit(save = "no")
task <- tasks[index, ]
fit <- readRDS(file.path(task$directory, "fit.rds"))
set_name <- sub("_(main|indep|robust).*$", "", basename(task$directory))
source_set <- sub("_dedup$", "", set_name)
input <- file.path("Data", "mediation", sprintf("mediation_ldl_liver_%s.tsv.gz", source_set))
data <- freadgz(input)
if (grepl("_dedup$", set_name)) data <- medldl_dedup(data)
data <- data[complete.cases(data[, ..MEDLDL_COLS])]
z <- capz(as.matrix(data[, ..MEDLDL_COLS]), 12)
lfdr <- .csm_function("csm_lfdr")(fit, z, "mediation", task$t, cores = as.integer(Sys.getenv("LSB_DJOB_NUMPROC", "4")))
step <- .stepup_parts(.csm_function("csm_stepup")(lfdr, 0.1), nrow(z))
row <- data.table(variant = basename(task$directory), t = task$t, n = nrow(z), R_raw = step$n_rejected,
                  loci_raw = clump(data$chr, data$pos_b38, lfdr, step$rejected),
                  all_alpha_lt2 = sum(step$rejected & apply(abs(z[, c(1,3,5), drop = FALSE]), 1, max) < 2))
output <- file.path(task$directory, sprintf("all_t_t%d.tsv", task$t))
fwrite(row, output, sep = "\t")
