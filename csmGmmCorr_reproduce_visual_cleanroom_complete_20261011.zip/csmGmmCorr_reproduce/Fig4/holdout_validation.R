suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
root <- file.path("Fig4", "output")
main_dir <- file.path(root, "glgc_replication_main")
discoveries <- file.path(main_dir, "discoveries_t1.tsv.gz")
prepared <- file.path("Data", "prepared", "glgc_replication")
if (!file.exists(discoveries)) stop("Replication discoveries are unavailable.", call. = FALSE)
selected <- freadgz(discoveries)
manifest <- fread(file.path(prepared, "chromosome_manifest.tsv"))
holdout <- rbindlist(lapply(manifest$path, function(path) {
  freadgz(file.path(prepared, basename(path)), select = c("variant_id", "HIS_female", "HIS_male", "SAS_female", "SAS_male"))
}), fill = TRUE)
joined <- merge(selected[, .(variant_id, rej_raw, rej_adj)], holdout, by = "variant_id", all.x = TRUE)
zcols <- c("HIS_female", "HIS_male", "SAS_female", "SAS_male")
z <- as.matrix(joined[, ..zcols])
joined[, holdout_same_direction := apply(z, 1, function(x) all(x > 0) || all(x < 0))]
joined[, holdout_all_nominal := apply(abs(z), 1, function(x) all(x >= qnorm(.975)))]
summary <- joined[, .(n = .N, same_direction = mean(holdout_same_direction, na.rm = TRUE),
                       all_nominal = mean(holdout_all_nominal, na.rm = TRUE)), by = .(rej_raw, rej_adj)]
fwrite(joined, file.path(root, "replication_holdout_variants.tsv.gz"), sep = "\t")
fwrite(summary, file.path(root, "replication_holdout_summary.tsv"), sep = "\t")
