suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))

input <- file.path("Data", "mediation", "mediation_ldl_liver_noshare.tsv.gz")
if (!file.exists(input)) stop("Prepared mediation LDL data are missing.", call. = FALSE)
data <- freadgz(input)
data <- data[complete.cases(data[, ..MEDLDL_COLS])]
z <- capz(as.matrix(data[, ..MEDLDL_COLS]), 12)
q <- 0.1
methods <- list(
  DEI = run_dei_mediation_R1,
  MediationTest = run_mediation_test_R1,
  PCPathSafeguard = run_mediation_safeguard_R1
)

summary_rows <- list()
discovery_rows <- list()
for (threshold in 1:2) {
  for (label in names(methods)) {
    result <- tryCatch(methods[[label]](z, threshold, q), error = identity)
    if (inherits(result, "error")) {
      summary_rows[[length(summary_rows) + 1L]] <- data.table(
        method = label, t = threshold, discoveries = NA_integer_, loci = NA_integer_, error = conditionMessage(result)
      )
      next
    }
    rejected <- as.logical(result$rejected)
    score <- as.numeric(result$score)
    summary_rows[[length(summary_rows) + 1L]] <- data.table(
      method = label, t = threshold, discoveries = sum(rejected),
      loci = clump(data$chr, data$pos_b38, score, rejected), error = ""
    )
    if (any(rejected)) {
      discovery_rows[[length(discovery_rows) + 1L]] <- cbind(
        data.table(method = label, t = threshold), data[rejected],
        data.table(score = score[rejected])
      )
    }
  }
}
output <- file.path("Fig4", "output", "mediation_ldl")
dir.create(output, recursive = TRUE, showWarnings = FALSE)
fwrite(rbindlist(summary_rows, fill = TRUE), file.path(output, "comparison_summary.tsv"), sep = "\t")
if (length(discovery_rows)) fwrite(rbindlist(discovery_rows, fill = TRUE), file.path(output, "comparison_discoveries.tsv.gz"), sep = "\t")
writeLines("DONE", file.path(output, "COMPARISON_DONE"))
