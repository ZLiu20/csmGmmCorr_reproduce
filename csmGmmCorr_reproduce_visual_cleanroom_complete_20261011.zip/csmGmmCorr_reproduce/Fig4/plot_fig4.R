suppressPackageStartupMessages({library(data.table); library(ggplot2); library(cowplot)})
source(file.path("SupportingCode", "load_all.R"))
collected <- rd_collect()
summary <- collected$summary
sigma <- collected$sigma
if (!nrow(summary)) stop("No application summaries found.", call. = FALSE)

labels <- c(glgc_replication = "Replication: GLGC", ukb_pleiotropy = "Pleiotropy: UK Biobank",
            glgc_pleiotropy = "Pleiotropy: GLGC")
summary[, Analysis := labels[analysis]]
summary[, Method := fifelse(grepl("indep", variant), "Independent", fifelse(grepl("robust", variant), "Robust plug-in", "Estimated correlation"))]
long <- melt(summary, id.vars = c("Analysis", "Method", "t"),
             measure.vars = c("R_raw", "R_adj"), variable.name = "score", value.name = "discoveries")
long[, score := factor(score, levels = c("R_raw", "R_adj"), labels = c("Raw", "Majorant"))]
p1 <- ggplot(long, aes(Method, discoveries, fill = score)) + geom_col(position = "dodge") +
  facet_grid(Analysis ~ t, scales = "free_y") + scale_y_continuous(labels = scales::comma) +
  labs(x = NULL, y = "Discoveries", fill = "Score") + theme_paper(13) +
  theme(axis.text.x = element_text(angle = 25, hjust = 1))

chosen_sigma <- sigma[variant == "main" & what %in% c("fitted_Sigma", "pearson_abs_lt2")]
p2 <- ggplot(chosen_sigma, aes(value, fill = what)) + geom_histogram(position = "identity", alpha = 0.55, bins = 18) +
  facet_wrap(~analysis, scales = "free_y") +
  labs(x = "Off-diagonal correlation", y = "Pairs", fill = "Matrix") + theme_paper(13)

figure <- plot_grid(p1, p2, labels = c("A", "B"), ncol = 1L, rel_heights = c(1.4, 1))
ggsave(file.path("Fig4", "Fig4.pdf"), figure, device = PDF_DEVICE, width = 14, height = 13)
