suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))

stopifnot(identical(glgc_chrom_rank(c("chr1", "22", "X")), c(1L, 22L, 23L)))
variant_key <- function(chr, pos, ref, alt) sprintf("%s:%d:%s:%s", chr, pos, toupper(ref), toupper(alt))
key <- variant_key(c(1L, 2L), c(100L, 200L), c("a", "C"), c("G", "t"))
stopifnot(identical(key, c("1:100:A:G", "2:200:C:T")))
sample <- data.table(chr = c(1L, 1L), pos_b37 = c(100L, 100L), ref = c("A", "A"), alt = c("G", "G"),
                     beta = c(0.2, 0.2), se = c(0.1, 0.1), maf = c(0.2, 0.2), n = c(1000, 1000))
sample[, variant_id := variant_key(chr, pos_b37, ref, alt)]
deduplicated <- sample[!duplicated(variant_id)]
stopifnot(nrow(deduplicated) == 1L, abs(deduplicated$beta / deduplicated$se - 2) < 1e-12)
cat("GLGC_PREPARATION_CONTRACT_OK\n")
