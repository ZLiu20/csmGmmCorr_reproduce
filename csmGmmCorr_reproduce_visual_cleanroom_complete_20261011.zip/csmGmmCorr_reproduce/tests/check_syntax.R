r_files <- list.files(".", pattern = "[.]R$", recursive = TRUE, full.names = TRUE)
r_files <- r_files[!grepl("SupportingCode/packages/", r_files, fixed = TRUE)]
failures <- character()
for (file in r_files) {
  issue <- tryCatch({
    parse(file)
    NULL
  }, error = function(error) conditionMessage(error))
  if (!is.null(issue)) failures <- c(failures, paste(file, issue, sep = ": "))
}
if (length(failures)) cat(paste("PARSE ERROR", failures, sep = ": "), sep = "\n")
cat(length(r_files), "R files parsed;", length(failures), "with errors\n")
if (length(failures)) quit(status = 1L)
