suppressPackageStartupMessages(library(data.table))

choose_no_shared <- function(ordered_genes, model_variants, count = 3L) {
  selected <- character()
  for (gene in ordered_genes) {
    collision <- vapply(selected, function(x) length(intersect(model_variants[[gene]], model_variants[[x]])) > 0L, logical(1L))
    if (!any(collision)) selected <- c(selected, gene)
    if (length(selected) == count) return(selected)
  }
  NULL
}
models <- list(g1 = c("a", "b"), g2 = c("b", "c"), g3 = "d", g4 = "e")
stopifnot(identical(choose_no_shared(c("g1", "g2", "g3", "g4"), models), c("g1", "g3", "g4")))

combine_z <- function(beta, se) {
  precision <- 1 / se^2
  sum(beta * precision) / sqrt(sum(precision))
}
stopifnot(abs(combine_z(c(0.2, 0.1), c(0.1, 0.2)) - (20 + 2.5) / sqrt(125)) < 1e-12)

conditional_z <- function(z, lead_z, r) (z - r * lead_z) / sqrt(1 - r^2)
stopifnot(is.finite(conditional_z(3, 4, 0.2)), abs(conditional_z(3, 4, 0)) == 3)
cat("MEDIATION_PREPARATION_CONTRACT_OK\n")
