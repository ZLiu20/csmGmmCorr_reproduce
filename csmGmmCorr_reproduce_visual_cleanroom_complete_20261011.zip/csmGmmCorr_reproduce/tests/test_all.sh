#!/usr/bin/env bash
set -u
mode=${1:-local}
module load R/4.5.1 2>/dev/null || true

case "$mode" in
  local)
    Rscript tests/check_syntax.R || exit 1
    if ! compgen -G 'SupportingCode/src/reprokernels.*' >/dev/null; then
      Rscript setup.R "${CSMGMMCORR_SRC:-}" 2>&1 | tee tests/setup.log
      [[ ${PIPESTATUS[0]} -eq 0 ]] || exit 1
    fi
    mkdir -p tests/logs
    scripts=(
      Fig1/plot_fig1.R Fig2/plot_fig2.R SuppFig1/plot_suppfig1_12.R
      Tab1/make_tab1.R Fig3/plot_fig3.R Tab2/make_tab2.R
      SuppTab2/make_supptab2.R SuppTab3/make_supptab3.R SuppTab5/make_supptab5.R
      SuppTab6/make_supptab6_8.R SuppTab9/make_supptab9.R
      SuppTab10/make_supptab10_11.R SuppTab12/make_supptab12_15.R
      SuppTab16/make_supptab16_18.R Fig4/make_tab3.R Fig4/plot_fig4.R
      Fig4/plot_fig5.R Fig4/holdout_validation.R SuppTab19/make_supptab19_23.R
      SuppTab24/make_supptab24_26.R
    )
    for script in "${scripts[@]}"; do
      log="tests/logs/$(basename "$script" .R).log"
      if Rscript "$script" >"$log" 2>&1; then
        printf 'OK %s\n' "$script"
      else
        printf 'FAILED %s (see %s)\n' "$script" "$log"
        tail -n 5 "$log"
      fi
    done
    Rscript -e 'here::i_am("setup.R"); source(here::here("SupportingCode", "load_all.R")); print(sim_progress(), row.names=FALSE)' > tests/logs/progress.log 2>&1
    ;;
  submit)
    mkdir -p tests/errDir
    first_array=$(Rscript -e 'here::i_am("setup.R"); source(here::here("SupportingCode", "load_all.R")); cat(names(sim_arrays())[[1L]])')
    bsub -J 'smoke[1-1]' -q medium -n 4 -W 4:00 -M 8 \
      -R 'span[hosts=1] rusage[mem=8]' \
      -o 'tests/errDir/smoke_%I.out' -e 'tests/errDir/smoke_%I.err' <<JOB
module load R/4.5.1
export SIM_N=2000 MAX_ITER=200 SIM_MAX_REPS=1 OMP_NUM_THREADS=1
Rscript -e 'here::i_am("setup.R"); source(here::here("SupportingCode", "load_all.R")); a <- names(sim_arrays())[as.integer(Sys.getenv("LSB_JOBINDEX"))]; message("array ", a); run_sim_task(a, 1L)'
JOB
    bsub -J smoke_rd -q medium -n 8 -W 4:00 -M 32 \
      -R 'span[hosts=1] rusage[mem=32]' \
      -o tests/errDir/smoke_rd.out -e tests/errDir/smoke_rd.err <<'JOB'
module load R/4.5.1
export SMOKE=1
Rscript Fig4/realdata_fit.R 1
JOB
    ;;
  report)
    Rscript SuppTab4/make_supptab4.R > tests/logs/make_supptab4.log 2>&1
    grep -l -i 'error' tests/errDir/smoke_*.err > tests/logs/smoke_errors.txt 2>/dev/null || true
    find Fig2 Fig3 Tab2 SuppTab* -path '*/output_smoke/*' -type f | wc -l > tests/logs/smoke_count.txt
    tar czf tests/report.tar.gz tests/*.log tests/logs tests/errDir \
      Fig1/*.pdf Fig1/*.txt Fig2/*.pdf Fig3/*.pdf Fig4/*.pdf Fig4/*.tex Fig4/*.txt \
      Fig4/output/holdout_validation.csv SuppFig1/*.pdf \
      Tab1/*.tex Tab2/*.tex SuppTab*/*.tex SuppTab*/*.csv SuppTab4/output 2>/dev/null || true
    ls -lh tests/report.tar.gz
    ;;
  *)
    echo "Usage: bash tests/test_all.sh [local|submit|report]" >&2
    exit 1
    ;;
esac
