suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))

fdp <- sources_means("FDP")
power <- sources_means("power")
fwrite(fdp, file.path("Tab2", "source_fdp.csv"))
fwrite(power, file.path("Tab2", "source_power.csv"))
lines <- c(
  sources_tex(fdp, 1L, "tab:source-fdp", "Mean false discovery proportions across estimation and data-generating variants."),
  "\\clearpage",
  sources_tex(power, 1L, "tab:source-power", "Mean power across estimation and data-generating variants.")
)
write_tex(lines, file.path("Tab2", "Tab2.tex"))
