suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
d <- read_sim("SuppTab3", "main")
summary <- overall_means(d)
fwrite(summary, file.path("SuppTab3", "SuppTab3.csv"))
lines <- c("\\begin{table}[!htbp]", "\\centering", "\\caption{Sensitivity to penalty parameters.}",
           "\\begin{tabular}{lllrrrr}", "\\toprule", "Target & $K$ & Method & FDP & Max FDP & Power & Incongruity\\\\", "\\midrule")
for (i in seq_len(nrow(summary))) lines <- c(lines, sprintf("%s & %d & %s & %s & %s & %s & %.1f\\\\",
  TARGET_NAME[[summary$target[i]]], summary$K[i], tex_escape(summary$method[i]), f3(summary$FDP[i]),
  f3(summary$FDPmax[i]), f3(summary$power[i]), summary$incon_dec[i]))
write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("SuppTab3", "SuppTab3.tex"))
