suppressPackageStartupMessages({library(data.table); library(ggplot2); library(cowplot)})
source(file.path("SupportingCode", "load_all.R"))

main <- design_means(read_sim("Fig2", "main"))
methods <- list(pleiotropy = c("penalized", "QCH", "adaFilter"), replication = "penalized",
                mediation = c("penalized", "DEI", "MediationTest", "PCPathSafeguard"))
for (metric in c("FDP", "power")) {
  panels <- list()
  for (target in names(methods)) {
    chosen <- main[target == ..target & K == 4L & t == 1L]
    for (axis in c("effect", "tau1")) {
      x_label <- if (axis == "effect") EFFECT_XLAB[[target]] else expression("Signal proportion " * tau[1])
      plot <- sim_panel(chosen[axis == ..axis], metric, methods[[target]], x_label,
                        sprintf("%s (%s)", metric, TARGET_NAME[[target]]), ylim = metric == "FDP")
      if (metric == "FDP") plot <- plot + fdp_line()
      panels[[length(panels) + 1L]] <- plot
    }
  }
  figure <- combine_panels(panels, nrow = 3L, legend = 1L, rel = 0.12)
  number <- if (metric == "FDP") 1L else 2L
  ggsave(file.path("SuppFig1", sprintf("SuppFig%d.pdf", number)), figure,
         device = PDF_DEVICE, width = 14, height = 15)
}
