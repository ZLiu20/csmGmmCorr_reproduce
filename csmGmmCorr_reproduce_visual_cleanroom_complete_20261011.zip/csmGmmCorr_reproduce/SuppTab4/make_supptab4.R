suppressPackageStartupMessages(library(data.table))
files <- list.files(file.path("SuppTab4", "output"), pattern = "[.]csv$", full.names = TRUE)
if (!length(files)) stop("No floor-study results found.", call. = FALSE)
d <- rbindlist(lapply(files, fread), fill = TRUE)
summary <- d[, .(FDP = mean(FDP), power = mean(power), R = mean(R), omega2to4 = mean(omega2to4),
                 iterations = mean(iterations)), by = .(target, fit)]
fwrite(summary, file.path("SuppTab4", "SuppTab4.csv"))
lines <- c("\\begin{table}[!htbp]", "\\centering", "\\caption{Sensitivity to the support-weight floor.}",
           "\\begin{tabular}{llrrrrr}", "\\toprule", "Target & Fit & FDP & Power & $R$ & $\\sum_{s=2}^4\\omega_s$ & Iterations\\\\", "\\midrule")
for (i in seq_len(nrow(summary))) lines <- c(lines, sprintf("%s & %s & %.3f & %.3f & %.1f & %.3f & %.1f\\\\",
  summary$target[i], tex_escape(summary$fit[i]), summary$FDP[i], summary$power[i], summary$R[i], summary$omega2to4[i], summary$iterations[i]))
writeLines(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("SuppTab4", "SuppTab4.tex"))
