suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
d <- read_sim("Fig2", "main")
specifications <- list(
  list(number=19L, value="fit_min", caption="Mean fitting time in minutes."),
  list(number=20L, value="generation_min", caption="Mean data-generation time in minutes."),
  list(number=21L, value="iterations", caption="Mean iteration count."),
  list(number=22L, value="sigma_min_eig", caption="Mean minimum eigenvalue of the fitted correlation matrix."),
  list(number=23L, value="converged", caption="Proportion of converged fits.")
)
for (specification in specifications) {
  field <- specification$value
  if (!field %in% names(d)) d[, (field) := NA_real_]
  z <- d[, .(value = mean(as.numeric(get(field)), na.rm = TRUE)), by = .(target, K, t, method)]
  fwrite(z, file.path("SuppTab19", sprintf("SuppTab%d.csv", specification$number)))
  lines <- c("\\begin{table}[!htbp]", "\\centering", sprintf("\\caption{%s}", specification$caption),
    "\\begin{tabular}{rrllr}", "\\toprule", "$K$ & $t$ & Target & Method & Value\\\\", "\\midrule")
  for (i in seq_len(nrow(z))) lines <- c(lines, sprintf("%d & %d & %s & %s & %.3f\\\\",
    z$K[i], z$t[i], TARGET_NAME[[z$target[i]]], tex_escape(z$method[i]), z$value[i]))
  write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"),
            file.path("SuppTab19", sprintf("SuppTab%d.tex", specification$number)))
}
