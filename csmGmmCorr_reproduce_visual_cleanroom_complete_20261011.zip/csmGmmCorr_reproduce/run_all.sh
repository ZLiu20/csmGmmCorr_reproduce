#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"
mkdir -p logs

queue=${QUEUE:-medium}
mode=${1:-all}
dry_run=${DRYRUN:-0}
active_names=()

stamp() {
  printf '[%s] %s\n' "$(date '+%F %T')" "$*"
}

lsf_name() {
  awk '/^#BSUB[[:space:]]+-J[[:space:]]+/ {print $3; exit}' "$1" | sed 's/\[.*$//'
}

queued() {
  local name=$1
  bjobs -a -J "$name" 2>/dev/null | awk 'NR > 1 && $3 ~ /^(RUN|PEND|PSUSP|USUSP|SSUSP)$/ {found=1} END {exit !found}'
}

submit_lsf() {
  local file=$1
  local dependency=${2:-}
  local name
  name=$(lsf_name "$file")
  if queued "$name"; then
    stamp "queued already: $name"
    active_names+=("$name")
    return 0
  fi
  if [[ "$dry_run" == 1 ]]; then
    stamp "dry run: bsub ${dependency:+-w $dependency }< $file"
  elif [[ -n "$dependency" ]]; then
    bsub -w "$dependency" < "$file"
  else
    bsub < "$file"
  fi
  active_names+=("$name")
}

simulation_files() {
  local patterns=(
    'Fig2/run_*.lsf' 'Fig3/run_*.lsf' 'Tab2/run_*.lsf'
    'SuppTab3/run_*.lsf' 'SuppTab4/run_*.lsf' 'SuppTab9/run_*.lsf'
    'SuppTab12/run_*.lsf'
  )
  local pattern file
  shopt -s nullglob
  for pattern in "${patterns[@]}"; do
    for file in $pattern; do printf '%s\n' "$file"; done
  done
  shopt -u nullglob
}

completed_arrays() {
  Rscript -e '
    here::i_am("run_all.sh")
    source(here::here("SupportingCode", "load_all.R"))
    p <- sim_progress()
    cat(paste(p$array[p$found >= p$expected], collapse="\n"))
  ' 2>/dev/null
}

application_markers() {
  local prepared realdata mediation
  prepared=$(find Data/prepared -mindepth 2 -maxdepth 2 -name DONE 2>/dev/null | wc -l | tr -d ' ')
  realdata=$(find Fig4/output -mindepth 2 -maxdepth 2 -name DONE 2>/dev/null | wc -l | tr -d ' ')
  mediation=$(find Fig4/output/mediation_ldl -name DONE 2>/dev/null | wc -l | tr -d ' ')
  printf '%s %s %s\n' "$prepared" "$realdata" "$mediation"
}

submit_final() {
  local conditions=()
  local name
  for name in "${active_names[@]}"; do conditions+=("ended($name)"); done
  local wait_for=''
  if ((${#conditions[@]})); then
    wait_for=$(IFS=' && '; echo "${conditions[*]}")
  fi
  if queued final_make; then
    stamp "queued already: final_make"
    return 0
  fi
  if [[ "$dry_run" == 1 ]]; then
    stamp "dry run: submit final_make${wait_for:+ after $wait_for}"
    return 0
  fi
  local dependency=()
  [[ -z "$wait_for" ]] || dependency=(-w "$wait_for")
  bsub -J final_make -q "$queue" -n 4 -W 12:00 -M 64 \
    -R 'span[hosts=1] rusage[mem=64]' \
    -o logs/final_make.out -e logs/final_make.err "${dependency[@]}" <<'JOB'
module load R/4.5.1 >/dev/null 2>&1
bash make_all.sh
find Data/raw -type f \( -name '*.gz' -o -name '*.bgz' -o -name '*.db' -o -name '*.gtf' \) -print0 2>/dev/null | sort -z | xargs -0 md5sum > logs/raw_md5.txt
JOB
}

status_report() {
  Rscript -e '
    here::i_am("run_all.sh")
    source(here::here("SupportingCode", "load_all.R"))
    print(sim_progress(), row.names=FALSE)
  '
  bjobs -w 2>/dev/null | awk 'NR == 1 || /final_make|prepare|realdata|medldl|RUN|PEND|SUSP/'
  read -r prepared realdata mediation < <(application_markers)
  printf 'application markers: prepared %s/3; real-data %s/13; mediation %s/23\n' \
    "$prepared" "$realdata" "$mediation"
}

case "$mode" in
  status)
    status_report
    ;;
  make)
    bash make_all.sh
    ;;
  final)
    submit_final
    ;;
  all)
    stamp '1. setup'
    if [[ ! -f logs/versions.txt ]] || ! compgen -G 'SupportingCode/src/reprokernels.*' >/dev/null; then
      Rscript setup.R > logs/setup.log 2>&1 || {
        tail -n 20 logs/setup.log
        exit 1
      }
    fi
    tail -n 12 logs/versions.txt

    stamp '2. simulation arrays'
    done_arrays="$(completed_arrays || true)"
    while IFS= read -r file; do
      [[ -n "$file" ]] || continue
      name=$(lsf_name "$file")
      if grep -qxF "$name" <<<"$done_arrays"; then
        stamp "complete: $name"
      else
        submit_lsf "$file"
      fi
    done < <(simulation_files)

    stamp '3. downloads'
    prepared_count=$(find Data/prepared -mindepth 2 -maxdepth 2 -name DONE 2>/dev/null | wc -l | tr -d ' ')
    if [[ "$prepared_count" -lt 3 ]]; then
      if [[ "${SKIP_DOWNLOAD:-0}" == 1 ]]; then
        stamp 'downloads skipped by SKIP_DOWNLOAD=1'
      elif [[ "$dry_run" == 1 ]]; then
        stamp 'dry run: Data/download_data.sh, Data/download_mediation_ldl.sh, Data/download_1000g.sh'
      else
        mkdir -p Data/raw/glgc
        bash Data/download_data.sh > logs/download_data.log 2>&1 & p1=$!
        bash Data/download_mediation_ldl.sh > logs/download_mediation_ldl.log 2>&1 & p2=$!
        bash Data/download_1000g.sh > logs/download_1000g.log 2>&1 & p3=$!
        download_failed=0
        for pid in "$p1" "$p2" "$p3"; do wait "$pid" || download_failed=1; done
        [[ "$download_failed" == 0 ]] || {
          stamp 'at least one download failed; rerun to resume'
          exit 1
        }
      fi
    else
      stamp 'downloads already prepared'
    fi

    stamp '4. preparation and applications'
    app_files=(
      Fig4/run_realdata.lsf
      Data/run_prepare_mediation_ldl.lsf
      Data/run_prepare_mediation_ldl_cond.lsf
      Fig4/run_mediation_ldl.lsf
      Fig4/run_mediation_ldl_compare.lsf
    )
    for file in "${app_files[@]}"; do
      [[ -f "$file" ]] && submit_lsf "$file"
    done

    stamp '5. final products'
    submit_final
    ;;
  *)
    echo 'Usage: bash run_all.sh [all|status|final|make]' >&2
    exit 1
    ;;
esac
