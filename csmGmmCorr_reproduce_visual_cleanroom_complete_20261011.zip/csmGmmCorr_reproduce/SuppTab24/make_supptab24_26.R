suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
input <- file.path("Fig4", "output", "mediation_ldl", "summary.csv")
if (!file.exists(input)) stop("Run Fig4/summarize_mediation_ldl.R first.", call. = FALSE)
d <- fread(input)
groups <- list(
  `24` = c("method", "t", "discoveries"),
  `25` = c("method", "t", "incongruity"),
  `26` = intersect(c("method", "t", "overlap", "holdout"), names(d))
)
for (number in names(groups)) {
  columns <- groups[[number]]
  columns <- columns[columns %in% names(d)]
  z <- unique(d[, ..columns])
  fwrite(z, file.path("SuppTab24", sprintf("SuppTab%s.csv", number)))
  header <- paste(tex_escape(names(z)), collapse = " & ")
  lines <- c("\\begin{table}[!htbp]", "\\centering", sprintf("\\caption{Mediation LDL application summary, part %s.}", number),
             sprintf("\\begin{tabular}{%s}", paste(rep("l", ncol(z)), collapse = "")), "\\toprule", paste0(header, "\\\\"), "\\midrule")
  for (i in seq_len(nrow(z))) lines <- c(lines, paste0(paste(tex_escape(as.character(unlist(z[i]))), collapse = " & "), "\\\\"))
  write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("SuppTab24", sprintf("SuppTab%s.tex", number)))
}
