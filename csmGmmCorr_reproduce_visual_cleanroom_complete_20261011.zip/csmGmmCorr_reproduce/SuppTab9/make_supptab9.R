suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
d <- read_sim("SuppTab9", "main")
summary <- overall_means(d)
fwrite(summary, file.path("SuppTab9", "SuppTab9.csv"))
lines <- c("\\begin{table}[!htbp]", "\\centering", "\\caption{Sensitivity to magnitude-mixture structure.}",
           "\\begin{tabular}{lllrrrr}", "\\toprule", "Target & $K$ & Structure & FDP & Max FDP & Power & Incongruity\\\\", "\\midrule")
for (i in seq_len(nrow(summary))) lines <- c(lines, sprintf("%s & %d & %s & %.3f & %.3f & %.3f & %.1f\\\\",
  TARGET_NAME[[summary$target[i]]], summary$K[i], tex_escape(summary$method[i]), summary$FDP[i],
  summary$FDPmax[i], summary$power[i], summary$incon_dec[i]))
write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("SuppTab9", "SuppTab9.tex"))
