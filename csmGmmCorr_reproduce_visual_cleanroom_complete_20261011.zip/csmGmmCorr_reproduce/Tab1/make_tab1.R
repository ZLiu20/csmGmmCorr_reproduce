suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))

summary <- design_means(read_sim("Fig2", "main"))
fwrite(summary, file.path("Tab1", "table1_design_means.csv"))
methods <- list(
  pleiotropy = list(c("penalized", "Correlated csmGmm"), c("QCH", "QCH"), c("adaFilter", "adaFilter")),
  replication = list(c("penalized", "Correlated csmGmm")),
  mediation = list(c("penalized", "Correlated csmGmm"), c("DEI", "DEI"),
                   c("MediationTest", "MediationTest"), c("PCPathSafeguard", "PC path safeguard"))
)
lines <- c("\\begin{table}[!htbp]", "\\centering", "\\caption{Simulation results averaged over the twelve main designs.}",
           "\\label{tab:simulation-overview}", "\\small")
for (target in names(methods)) {
  lines <- c(lines, "\\begin{tabular}{llrrrrrr}", "\\toprule",
             sprintf("\\multicolumn{8}{c}{%s}\\\\", TARGET_NAME[[target]]),
             "Method & $K$ & $t$ & FDP & Max FDP & Power & $R$ & Incongruity\\\\", "\\midrule")
  for (entry in methods[[target]]) {
    rows <- summary[target == ..target & method == entry[[1L]],
                    .(FDP = mean(FDP), FDPmax = max(FDP), power = mean(power), R = mean(R), incon = mean(incon_dec)),
                    by = .(K, t)]
    for (i in seq_len(nrow(rows))) {
      lines <- c(lines, sprintf("%s & %d & %d & %s & %s & %s & %.1f & %.1f\\\\",
        entry[[2L]], rows$K[i], rows$t[i], f3(rows$FDP[i]), f3(rows$FDPmax[i]),
        f3(rows$power[i]), rows$R[i], rows$incon[i]))
    }
  }
  lines <- c(lines, "\\bottomrule", "\\end{tabular}", "\\par\\medskip")
}
write_tex(c(lines, "\\end{table}"), file.path("Tab1", "Tab1.tex"))
