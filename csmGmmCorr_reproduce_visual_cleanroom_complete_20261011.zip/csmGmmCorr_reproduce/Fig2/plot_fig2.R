suppressPackageStartupMessages({library(data.table); library(ggplot2); library(cowplot)})
source(file.path("SupportingCode", "load_all.R"))

main <- design_means(read_sim("Fig2", "main"))
symmetric <- design_means(read_sim("Fig2", "sym"))
fwrite(main, file.path("Fig2", "output", "design_main.csv"))
fwrite(symmetric, file.path("Fig2", "output", "design_sym.csv"))
methods <- list(
  pleiotropy = c("penalized", "QCH", "adaFilter"),
  replication = "penalized",
  mediation = c("penalized", "DEI", "MediationTest", "PCPathSafeguard")
)
panels <- list()
for (target in names(methods)) {
  selected <- main[target == ..target & K == 6L & t == 1L]
  sym <- symmetric[target == ..target & K == 6L & t == 1L & method == "penalized"]
  for (axis in c("effect", "tau1")) {
    x_label <- if (axis == "effect") EFFECT_XLAB[[target]] else expression("Signal proportion " * tau[1])
    panels[[length(panels) + 1L]] <- sim_panel(
      selected[axis == ..axis], "FDP", methods[[target]], x_label,
      sprintf("FDP (%s)", TARGET_NAME[[target]]), ylim = TRUE,
      sym = sym[axis == ..axis]
    ) + fdp_line()
  }
  for (axis in c("effect", "tau1")) {
    x_label <- if (axis == "effect") EFFECT_XLAB[[target]] else expression("Signal proportion " * tau[1])
    panels[[length(panels) + 1L]] <- sim_panel(
      selected[axis == ..axis], "power", methods[[target]], x_label,
      sprintf("Power (%s)", TARGET_NAME[[target]]), sym = sym[axis == ..axis]
    )
  }
}
figure <- combine_panels(panels, nrow = 3L, legend = 1L, rel = 0.1, ncol_legend = 4L)
ggsave(file.path("Fig2", "Fig2.pdf"), figure, device = PDF_DEVICE, width = 24, height = 17)
