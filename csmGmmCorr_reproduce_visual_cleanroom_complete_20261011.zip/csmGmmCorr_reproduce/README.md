# Reproducing the correlated csmGmm analyses

This repository contains the scripts used to run the simulation experiments,
prepare the application data, and create the figures and tables accompanying
the correlated csmGmm study. Statistical estimation is provided by the
`csmGmmCorr` R package; this repository supplies the reproducible analysis
workflow around that package.

## Requirements

The workflow targets R 4.5 or later and an LSF cluster. Install the required R
packages and compile the small native kernels before submitting jobs:

```bash
Rscript setup.R
```

The setup script may install `csmGmmCorr` from a local source archive when one
is supplied through the documented environment variables. Otherwise it uses
the configured remote repository.

## Complete workflow

Run the orchestration script from the repository root:

```bash
mkdir -p logs
bash run_all.sh > logs/run_all.log 2>&1 &
```

Use `bash run_all.sh status` to inspect progress. Re-running the submission
command is safe: completed replicate files are retained and only missing work
is scheduled. After failed array elements have been resubmitted, invoke
`bash run_all.sh final` to recreate the final dependency job.

Simulation arrays write one record per replicate. Randomness is tied to fixed
design and replicate identifiers, so results do not depend on execution order.
For a quick installation check, set `SIM_N=2000` and run
`bash tests/test_all.sh submit`.

## Analysis layout

- `SupportingCode/` contains shared simulation, fitting, scoring, diagnostic,
  real-data, and plotting utilities.
- `Fig1/` through `Fig4/` contain scripts for main-text figures and analyses.
- `Tab1/` and `Tab2/` produce the main tables.
- `SuppFig1/` and `SuppTab*/` contain supplementary analyses.
- `Data/` downloads and prepares the public summary statistics.
- `Validation/` compares implementations and checks numerical behavior.
- `tests/` contains syntax and smoke tests.

Each simulation folder contains an R worker and a matching LSF submission file.
Figure and table scripts consume the completed replicate-level outputs. The
application workflow uses public GLGC lipid summary statistics and UK Biobank
GWAS summary statistics; preparation instructions are in `Data/README.md`.

## Computational notes

The expensive components are the simulation arrays and correlated mixture
fits. Resource requests in the LSF files are conservative limits rather than
expected use. Native kernels under `SupportingCode/src/` accelerate monotone
adjustment, incongruity diagnostics, and hashing used by data preparation.

## License

The repository is distributed under the MIT license. The bundled
`mediation.test` sources retain their own license files.
