args <- commandArgs(trailingOnly = TRUE)
local_source <- if (length(args)) args[[1L]] else Sys.getenv("CSMGMMCORR_SRC", "")
library_dir <- .libPaths()[[1L]]
if (!dir.exists(library_dir) || file.access(library_dir, 2L) != 0L) {
  library_dir <- normalizePath(".Rlib", mustWork = FALSE)
  dir.create(library_dir, recursive = TRUE, showWarnings = FALSE)
  .libPaths(c(library_dir, .libPaths()))
}
cran <- "https://cloud.r-project.org"

cran_packages <- c(
  "here", "data.table", "ggplot2", "cowplot", "remotes", "qch", "repfdr",
  "RSQLite", "dplyr", "lpSolve", "R.methodsS3", "R.oo", "R.utils",
  "stringr", "tibble", "tidyr"
)
for (package in cran_packages) {
  if (!requireNamespace(package, quietly = TRUE)) {
    install.packages(package, lib = library_dir, repos = cran)
  }
}

if (!requireNamespace("adaFilter", quietly = TRUE)) {
  message("adaFilter is absent; the repository includes its comparison implementation.")
}

if (!requireNamespace("mediation.test", quietly = TRUE)) {
  install.packages(
    file.path("SupportingCode", "packages", "mediation.test"),
    lib = library_dir,
    repos = NULL,
    type = "source"
  )
}

required_version <- package_version("1.3.0")
needs_csm <- !requireNamespace("csmGmmCorr", quietly = TRUE) ||
  utils::packageVersion("csmGmmCorr") < required_version
if (nzchar(local_source)) {
  install.packages(local_source, lib = library_dir, repos = NULL, type = "source")
} else if (needs_csm) {
  repository <- Sys.getenv("CSMGMMCORR_REPO", "ZLiu20/csmGmmCorr")
  installed <- tryCatch({
    remotes::install_github(repository, lib = library_dir, upgrade = "never")
    TRUE
  }, error = function(error) {
    message(conditionMessage(error))
    FALSE
  })
  if (!installed) {
    stop(
      "Unable to install csmGmmCorr 1.3.0. Supply a local source archive as the first argument ",
      "or set CSMGMMCORR_SRC.",
      call. = FALSE
    )
  }
}
if (utils::packageVersion("csmGmmCorr") != required_version) {
  warning("The paper used csmGmmCorr 1.3.0; installed version is ",
          utils::packageVersion("csmGmmCorr"), call. = FALSE)
}

if (!requireNamespace("csmGmm", quietly = TRUE)) {
  tryCatch(
    remotes::install_github("ryansun/csmGmm@4a03af5", lib = library_dir, upgrade = "never"),
    error = function(error) message("Optional validation package csmGmm was not installed: ",
                                     conditionMessage(error))
  )
}

dir.create("logs", showWarnings = FALSE, recursive = TRUE)
version_packages <- c(
  "csmGmmCorr", "csmGmm", "data.table", "ggplot2", "cowplot", "qch",
  "repfdr", "mediation.test", "RSQLite", "here"
)
version_lines <- c(
  paste("R", getRversion()),
  vapply(version_packages, function(package) {
    version <- tryCatch(as.character(utils::packageVersion(package)), error = function(error) "absent")
    paste(package, version)
  }, character(1))
)
writeLines(version_lines, file.path("logs", "versions.txt"))

source_dir <- file.path("SupportingCode", "src")
old_directory <- getwd()
setwd(source_dir)
on.exit(setwd(old_directory), add = TRUE)
shared_name <- paste0("reprokernels", .Platform$dynlib.ext)
compile_command <- paste(
  shQuote(file.path(R.home("bin"), "R")),
  "CMD SHLIB -o", shQuote(shared_name),
  "rd_kernels.cpp glgc_hash.cpp"
)
compile_status <- system(compile_command)
setwd(old_directory)
if (compile_status != 0L) stop("Native-kernel compilation failed.", call. = FALSE)

here::i_am("setup.R")
source(here::here("SupportingCode", "load_all.R"))
load_kernels()
suppressPackageStartupMessages(library(csmGmmCorr))

set.seed(1)
z <- matrix(stats::rnorm(3000), nrow = 600, ncol = 5)
score <- stats::runif(600)
for (target in c("pleiotropy", "replication")) {
  reference <- csm_adjust(z, score, target, 1L, all = TRUE)$adjusted
  kernel <- rd_majorant(z, score, target, 1L)
  reject <- score < 0.3
  valid <- max(abs(reference - kernel)) <= 1e-12 &&
    sum(rd_incon_dec(z, reject, target, 1L)) == incon_decision(z, reject, target, 1L)
  message("Native kernel ", target, ": ", if (valid) "ok" else "FAILED")
  if (!valid) stop("Native-kernel contract failed.", call. = FALSE)
}

hash_value <- .Call(
  "glgc_blake2b_hex",
  c("chr1:749963:TAA:T", "chr22:17037192:C:T")
)
expected_hash <- c("80cbe36f121d036a", "c8e751c24846a6ce")
if (!identical(hash_value, expected_hash)) stop("BLAKE2b contract failed.", call. = FALSE)
message("SETUP DONE")
