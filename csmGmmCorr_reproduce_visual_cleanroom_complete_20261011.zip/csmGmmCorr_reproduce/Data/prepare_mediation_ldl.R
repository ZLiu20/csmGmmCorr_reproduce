suppressPackageStartupMessages(library(data.table))

say <- function(...) message(format(Sys.time(), "%H:%M:%S"), " ", sprintf(...))
args <- commandArgs(trailingOnly = TRUE)
source_dir <- if (length(args)) args[[1L]] else file.path("Data", "raw", "mediation_ldl")
glgc_root <- if (length(args) >= 2L) args[[2L]] else file.path("Data", "raw", "glgc")
project_root <- Sys.getenv("MEDLDL_OUT", unset = "Data")
scratch <- file.path(project_root, "prepared", "mediation_ldl")
output_dir <- file.path(project_root, "mediation")
pair_dir <- file.path(scratch, "liver_pairs")
dir.create(pair_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

first_match <- function(root, pattern) {
  value <- list.files(root, pattern, recursive = TRUE, full.names = TRUE)
  if (!length(value)) stop("No file matching ", pattern, " below ", root, call. = FALSE)
  value[[1L]]
}
open_command <- function(path) sprintf("gzip -cd %s", shQuote(path))
strip_version <- function(x) sub("\\..*$", "", x)

eqtl_file <- file.path(source_dir, "QTD000266.all.tsv.gz")
gtf_file <- file.path(source_dir, "gencode.v26.GRCh38.genes.gtf")
lookup_file <- file.path(source_dir, "GTEx_v8_lookup_table.txt.gz")
model_db <- file.path(source_dir, "mashr_Liver.db")
covariance_file <- file.path(source_dir, "mashr_Liver.txt.gz")
for (path in c(eqtl_file, gtf_file, lookup_file, model_db, covariance_file)) {
  if (!file.exists(path)) stop("Missing mediation input: ", path, call. = FALSE)
}

ldl_files <- c(
  female = first_match(glgc_root, "LDL_INV_EUR_HRC_1KGP3_others_FEMALE.*results\\.gz$"),
  male = first_match(glgc_root, "LDL_INV_EUR_HRC_1KGP3_others_MALE.*results\\.gz$")
)

read_sqlite_table <- function(database, table) {
  if (requireNamespace("RSQLite", quietly = TRUE)) {
    connection <- DBI::dbConnect(RSQLite::SQLite(), database)
    on.exit(DBI::dbDisconnect(connection), add = TRUE)
    as.data.table(DBI::dbReadTable(connection, table))
  } else {
    fread(cmd = sprintf("sqlite3 -header -csv %s %s", shQuote(database), shQuote(paste0("select * from ", table, ";"))))
  }
}

weights <- read_sqlite_table(model_db, "weights")
extra <- read_sqlite_table(model_db, "extra")
variant_column <- intersect(c("varID", "rsid"), names(weights))[[1L]]
setnames(weights, variant_column, "variant")
weights[, gene := as.character(gene)]
weights[, `:=`(effect = toupper(eff_allele), weight = as.numeric(weight))]
if (!all(grepl("^chr[0-9XY]+_[0-9]+_[ACGT]+_[ACGT]+_b38$", head(weights$variant, 1000L)))) {
  stop("Unexpected MASHR variant identifier format.", call. = FALSE)
}
weights[, c("ref38", "alt38") := tstrsplit(variant, "_", fixed = TRUE, keep = 3:4)]
extra_gene <- intersect(c("gene", "gene_id"), names(extra))
if (!length(extra_gene)) stop("MASHR extra table has no gene identifier.", call. = FALSE)
if (extra_gene[[1L]] != "gene") setnames(extra, extra_gene[[1L]], "gene")
extra_name <- intersect(c("genename", "gene_name"), names(extra))
if (length(extra_name)) {
  gene_labels <- extra[, .(
    gene = as.character(gene),
    gene_name = as.character(get(extra_name[[1L]]))
  )]
} else {
  gene_labels <- extra[, .(gene = as.character(gene), gene_name = as.character(gene))]
}
gene_labels <- gene_labels[!duplicated(gene)]
say("MASHR model: %d genes and %d weights", uniqueN(weights$gene), nrow(weights))

model_variants_file <- file.path(scratch, "ldl_model_variants.tsv.gz")
if (!file.exists(model_variants_file)) {
  model_variants <- unique(weights$variant)
  lookup <- fread(cmd = open_command(lookup_file), select = c("variant_id", "variant_id_b37"))
  lookup <- lookup[variant_id %chin% model_variants & !is.na(variant_id_b37) & nzchar(variant_id_b37)]
  lookup[, key := sub("^chr", "", variant_id_b37)]
  lookup[, c("chr37", "pos37", "ref37", "alt37") := tstrsplit(key, "_", fixed = TRUE, keep = 1:4)]
  lookup[, position_key := paste(chr37, as.integer(pos37), sep = ":")]

  read_ldl <- function(path) {
    tab <- fread(cmd = open_command(path), select = c("CHROM", "POS_b37", "REF", "ALT", "EFFECT_SIZE", "SE"))
    tab[, position_key := paste(sub("^chr", "", CHROM), as.integer(POS_b37), sep = ":")]
    tab[, `:=`(REF = toupper(REF), ALT = toupper(ALT), EFFECT_SIZE = as.numeric(EFFECT_SIZE), SE = as.numeric(SE))]
    tab[position_key %chin% lookup$position_key & is.finite(EFFECT_SIZE) & is.finite(SE) & SE > 0]
  }
  female <- read_ldl(ldl_files[["female"]])
  male <- read_ldl(ldl_files[["male"]])
  ldl <- merge(female, male, by = c("position_key", "REF", "ALT"), all = TRUE, suffixes = c("_f", "_m"))
  ldl[, `:=`(
    precision_f = fifelse(is.na(SE_f), 0, 1 / SE_f^2),
    precision_m = fifelse(is.na(SE_m), 0, 1 / SE_m^2)
  )]
  ldl[, z_ldl := (fifelse(is.na(EFFECT_SIZE_f), 0, EFFECT_SIZE_f * precision_f) +
                    fifelse(is.na(EFFECT_SIZE_m), 0, EFFECT_SIZE_m * precision_m)) /
                   sqrt(precision_f + precision_m)]
  aligned <- merge(lookup[, .(variant = variant_id, position_key, ref37, alt37)],
                   ldl[, .(position_key, REF, ALT, z_ldl)], by = "position_key", allow.cartesian = TRUE)
  aligned <- aligned[(REF == ref37 & ALT == alt37) | (REF == alt37 & ALT == ref37)]
  aligned[REF == alt37 & ALT == ref37, z_ldl := -z_ldl]
  aligned <- aligned[!duplicated(variant) & is.finite(z_ldl)]
  fwrite(aligned[, .(variant, z_ldl)], model_variants_file, sep = "\t")
  say("LDL statistics aligned for %d model variants", nrow(aligned))
}
model_z <- fread(model_variants_file)

twas_file <- file.path(output_dir, "ldl_twas_liver.tsv.gz")
if (!file.exists(twas_file)) {
  covariance <- fread(cmd = open_command(covariance_file))
  setnames(covariance, toupper(names(covariance)))
  required <- c("GENE", "RSID1", "RSID2", "VALUE")
  if (!all(required %in% names(covariance))) stop("MASHR covariance columns are incomplete.", call. = FALSE)
  covariance <- split(covariance[, .(RSID1, RSID2, VALUE)], covariance$GENE)
  model <- merge(weights, model_z, by = "variant")
  result <- rbindlist(lapply(split(model, model$gene), function(block) {
    gene_id <- block$gene[[1L]]
    cov <- covariance[[gene_id]]
    if (is.null(cov)) return(NULL)
    variants <- block$variant
    sigma <- matrix(0, length(variants), length(variants), dimnames = list(variants, variants))
    keep <- cov$RSID1 %chin% variants & cov$RSID2 %chin% variants
    cov <- cov[keep]
    sigma[cbind(cov$RSID1, cov$RSID2)] <- cov$VALUE
    sigma[cbind(cov$RSID2, cov$RSID1)] <- cov$VALUE
    variance <- drop(crossprod(block$weight, sigma %*% block$weight))
    if (!is.finite(variance) || variance <= 0) return(NULL)
    data.table(gene = gene_id, n_used = nrow(block), z_twas = sum(block$weight * block$z_ldl) / sqrt(variance))
  }), use.names = TRUE)
  result <- merge(result, gene_labels, by = "gene", all.x = TRUE)
  result[, gene_id := strip_version(gene)]
  fwrite(result, twas_file, sep = "\t")
  say("S-PrediXcan statistics produced for %d genes", nrow(result))
}
twas <- fread(twas_file)

gene_model_variants <- split(weights$variant, weights$gene)
gene_model_variants <- lapply(gene_model_variants, unique)

split_eqtl <- function() {
  done <- file.path(pair_dir, "DONE")
  if (file.exists(done)) return(invisible())
  gtf <- fread(cmd = if (grepl("\\.gz$", gtf_file)) open_command(gtf_file) else paste("cat", shQuote(gtf_file)),
               sep = "\t", header = FALSE, select = c(1, 3, 4, 5, 7, 9),
               col.names = c("chr", "feature", "start", "end", "strand", "attribute"))
  gtf <- gtf[feature == "gene"]
  gtf[, gene_id := strip_version(sub('.*gene_id "([^"]+)".*', "\\1", attribute))]
  gtf[, tss := fifelse(strand == "-", end, start)]
  gtf <- gtf[gene_id %chin% twas$gene_id & !duplicated(gene_id), .(gene_id, tss)]
  fwrite(gtf, file.path(pair_dir, "model_genes_tss.txt"), sep = "\t", col.names = FALSE)

  header <- names(fread(cmd = paste(open_command(eqtl_file), "| head -1"), nrows = 0L))
  required <- c("gene_id", "chromosome", "position", "ref", "alt", "variant", "maf", "beta", "se", "type")
  index <- match(required, header)
  if (anyNA(index)) stop("eQTL Catalogue input does not contain the expected columns.", call. = FALSE)
  awk <- sprintf(paste0(
    "awk -F'\\t' -v OFS='\\t' -v G=%d -v V=%d -v C=%d -v P=%d -v R=%d -v A=%d -v M=%d -v B=%d -v S=%d -v T=%d ",
    "'BEGIN{while((getline line < G)>0){split(line,x,\"\\t\"); t[x[1]]=x[2]}} ",
    "NR==1{next} $T!=\"SNP\"{next} $M<0.05{next} $S<=0{next} ",
    "{g=$G; sub(/\\..*/,\"\",g); if(!(g in t))next; c=$C; sub(/^chr/,\"\",c); ",
    "file=\"gzip > %s/chr\" c \".tsv.gz\"; if(!seen[file]++){print g,$V,$P,t[g],$B/$S | file}} ",
    "END{for(f in seen)close(f)}'"),
    index[[1L]], index[[6L]], index[[2L]], index[[3L]], index[[4L]], index[[5L]],
    index[[7L]], index[[8L]], index[[9L]], index[[10L]], pair_dir
  )
  status <- system(paste(open_command(eqtl_file), "|", awk))
  if (status != 0L) stop("Failed while splitting liver eQTL statistics.", call. = FALSE)
  writeLines("ok", done)
}
split_eqtl()

choose_genes <- function(genes, rule) {
  if (length(genes) < 3L) return(NULL)
  if (rule == "nearest") return(genes[seq_len(3L)])
  selected <- genes[[1L]]
  for (candidate in genes[-1L]) {
    overlap <- vapply(selected, function(chosen) {
      length(intersect(gene_model_variants[[candidate]], gene_model_variants[[chosen]])) > 0L
    }, logical(1L))
    if (!any(overlap)) selected <- c(selected, candidate)
    if (length(selected) == 3L) return(selected)
  }
  NULL
}

z_twas <- setNames(twas$z_twas, twas$gene_id)
gene_names <- setNames(twas$gene_name, twas$gene_id)
outputs <- list(noshare = list(), nearest = list())
for (chromosome in 1:22) {
  path <- file.path(pair_dir, sprintf("chr%d.tsv.gz", chromosome))
  if (!file.exists(path)) next
  pairs <- fread(cmd = open_command(path), header = FALSE,
                 col.names = c("gene", "variant", "pos", "tss", "z"))
  pairs <- pairs[is.finite(z)]
  pairs[, count := .N, by = variant]
  candidates <- unique(pairs[count >= 3L, .(variant, pos)])
  candidates[, window := pos %/% 10000L]
  candidates[, distance := abs(pos - (window * 10000L + 5000L))]
  setorder(candidates, window, distance, pos, variant)
  candidates <- candidates[!duplicated(window)]
  pairs[, distance := abs(pos - tss)]
  setorder(pairs, variant, distance, gene)
  groups <- split(pairs, pairs$variant)
  for (rule in names(outputs)) {
    rows <- lapply(candidates$variant, function(id) {
      block <- groups[[id]]
      genes <- choose_genes(block$gene, rule)
      if (is.null(genes)) return(NULL)
      block <- block[match(genes, gene)]
      row <- list(variant = id, chr = chromosome, pos_b38 = block$pos[[1L]])
      shared <- FALSE
      for (j in 1:3) {
        if (j > 1L) shared <- shared || any(vapply(seq_len(j - 1L), function(k) {
          length(intersect(gene_model_variants[[genes[[j]]]], gene_model_variants[[genes[[k]]]])) > 0L
        }, logical(1L)))
        row[[paste0("gene", j)]] <- genes[[j]]
        row[[paste0("gene", j, "_name")]] <- gene_names[[genes[[j]]]]
        row[[paste0("tss", j)]] <- block$tss[[j]]
        row[[paste0("alpha", j)]] <- block$z[[j]]
        row[[paste0("beta", j)]] <- z_twas[[genes[[j]]]]
      }
      row$shared <- shared
      row
    })
    outputs[[rule]][[length(outputs[[rule]]) + 1L]] <- rbindlist(rows, fill = TRUE)
  }
}

stat_columns <- as.vector(rbind(paste0("alpha", 1:3), paste0("beta", 1:3)))
for (rule in names(outputs)) {
  table <- rbindlist(outputs[[rule]], fill = TRUE)
  setorder(table, chr, pos_b38)
  setcolorder(table, c("variant", "chr", "pos_b38", paste0("gene", rep(1:3, each = 2L), rep(c("", "_name"), 3L)),
                       paste0("tss", 1:3), stat_columns, "shared"))
  fwrite(table, file.path(output_dir, sprintf("mediation_ldl_liver_%s.tsv.gz", rule)), sep = "\t")
  say("%s: %d features, %d gene triples", rule, nrow(table), uniqueN(table[, .(gene1, gene2, gene3)]))
  print(round(cor(as.matrix(table[, ..stat_columns]), use = "pairwise.complete.obs"), 3L))
}
say("DONE")
