#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p raw/glgc/pleiotropy/GLGC_trans raw/glgc/replication/GLGC_LDL_sex_ancestry raw/ukb

fetch() {
  local url=$1 destination=$2
  [[ -s "$destination" ]] && { printf 'exists: %s\n' "$destination"; return; }
  local partial="${destination}.part"
  wget -q --tries=10 --timeout=120 --waitretry=30 -O "$partial" "$url"
  mv "$partial" "$destination"
}

glgc=https://csg.sph.umich.edu/willer/public/glgc-lipids2021/results
for trait in HDL LDL TC logTG nonHDL; do
  name="with_BF_meta-analysis_AFR_EAS_EUR_HIS_SAS_${trait}_INV_ALL_with_N_1.gz"
  fetch "$glgc/trans_ancestry/$name" "raw/glgc/pleiotropy/GLGC_trans/$name"
done
fetch "$glgc/trans_ancestry/README.txt" raw/glgc/pleiotropy/GLGC_trans/README.txt

for stratum in AFR_HRC_1KGP3_others EAS_1KGP3 EUR_HRC_1KGP3_others HIS_1KGP3 SAS_HRC_1KGP3_others; do
  for sex in FEMALE MALE; do
    name="LDL_INV_${stratum}_${sex}.meta.singlevar.results.gz"
    fetch "$glgc/sex_and_ancestry_specific_summary_stats/$name" "raw/glgc/replication/GLGC_LDL_sex_ancestry/$name"
  done
done

ukb=https://broad-ukb-sumstats-us-east-1.s3.amazonaws.com/round2/additive-tsvs
for trait in 21001_irnt 4080_irnt 30870_irnt 30760_irnt 30750_irnt; do
  extra=""
  case "$trait" in 30870_irnt|30760_irnt|30750_irnt) extra=.varorder ;; esac
  fetch "$ukb/$trait.gwas.imputed_v3.both_sexes${extra}.tsv.bgz" "raw/ukb/$trait.gwas.imputed_v3.both_sexes${extra}.tsv.bgz"
done
find raw -type f \( -name '*.gz' -o -name '*.bgz' \) -print0 | xargs -0 -n1 ls -lh
printf 'DOWNLOAD DONE\n'
