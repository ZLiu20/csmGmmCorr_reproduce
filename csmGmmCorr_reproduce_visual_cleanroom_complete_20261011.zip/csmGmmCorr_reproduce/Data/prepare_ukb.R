suppressPackageStartupMessages(library(data.table))

raw_dir <- file.path("Data", "raw", "ukb")
out_dir <- file.path("Data", "prepared", "ukb_pleiotropy")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

traits <- c(BMI = "21001_irnt", SBP = "4080_irnt", TG = "30870_irnt",
            HDL = "30760_irnt", HbA1c = "30750_irnt")
joined <- NULL
for (label in names(traits)) {
  suffix <- if (traits[[label]] %in% c("30870_irnt", "30760_irnt", "30750_irnt")) ".varorder" else ""
  input <- file.path(raw_dir, paste0(traits[[label]], ".gwas.imputed_v3.both_sexes", suffix, ".tsv.bgz"))
  if (!file.exists(input)) stop("Missing UK Biobank file: ", input, call. = FALSE)
  tab <- fread(input, select = c("variant", "minor_AF", "low_confidence_variant", "n_complete_samples", "tstat"))
  message(label, ": ", nrow(tab), " input variants; maximum N = ", max(tab$n_complete_samples, na.rm = TRUE))
  tab <- tab[!low_confidence_variant & minor_AF >= 0.01 & is.finite(tstat),
             .(variant, maf = minor_AF, value = tstat)]
  setnames(tab, "value", label)
  joined <- if (is.null(joined)) tab else merge(joined, tab[, c("variant", label), with = FALSE], by = "variant")
  rm(tab); invisible(gc(FALSE))
}

joined[, c("chr", "pos_b37") := tstrsplit(variant, ":", fixed = TRUE, keep = 1:2)]
joined[, chr := as.integer(chr)]
joined[, pos_b37 := as.integer(pos_b37)]
joined <- joined[chr %between% c(1L, 22L) & is.finite(pos_b37)]
setnames(joined, "variant", "variant_id")
setorder(joined, chr, pos_b37)

columns <- c("variant_id", "chr", "pos_b37", names(traits))
set.seed(20261007)
fitting <- joined[, .SD[sample.int(.N, 1L)], by = .(chr, window = pos_b37 %/% 10000L), .SDcols = columns]
fwrite(fitting[, ..columns], file.path(out_dir, "fit_sample.tsv.gz"), sep = "\t")

manifest <- rbindlist(lapply(1:22, function(chromosome) {
  path <- file.path(out_dir, sprintf("chr%d.tsv.gz", chromosome))
  slice <- joined[chr == chromosome, ..columns]
  fwrite(slice, path, sep = "\t")
  data.table(chr = chromosome, path = basename(path), n_rows = nrow(slice))
}))
fwrite(manifest, file.path(out_dir, "chromosome_manifest.tsv"), sep = "\t")

z <- as.matrix(joined[, ..names(traits)])
message("Common variants: ", nrow(joined), "; test variants: ", nrow(joined) - nrow(fitting))
message("Median null scale: ", paste(round(apply(z, 2L, function(v) median(v^2) / qchisq(0.5, 1)), 3L), collapse = ", "))
print(round(cor(z[rowSums(abs(z) < 2) == ncol(z), , drop = FALSE]), 3L))
writeLines("ok", file.path(out_dir, "PREPARATION_COMPLETE"))
