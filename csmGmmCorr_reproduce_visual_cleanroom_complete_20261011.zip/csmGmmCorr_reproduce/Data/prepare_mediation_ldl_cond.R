suppressPackageStartupMessages(library(data.table))

say <- function(...) message(format(Sys.time(), "%H:%M:%S"), " ", sprintf(...))
args <- commandArgs(trailingOnly = TRUE)
reference <- if (length(args)) args[[1L]] else file.path("Data", "raw", "g1000")
plink <- if (length(args) >= 2L) args[[2L]] else "plink"
bcftools <- if (length(args) >= 3L) args[[3L]] else "bcftools"
proxy_r2 <- 0.8
root <- Sys.getenv("MEDLDL_OUT", unset = "Data")
prepared <- file.path(root, "prepared", "mediation_ldl")
pair_dir <- file.path(prepared, "liver_pairs")
work_dir <- file.path(prepared, "conditional")
dir.create(work_dir, recursive = TRUE, showWarnings = FALSE)
source_dir <- Sys.getenv("MEDLDL_SRC", unset = file.path("Data", "raw", "mediation_ldl"))
input <- file.path(root, "mediation", "mediation_ldl_liver_noshare.tsv.gz")
if (!file.exists(input)) stop("Run prepare_mediation_ldl.R first.", call. = FALSE)
features <- fread(input)
genes <- unique(unlist(features[, .(gene1, gene2, gene3)]))

read_pair_file <- function(chromosome) {
  path <- file.path(pair_dir, sprintf("chr%d.tsv.gz", chromosome))
  if (!file.exists(path)) return(NULL)
  fread(cmd = sprintf("gzip -cd %s", shQuote(path)), header = FALSE,
        col.names = c("gene", "variant", "pos", "tss", "z"))[gene %chin% genes & is.finite(z)]
}
lead <- rbindlist(lapply(1:22, read_pair_file), fill = TRUE)
lead <- lead[lead[, .I[which.max(abs(z))], by = gene]$V1, .(gene, lead = variant, lead_z = z)]
say("Lead variants available for %d genes", nrow(lead))

lookup_path <- file.path(source_dir, "GTEx_v8_lookup_table.txt.gz")
lookup <- fread(cmd = sprintf("gzip -cd %s", shQuote(lookup_path)), select = c("variant_id", "variant_id_b37"))
lookup[, variant := sub("_b38$", "", variant_id)]
lookup <- lookup[variant %chin% unique(c(features$variant, lead$lead)) & !is.na(variant_id_b37)]
lookup[, c("chr37", "pos37", "ref37", "alt37") := tstrsplit(variant_id_b37, "_", fixed = TRUE, keep = 1:4)]
lookup[, `:=`(chr37 = as.integer(sub("^chr", "", chr37)), pos37 = as.integer(pos37))]

fileset <- reference
if (dir.exists(reference)) {
  prefix <- file.path(work_dir, "g1000_eur_needed")
  if (!file.exists(paste0(prefix, ".bed"))) {
    panel <- fread(file.path(reference, "integrated_call_samples_v3.20130502.ALL.panel"))
    eur <- panel[super_pop == "EUR", sample]
    regions <- unique(lookup[, .(chr = chr37, pos = pos37)])
    vcf_parts <- character()
    sample_file <- file.path(work_dir, "eur_samples.txt")
    writeLines(eur, sample_file)
    for (chromosome in 1:22) {
      vcf <- file.path(reference, sprintf("ALL.chr%d.phase3_shapeit2_mvncall_integrated_v5b.20130502.genotypes.vcf.gz", chromosome))
      if (!file.exists(vcf)) stop("Missing reference VCF: ", vcf, call. = FALSE)
      region_file <- file.path(work_dir, sprintf("regions_chr%d.txt", chromosome))
      fwrite(regions[chr == chromosome, .(chr, pos, pos)], region_file, sep = "\t", col.names = FALSE)
      part <- file.path(work_dir, sprintf("eur_chr%d.vcf.gz", chromosome))
      status <- system2(bcftools, c("view", "-R", region_file, "-S", sample_file, "-v", "snps", "-m2", "-M2", "-Oz", "-o", part, vcf))
      if (status != 0L) stop("bcftools failed for chromosome ", chromosome, call. = FALSE)
      vcf_parts <- c(vcf_parts, part)
    }
    combined <- file.path(work_dir, "eur_all.vcf.gz")
    if (system2(bcftools, c("concat", "-Oz", "-o", combined, vcf_parts)) != 0L) stop("bcftools concat failed.", call. = FALSE)
    if (system2(plink, c("--vcf", combined, "--double-id", "--set-missing-var-ids", "@:#", "--make-bed", "--out", prefix)) != 0L) {
      stop("PLINK VCF conversion failed.", call. = FALSE)
    }
  }
  fileset <- prefix
}
if (!file.exists(paste0(fileset, ".bim"))) stop("PLINK reference fileset not found: ", fileset, call. = FALSE)

bim <- fread(paste0(fileset, ".bim"), header = FALSE,
             col.names = c("chr", "id", "cm", "pos", "a1", "a2"))
bim[, key := paste(chr, pos, sep = ":")]
lookup[, key := paste(chr37, pos37, sep = ":")]
mapped <- merge(lookup, bim[, .(key, id, a1, a2)], by = "key", allow.cartesian = TRUE)
mapped <- mapped[(a1 == ref37 & a2 == alt37) | (a1 == alt37 & a2 == ref37)]
mapped[, sign := fifelse(a1 == alt37, 1, -1)]
mapped <- mapped[!duplicated(variant) & !duplicated(key)]
say("Reference variants aligned: %d", nrow(mapped))

range_file <- file.path(work_dir, "range.txt")
fwrite(mapped[, .(chr37, pos37, pos37, variant)], range_file, sep = " ", col.names = FALSE)
subset_prefix <- file.path(work_dir, "reference_subset")
if (system2(plink, c("--bfile", fileset, "--extract", "range", range_file,
                     "--make-bed", "--out", subset_prefix, "--allow-no-sex")) != 0L) {
  stop("PLINK subset operation failed.", call. = FALSE)
}

subset_bim <- fread(paste0(subset_prefix, ".bim"), header = FALSE,
                    col.names = c("chr", "id", "cm", "pos", "a1", "a2"))
subset_bim[, key := paste(chr, pos, sep = ":")]
subset_bim <- merge(subset_bim, mapped[, .(key, variant)], by = "key", all.x = TRUE)
subset_bim[is.na(variant), variant := sprintf("unused_%d", .I)]
fwrite(subset_bim[, .(chr, variant, cm, pos, a1, a2)], paste0(subset_prefix, ".bim"), sep = "\t", col.names = FALSE)

lead_file <- file.path(work_dir, "lead_ids.txt")
writeLines(intersect(unique(lead$lead), subset_bim$variant), lead_file)
ld_prefix <- file.path(work_dir, "lead_ld")
if (system2(plink, c("--bfile", subset_prefix, "--r", "--ld-snp-list", lead_file,
                     "--ld-window-kb", "1500", "--ld-window", "999999", "--ld-window-r2", "0",
                     "--out", ld_prefix, "--allow-no-sex")) != 0L) stop("PLINK LD calculation failed.", call. = FALSE)

ld_raw <- fread(paste0(ld_prefix, ".ld"), select = c("SNP_A", "SNP_B", "R"))
signs <- setNames(mapped$sign, mapped$variant)
ld_raw[, R := R * signs[SNP_A] * signs[SNP_B]]
ld <- unique(rbind(ld_raw[, .(lead = SNP_A, variant = SNP_B, r = R)],
                   ld_raw[, .(lead = SNP_B, variant = SNP_A, r = R)]))
setkey(ld, lead, variant)

lead_z <- setNames(lead$lead_z, lead$gene)
lead_variant <- setNames(lead$lead, lead$gene)
condition_one <- function(variant, gene, marginal) {
  controlling <- lead_variant[[gene]]
  controlling_z <- lead_z[[gene]]
  record <- ld[.(controlling, variant)]
  correlation <- if (nrow(record)) record$r[[1L]] else NA_real_
  reason <- if (identical(variant, controlling)) "lead" else if (!is.finite(correlation)) "no_ld" else if (correlation^2 >= proxy_r2) "proxy" else "conditional"
  value <- if (reason %in% c("lead", "proxy")) marginal else if (reason == "no_ld") NA_real_ else
    (marginal - correlation * controlling_z) / sqrt(1 - correlation^2)
  list(value = value, reason = reason, r = correlation)
}

for (j in 1:3) {
  result <- Map(condition_one, features$variant, features[[paste0("gene", j)]], features[[paste0("alpha", j)]])
  features[[paste0("alpha", j, "_marg")]] <- features[[paste0("alpha", j)]]
  features[[paste0("alpha", j)]] <- vapply(result, `[[`, numeric(1L), "value")
  features[[paste0("alpha", j, "_how")]] <- vapply(result, `[[`, character(1L), "reason")
  features[[paste0("r_lead", j)]] <- vapply(result, `[[`, numeric(1L), "r")
}
features <- features[complete.cases(features[, .(alpha1, alpha2, alpha3)])]
output <- file.path(root, "mediation", "mediation_ldl_liver_noshare_cond.tsv.gz")
fwrite(features, output, sep = "\t")
say("Conditional dataset written with %d features", nrow(features))
say("DONE")
