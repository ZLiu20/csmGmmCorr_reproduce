#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
destination=raw/g1000
mkdir -p "$destination"
base=https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/release/20130502
panel=integrated_call_samples_v3.20130502.ALL.panel
wget -nv -c -O "$destination/$panel" "$base/$panel"
for chromosome in $(seq 1 22); do
  name="ALL.chr${chromosome}.phase3_shapeit2_mvncall_integrated_v5b.20130502.genotypes.vcf.gz"
  wget -nv -c -O "$destination/$name" "$base/$name"
  wget -nv -c -O "$destination/$name.tbi" "$base/$name.tbi"
  if ! gzip -t "$destination/$name" 2>/dev/null; then
    rm -f "$destination/$name"
    wget -nv --tries=10 --timeout=120 -O "$destination/$name" "$base/$name"
    gzip -t "$destination/$name"
  fi
done
printf 'DOWNLOAD DONE\n'
