# Application data

The application datasets are public GWAS and molecular-QTL resources and are intentionally not distributed in this repository. Their total compressed size is roughly 25 GB.

## Download and preparation

Run the following from the repository root on a machine with internet access:

```bash
bash Data/download_data.sh
bsub < Data/run_prepare.lsf
```

The first command obtains five trans-ancestry GLGC lipid traits, ten sex-by-ancestry LDL strata, and five UK Biobank traits. The LSF array prepares replication, lipid pleiotropy, and UK Biobank pleiotropy inputs. Each job requests eight hours and 64 GB.

GLGC variants are aligned by build-37 chromosome, position, REF, and ALT, where ALT is the effect allele. Records must have minor-allele frequency at least 0.01, adequate sample size, finite statistics, and complete coordinates. A deterministic hash chooses one fitting record from every occupied 10-kb window. The UK Biobank preparation applies the analogous frequency and confidence filters and uses a fixed random seed for window sampling.

Each prepared analysis directory contains chromosome-specific compressed tables, `chromosome_manifest.tsv`, and `fit_sample.tsv.gz`. The chromosome files contain the complete evaluation universe; fitting variants are excluded when application discoveries are summarized.

## Three-mediator LDL analysis

The mediation application combines GTEx liver cis-eQTL statistics, GTEx MASHR liver prediction models, and female/male European GLGC LDL summary statistics. Prepare it with:

```bash
bash Data/download_mediation_ldl.sh
Rscript tests/test_prepare_mediation_ldl.R
bsub < Data/run_prepare_mediation_ldl.lsf
bash Data/download_1000g.sh
bsub < Data/run_prepare_mediation_ldl_cond.lsf
```

For each common variant, the design selects three nearby liver-model genes without using association strength. The exposure-to-mediator coordinate is the liver eQTL Z statistic; the mediator-to-LDL coordinate is the S-PrediXcan Z statistic. The primary `noshare` dataset avoids choosing multiple genes that reuse a model variant. The `nearest` dataset is retained as a sensitivity analysis. Conditional alpha statistics use the 1000 Genomes European reference and leave the beta coordinates unchanged.
