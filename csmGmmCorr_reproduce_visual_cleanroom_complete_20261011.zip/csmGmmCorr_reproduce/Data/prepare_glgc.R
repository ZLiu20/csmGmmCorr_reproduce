args <- commandArgs(trailingOnly = TRUE)
analysis <- if (length(args)) args[[1L]] else ""
if (!analysis %in% c("pleiotropy", "replication")) {
  stop("Usage: Rscript Data/prepare_glgc.R {pleiotropy|replication}", call. = FALSE)
}

source(file.path("SupportingCode", "load_all.R"))
load_kernels()
prepare_glgc(
  manifest = file.path("Data", sprintf("glgc_%s_manifest.tsv", analysis)),
  raw_root = file.path("Data", "raw", "glgc"),
  out_dir = file.path("Data", "prepared", sprintf("glgc_%s", analysis)),
  overwrite = TRUE
)
