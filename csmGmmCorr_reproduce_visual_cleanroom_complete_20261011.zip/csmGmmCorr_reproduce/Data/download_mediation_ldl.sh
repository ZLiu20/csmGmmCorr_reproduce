#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
destination=raw/mediation_ldl
mkdir -p "$destination"

fetch() {
  local url=$1 output=$2
  [[ -s "$output" ]] && { printf 'exists: %s\n' "$output"; return; }
  wget -nv --tries=10 --timeout=120 --waitretry=30 -O "${output}.part" "$url"
  mv "${output}.part" "$output"
}

gtex=https://storage.googleapis.com/adult-gtex
fetch "https://ftp.ebi.ac.uk/pub/databases/spot/eQTL/sumstats/QTS000015/QTD000266/QTD000266.all.tsv.gz" "$destination/QTD000266.all.tsv.gz"
fetch "$gtex/references/v8/reference-tables/gencode.v26.GRCh38.genes.gtf" "$destination/gencode.v26.GRCh38.genes.gtf"
fetch "$gtex/references/v8/reference-tables/GTEx_Analysis_2017-06-05_v8_WholeGenomeSeq_838Indiv_Analysis_Freeze.lookup_table.txt.gz" "$destination/GTEx_v8_lookup_table.txt.gz"
fetch "https://zenodo.org/records/3518299/files/mashr_eqtl.tar?download=1" "$destination/mashr_eqtl.tar"

if [[ ! -s "$destination/mashr_Liver.db" ]]; then
  tar -xf "$destination/mashr_eqtl.tar" -C "$destination" --wildcards '*mashr_Liver.db' '*mashr_Liver.txt.gz'
  find "$destination" -name mashr_Liver.db -not -path "$destination/mashr_Liver.db" -exec mv {} "$destination/" \;
  find "$destination" -name mashr_Liver.txt.gz -not -path "$destination/mashr_Liver.txt.gz" -exec mv {} "$destination/" \;
fi
find "$destination" -maxdepth 1 -type f -exec ls -lh {} +
printf 'DOWNLOAD DONE\n'
