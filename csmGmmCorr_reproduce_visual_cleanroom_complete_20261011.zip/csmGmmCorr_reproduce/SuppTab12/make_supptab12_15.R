suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
d <- design_means(read_sim("SuppTab12", "main"))
metrics <- c("FDP", "power", "R", "incon_dec")
captions <- c("Replication false discovery proportion.", "Replication power.",
              "Replication discovery count.", "Replication decision incongruity.")
for (j in seq_along(metrics)) {
  z <- d[, .(value = mean(get(metrics[j]), na.rm = TRUE)), by = .(K, t, method, axis, x)]
  number <- 11L + j
  fwrite(z, file.path("SuppTab12", sprintf("SuppTab%d.csv", number)))
  lines <- c("\\begin{table}[!htbp]", "\\centering", sprintf("\\caption{%s}", captions[j]),
             "\\begin{tabular}{rrlrrr}", "\\toprule", "$K$ & $t$ & Method & Axis & Setting & Value\\\\", "\\midrule")
  for (i in seq_len(nrow(z))) lines <- c(lines, sprintf("%d & %d & %s & %s & %.3f & %.3f\\\\",
    z$K[i], z$t[i], tex_escape(z$method[i]), tex_escape(z$axis[i]), z$x[i], z$value[i]))
  write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("SuppTab12", sprintf("SuppTab%d.tex", number)))
}
