suppressPackageStartupMessages({library(ggplot2); library(cowplot)})
source(file.path("SupportingCode", "plot_style.R"))

K <- 4L
states <- as.matrix(expand.grid(rep(list(c(-1, 0, 1)), K)))
support <- rowSums(states != 0)
rho <- 0.3
sigma <- matrix(rho, K, K); diag(sigma) <- 1
precision <- solve(sigma)

lfdr <- function(z, target, threshold = 1L, magnitudes = c(0, 2, 1.5, 1.5, 1.5)) {
  weight_support <- c(0.6, 0.2, 0.1, 0.06, 0.04)
  weights <- weight_support[support + 1L] / (choose(K, support) * 2^support)
  means <- states * magnitudes[support + 1L]
  log_density <- vapply(seq_len(nrow(states)), function(i) {
    residual <- z - means[i, ]
    -0.5 * drop(residual %*% precision %*% residual) + log(weights[[i]])
  }, numeric(1L))
  probability <- exp(log_density - max(log_density))
  null <- if (target == "pleiotropy") support <= threshold else
    !(support > threshold & abs(rowSums(states)) == support)
  sum(probability[null]) / sum(probability)
}

axis_values <- seq(0, 14, length.out = 561L)
ray <- function(origin, direction) t(vapply(axis_values, function(step) origin + step * direction, numeric(K)))
settings <- list(
  correlated = list(sigma = sigma, origin = c(0, 0, 0, 0), direction = c(1, 0, 0, 0)),
  independent = list(sigma = diag(K), origin = c(0, 0, 0, 0), direction = c(1, 0, 0, 0)),
  diagonal_ray = list(sigma = sigma, origin = c(0, 0, 0, 0), direction = c(0.5, 0.5, 0, 0))
)
setting_labels <- c(
  correlated = expression(rho == 0.3),
  independent = expression(Sigma == I),
  diagonal_ray = expression(paste(rho == 0.3, ", along ", z[1], "=", z[2]))
)

curve_data <- do.call(rbind, lapply(seq_along(settings), function(i) {
  specification <- settings[[i]]
  precision <<- solve(specification$sigma)
  points <- ray(specification$origin, specification$direction)
  data.frame(x = axis_values, y = apply(points, 1L, lfdr, target = "pleiotropy"), setting = names(settings)[i])
}))
curve_data$setting <- factor(curve_data$setting, levels = names(settings))
palette <- c("#0072B2", "#D55E00", "#009E73")
p1 <- ggplot(curve_data, aes(x, y, color = setting, linetype = setting)) +
  geom_line(linewidth = 1.2) + coord_cartesian(ylim = c(0, 1)) +
  scale_color_manual(values = palette, labels = setting_labels, name = NULL) +
  scale_linetype_manual(values = c("solid", "22", "12"), labels = setting_labels, name = NULL) +
  labs(x = expression(z[1]), y = "Local false discovery rate") + theme_paper(14)

precision <- solve(sigma)
grid <- expand.grid(x = seq(0, 5, length.out = 180L), y = seq(0, 5, length.out = 180L))
grid$value <- mapply(function(x, y) lfdr(c(x, y, 1.5, 1.5), "replication"), grid$x, grid$y)
p2 <- ggplot(grid, aes(x, y, fill = value)) + geom_raster() +
  scale_fill_viridis_c(limits = c(0, 1), name = "lfdr") +
  labs(x = expression(z[1]), y = expression(z[2])) + theme_paper(14)

figure <- plot_grid(p1, p2, labels = c("A", "B"), nrow = 1L, rel_widths = c(1.35, 1))
ggsave(file.path("Fig1", "Fig1.pdf"), figure, device = PDF_DEVICE, width = 13, height = 6.5)
writeLines(c(
  sprintf("Pleiotropy lfdr at (12,0,0,0): %.4f", lfdr(c(12, 0, 0, 0), "pleiotropy")),
  sprintf("Pleiotropy lfdr at (12,3,0,0): %.4f", lfdr(c(12, 3, 0, 0), "pleiotropy")),
  sprintf("Replication lfdr at (4,1.5,1.5,1.5): %.4f", lfdr(c(4, 1.5, 1.5, 1.5), "replication"))
), file.path("Fig1", "Fig1_numbers.txt"))
