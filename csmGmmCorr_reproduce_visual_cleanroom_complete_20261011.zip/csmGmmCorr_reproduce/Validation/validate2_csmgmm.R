source(file.path("SupportingCode", "load_all.R"))
records <- list()
for (seed in 1:5) for (K in c(4L, 6L)) {
  set.seed(20261011 + seed + K)
  sigma <- matrix(0.3, K, K); diag(sigma) <- 1
  simulated <- floor_simulate(500L, rep(1 / (K + 1L), K + 1L), rep(2, K), sigma)
  stopifnot(all(is.finite(simulated$Z)), all(dim(simulated$Z) == c(500L, K)))
  records[[length(records) + 1L]] <- data.frame(seed = seed, K = K,
    min_eigenvalue = min(eigen(cor(simulated$Z), symmetric = TRUE, only.values = TRUE)$values))
}
result <- do.call(rbind, records)
write.csv(result, file.path("Validation", "stability_summary.csv"), row.names = FALSE)
stopifnot(all(result$min_eigenvalue > 0))
cat("VALIDATION_STABILITY_OK\n")
