source(file.path("SupportingCode", "load_all.R"))
set.seed(20261011)
H <- rbind(c(0,0,0,0), c(1,1,0,0), c(1,-1,1,0), c(1,1,1,0), c(1,0,1,1))
stopifnot(
  identical(truth_alt(H, "pleiotropy", 1L), c(FALSE, TRUE, TRUE, TRUE, TRUE)),
  identical(truth_alt(H, "replication", 1L), c(FALSE, TRUE, FALSE, TRUE, TRUE))
)
z <- matrix(rnorm(400), ncol = 4L)
for (target in c("pleiotropy", "replication")) {
  score <- runif(nrow(z))
  rejected <- floor_stepup(score, 0.1)
  stopifnot(length(rejected) == nrow(z), all(is.finite(score)))
}
cat("VALIDATION_CORE_OK\n")
