# Validation programs

These scripts are optional diagnostics and are not used to create the primary paper results.

- `validate_csmgmm.R` checks target definitions, lfdr step-up behavior, and comparator contracts on deterministic synthetic data.
- `validate2_csmgmm.R` repeats the checks across seeds, dimensions, and thresholds and records numerical stability summaries.
- `diag_incon.R` verifies the raw score and decision incongruity calculations on examples with known order relations.

Run them from the repository root after `Rscript setup.R`, or set `VALIDATION=1` before running `make_all.sh`.
