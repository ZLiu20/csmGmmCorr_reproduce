suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
main <- rbindlist(list(read_sim("Tab2", "main"), read_sim("Fig2", "main")), fill = TRUE)
rho <- read_sim("Fig3", "rho")

make_one <- function(data, number, caption) {
  summary <- overall_means(data)
  fwrite(summary, file.path("SuppTab10", sprintf("SuppTab%d.csv", number)))
  lines <- c("\\begin{table}[!htbp]", "\\centering", sprintf("\\caption{%s}", caption),
    "\\begin{tabular}{lllrrrr}", "\\toprule", "Target & $K$ & Method & FDP & Max FDP & Power & Incongruity\\\\", "\\midrule")
  for (i in seq_len(nrow(summary))) lines <- c(lines, sprintf("%s & %d & %s & %.3f & %.3f & %.3f & %.1f\\\\",
    TARGET_NAME[[summary$target[i]]], summary$K[i], tex_escape(summary$method[i]), summary$FDP[i], summary$FDPmax[i], summary$power[i], summary$incon_dec[i]))
  write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("SuppTab10", sprintf("SuppTab%d.tex", number)))
}
make_one(main, 10L, "Comparison with csmGmm in the main designs.")
make_one(rho, 11L, "Comparison with csmGmm across correlation settings.")
