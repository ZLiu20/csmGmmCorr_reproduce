suppressPackageStartupMessages({library(data.table); library(ggplot2); library(cowplot)})
source(file.path("SupportingCode", "load_all.R"))

summary <- design_means(read_sim("Fig3", "rho"))
fwrite(summary, file.path("Fig3", "output", "design_rho.csv"))
panels <- list()
for (target in names(TARGET_NAME)) {
  chosen <- summary[target == ..target & K == 6L & t == 1L]
  active <- intersect(c("penalized", "ML", "csmGmm", "csmGmm_cor", "csmGmm_pen"), unique(chosen$method))
  panels[[length(panels) + 1L]] <- sim_panel(chosen, "FDP", active,
    expression("Equicorrelation " * rho), sprintf("FDP (%s)", TARGET_NAME[[target]]), ylim = TRUE) + fdp_line()
  panels[[length(panels) + 1L]] <- sim_panel(chosen, "power", active,
    expression("Equicorrelation " * rho), sprintf("Power (%s)", TARGET_NAME[[target]]))
}
figure <- combine_panels(panels, nrow = 3L, legend = 1L, rel = 0.12, ncol_legend = 3L)
ggsave(file.path("Fig3", "Fig3.pdf"), figure, device = PDF_DEVICE, width = 14, height = 15)
