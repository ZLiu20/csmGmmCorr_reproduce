suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
d <- design_means(read_sim("Fig2", "main"))[target == "mediation" & t == 2L]
metrics <- c("FDP", "power", "incon_score")
captions <- c("Mediation FDP for the support-qualified target with $t=2$.",
              "Mediation power for the support-qualified target with $t=2$.",
              "Mediation score incongruity for the support-qualified target with $t=2$.")
for (j in seq_along(metrics)) {
  z <- d[, .(value = mean(get(metrics[j]), na.rm = TRUE)), by = .(K, method, axis, x)]
  number <- 15L + j
  fwrite(z, file.path("SuppTab16", sprintf("SuppTab%d.csv", number)))
  lines <- c("\\begin{table}[!htbp]", "\\centering", sprintf("\\caption{%s}", captions[j]),
    "\\begin{tabular}{rlrrr}", "\\toprule", "$K$ & Method & Axis & Setting & Value\\\\", "\\midrule")
  for (i in seq_len(nrow(z))) lines <- c(lines, sprintf("%d & %s & %s & %.3f & %.3f\\\\",
    z$K[i], tex_escape(z$method[i]), tex_escape(z$axis[i]), z$x[i], z$value[i]))
  write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("SuppTab16", sprintf("SuppTab%d.tex", number)))
}
