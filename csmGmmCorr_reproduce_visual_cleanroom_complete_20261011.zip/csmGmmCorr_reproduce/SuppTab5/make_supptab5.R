suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
d <- read_sim("Fig2", "main")
summary <- d[, .(
  replicates = uniqueN(rep), convergence = mean(converged %in% TRUE, na.rm = TRUE),
  iterations = mean(iterations, na.rm = TRUE), fit_minutes = mean(fit_min, na.rm = TRUE),
  min_eigenvalue = mean(sigma_min_eig, na.rm = TRUE)
), by = .(target, K, t, method)]
fwrite(summary, file.path("SuppTab5", "SuppTab5.csv"))
lines <- c("\\begin{table}[!htbp]", "\\centering", "\\caption{Fitting diagnostics in the main simulation.}",
  "\\begin{tabular}{lllr rrr}", "\\toprule", "Target & $K$ & Method & Replicates & Convergence & Iterations & Minutes\\\\", "\\midrule")
for (i in seq_len(nrow(summary))) lines <- c(lines, sprintf("%s & %d & %s & %d & %.3f & %.1f & %.2f\\\\",
  TARGET_NAME[[summary$target[i]]], summary$K[i], tex_escape(summary$method[i]), summary$replicates[i],
  summary$convergence[i], summary$iterations[i], summary$fit_minutes[i]))
write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("SuppTab5", "SuppTab5.tex"))
