suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
d <- design_means(read_sim("Fig2", "main"))

write_metric <- function(metric, number, caption) {
  z <- d[, .(value = mean(get(metric), na.rm = TRUE)), by = .(target, K, t, method)]
  fwrite(z, file.path("SuppTab6", sprintf("SuppTab%d.csv", number)))
  lines <- c("\\begin{table}[!htbp]", "\\centering", sprintf("\\caption{%s}", caption),
             "\\begin{tabular}{lllrr}", "\\toprule", "Target & $K$ & Method & $t$ & Value\\\\", "\\midrule")
  for (i in seq_len(nrow(z))) lines <- c(lines, sprintf("%s & %d & %s & %d & %.3f\\\\",
    TARGET_NAME[[z$target[i]]], z$K[i], tex_escape(z$method[i]), z$t[i], z$value[i]))
  write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("SuppTab6", sprintf("SuppTab%d.tex", number)))
}
write_metric("FDP", 6L, "Mean false discovery proportion by target and dimension.")
write_metric("power", 7L, "Mean power by target and dimension.")
write_metric("incon_dec", 8L, "Mean number of decision incongruities by target and dimension.")
