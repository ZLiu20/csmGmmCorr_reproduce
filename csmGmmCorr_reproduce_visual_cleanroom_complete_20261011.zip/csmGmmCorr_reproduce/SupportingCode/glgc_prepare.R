GLGC_MISSING <- c("", "NA", "NaN", "nan", ".")

acklam_qnorm <- function(p) {
  p <- as.numeric(p)
  out <- stats::qnorm(p)
  out[p == 0] <- -Inf
  out[p == 1] <- Inf
  out
}

glgc_chrom_rank <- function(x) {
  value <- toupper(sub("^chr", "", trimws(as.character(x)), ignore.case = TRUE))
  rank <- suppressWarnings(as.integer(value))
  rank[value == "X"] <- 23L
  rank[value == "Y"] <- 24L
  rank[value %in% c("M", "MT")] <- 25L
  rank[is.na(rank)] <- 10000L
  rank
}

glgc_chrom_label <- function(rank) {
  ifelse(rank == 23L, "X", ifelse(rank == 24L, "Y", ifelse(rank == 25L, "MT", as.character(rank))))
}

.glgc_numeric <- function(x) {
  if (is.numeric(x)) return(as.double(x))
  suppressWarnings(as.numeric(ifelse(x %in% GLGC_MISSING, NA_character_, x)))
}

.glgc_read_header <- function(path) {
  first <- if (grepl("[.](gz|bgz)$", path)) {
    system(paste("gzip -cd", shQuote(path), "| head -1"), intern = TRUE)
  } else {
    readLines(path, n = 1L, warn = FALSE)
  }
  strsplit(first, "\t", fixed = TRUE)[[1L]]
}

glgc_read_source <- function(path, beta_col, se_col, p_col, af_col, n_col,
                             min_maf, min_n_fraction, max_chrom_rank = 22L) {
  header <- .glgc_read_header(path)
  needed <- c("rsID", "CHROM", "POS_b37", "REF", "ALT", beta_col, se_col, af_col, n_col)
  if (nzchar(p_col)) needed <- c(needed, p_col)
  missing <- setdiff(needed, header)
  if (length(missing)) stop("Missing columns in ", path, ": ", paste(missing, collapse = ", "), call. = FALSE)
  read_args <- list(sep = "\t", select = unique(needed),
                    na.strings = GLGC_MISSING, showProgress = FALSE)
  if (grepl("[.](gz|bgz)$", path)) {
    read_args$cmd <- paste("gzip -cd", shQuote(path))
  } else {
    read_args$file <- path
  }
  value <- do.call(data.table::fread, read_args)
  counts <- list(raw_rows = nrow(value))
  sample_n <- .glgc_numeric(value[[n_col]])
  max_n <- suppressWarnings(max(sample_n[is.finite(sample_n)]))
  if (!is.finite(max_n)) stop("No finite sample size in ", path, call. = FALSE)
  minimum_n <- max_n * min_n_fraction
  rank <- glgc_chrom_rank(value$CHROM)
  position <- suppressWarnings(as.integer(trunc(.glgc_numeric(value$POS_b37))))
  invalid_coordinate <- is.na(position) | rank < 1L | rank > 25L | position < 1L
  counts$invalid_coordinate <- sum(invalid_coordinate)
  excluded_chromosome <- !invalid_coordinate & rank > max_chrom_rank
  counts$non_autosomal_or_excluded <- sum(excluded_chromosome)
  keep <- !invalid_coordinate & !excluded_chromosome

  ref <- toupper(trimws(ifelse(is.na(value$REF), "", value$REF)))
  alt <- toupper(trimws(ifelse(is.na(value$ALT), "", value$ALT)))
  invalid_allele <- keep & (ref == "" | alt == "" | ref == alt)
  counts$invalid_allele <- sum(invalid_allele)
  keep <- keep & !invalid_allele

  beta <- .glgc_numeric(value[[beta_col]])
  standard_error <- .glgc_numeric(value[[se_col]])
  p_value <- if (nzchar(p_col)) .glgc_numeric(value[[p_col]]) else rep(NA_real_, nrow(value))
  z <- rep(NA_real_, nrow(value))
  use_standard_error <- is.finite(beta) & is.finite(standard_error) & standard_error > 0
  z[use_standard_error] <- beta[use_standard_error] / standard_error[use_standard_error]
  use_p <- !use_standard_error & is.finite(beta) & is.finite(p_value) & p_value > 0 & p_value <= 1
  if (any(use_p)) {
    probability <- pmin(1, pmax(1e-300, p_value[use_p]))
    magnitude <- -acklam_qnorm(probability / 2)
    z[use_p] <- ifelse(beta[use_p] < 0, -magnitude, magnitude)
  }
  finite_z <- keep & is.finite(z)
  counts$nonfinite_z <- sum(keep & !is.finite(z))
  keep <- finite_z

  allele_frequency <- .glgc_numeric(value[[af_col]])
  maf_fail <- keep & (!is.finite(allele_frequency) | allele_frequency < min_maf |
                        allele_frequency > 1 - min_maf)
  counts$maf_fail <- sum(maf_fail)
  keep <- keep & !maf_fail
  n_fail <- keep & (!is.finite(sample_n) | sample_n < minimum_n)
  counts$n_fail <- sum(n_fail)
  keep <- keep & !n_fail

  out <- data.table::data.table(
    rank = rank[keep], pos = position[keep], ref = ref[keep], alt = alt[keep],
    z = z[keep], n = sample_n[keep], rsid = as.character(value$rsID[keep]),
    source_index = which(keep)
  )
  data.table::setorderv(out, c("rank", "pos", "ref", "alt", "source_index"))
  out[, best_n := max(n), by = .(rank, pos, ref, alt)]
  counts$duplicate_allele_at_position <- sum(out[, .N, by = .(rank, pos, ref, alt)]$N - 1L)
  out <- out[n == best_n][, .SD[1L], by = .(rank, pos, ref, alt)]
  out[, c("best_n", "source_index") := NULL]
  counts$qc_rows <- nrow(out)
  list(data = out, counts = counts, max_n = max_n, min_n = minimum_n)
}

.glgc_write <- function(x, path) {
  data.table::fwrite(x, path, sep = "\t", eol = "\r\n", quote = "auto",
                     compress = if (grepl("[.]gz$", path)) "gzip" else "none")
}

prepare_glgc <- function(manifest, raw_root, out_dir, min_maf = 0.01,
                         min_n_fraction = 0.5, fit_window_bp = 10000L,
                         z_cap = 12, overwrite = FALSE) {
  manifest_table <- data.table::fread(manifest, sep = "\t", colClasses = "character")
  if (nrow(manifest_table) < 2L || anyDuplicated(manifest_table$label)) {
    stop("Manifest needs at least two uniquely labelled sources.", call. = FALSE)
  }
  complete_marker <- file.path(out_dir, "PREPARATION_COMPLETE")
  if (file.exists(complete_marker) && !overwrite) stop("Prepared output already exists.", call. = FALSE)
  if (dir.exists(out_dir)) unlink(out_dir, recursive = TRUE)
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  combined <- NULL
  qc <- vector("list", nrow(manifest_table))

  for (i in seq_len(nrow(manifest_table))) {
    row <- manifest_table[i]
    path <- if (startsWith(row$relative_path, "/")) row$relative_path else file.path(raw_root, row$relative_path)
    source <- glgc_read_source(
      path, row$beta_col, row$se_col,
      if (nzchar(row$p_col)) row$p_col else "pvalue",
      if (nzchar(row$af_col)) row$af_col else "POOLED_ALT_AF",
      if (nzchar(row$n_col)) row$n_col else "N",
      min_maf, min_n_fraction
    )
    qc[[i]] <- data.table::data.table(
      label = row$label, path = normalizePath(path), max_n = source$max_n,
      min_n = source$min_n, min_maf = min_maf,
      data.table::as.data.table(source$counts)
    )
    current <- source$data
    data.table::setnames(current, c("z", "n", "rsid"), paste0(c("z_", "n_", "rsid_"), i))
    combined <- if (is.null(combined)) current else merge(combined, current, by = c("rank", "pos", "ref", "alt"))
  }
  data.table::setorderv(combined, c("rank", "pos", "ref", "alt"))
  rsid <- rep(".", nrow(combined))
  for (i in seq_len(nrow(manifest_table))) {
    candidate <- combined[[paste0("rsid_", i)]]
    usable <- !is.na(candidate) & !(candidate %in% GLGC_MISSING)
    rsid[usable & rsid == "."] <- candidate[usable & rsid == "."]
  }
  chromosome <- glgc_chrom_label(combined$rank)
  output <- data.table::data.table(
    variant_id = sprintf("chr%s:%d:%s:%s", chromosome, combined$pos, combined$ref, combined$alt),
    rsid = rsid, chr = chromosome, pos_b37 = combined$pos,
    ref = combined$ref, alt = combined$alt
  )
  for (i in seq_len(nrow(manifest_table))) {
    output[[manifest_table$label[i]]] <- sprintf("%.10g", pmin(z_cap, pmax(-z_cap, combined[[paste0("z_", i)]])))
  }
  window <- (combined$rank - 1L) * 1000000000 + (combined$pos - 1L) %/% fit_window_bp
  hash <- .Call("glgc_blake2b_hex", output$variant_id)
  selected_order <- order(window, hash, method = "radix")
  fit_rows <- sort(selected_order[!duplicated(window[selected_order])])
  .glgc_write(output[fit_rows], file.path(out_dir, "fit_sample.tsv.gz"))
  chromosome_manifest <- NULL
  for (rank in sort(unique(combined$rank))) {
    index <- which(combined$rank == rank)
    filename <- sprintf("chr%s.tsv.gz", glgc_chrom_label(rank))
    .glgc_write(output[index], file.path(out_dir, filename))
    chromosome_manifest <- rbind(chromosome_manifest, data.table::data.table(
      chr = glgc_chrom_label(rank), path = filename, n_rows = length(index)
    ))
  }
  .glgc_write(chromosome_manifest, file.path(out_dir, "chromosome_manifest.tsv"))
  .glgc_write(data.table::rbindlist(qc, fill = TRUE), file.path(out_dir, "source_qc.tsv"))
  .glgc_write(data.table::data.table(
    strict_common = nrow(output), fit_sample_n = length(fit_rows),
    fit_window_bp = fit_window_bp, min_maf = min_maf,
    min_n_fraction = min_n_fraction, z_cap = z_cap,
    n_sources = nrow(manifest_table), manifest = normalizePath(manifest), raw_root = normalizePath(raw_root)
  ), file.path(out_dir, "prepare_summary.tsv"))
  writeLines("ok", complete_marker)
  invisible(list(common = nrow(output), fit = length(fit_rows)))
}
