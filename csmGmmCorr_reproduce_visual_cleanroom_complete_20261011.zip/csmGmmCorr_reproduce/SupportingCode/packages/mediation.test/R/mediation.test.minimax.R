#' Minimax test for a two-parameter mediation null
#'
#' @param t A two-column matrix or a length-two vector of test statistics.
#' @param alpha Type-I error level.
#' @param truncation Minimum absolute coordinate required for rejection.
#' @param sample_size Sample size; use `Inf` for Gaussian statistics.
#' @param compute_pvals Whether conservative p-values should be returned.
#' @export
mediation_test_minimax <- function(t, alpha = 0.05, truncation = 0,
                                   sample_size = Inf, compute_pvals = TRUE) {
  original <- t
  statistic <- .as_test_matrix(t)
  alpha <- as.numeric(alpha)[1L]
  if (!is.finite(alpha) || alpha <= 0 || alpha > 0.5) stop("alpha must lie in (0, 0.5].", call. = FALSE)
  truncation <- max(0, as.numeric(truncation)[1L])
  distribution <- .distribution_functions(sample_size)
  inverse_alpha <- 1 / alpha
  probabilities <- seq(1 - inverse_alpha * alpha / 2, 1 - alpha,
                       by = inverse_alpha * alpha / 2)
  cutoffs <- distribution$quantile(probabilities)
  absolute <- abs(statistic)
  rank_x <- findInterval(absolute[, 1L], cutoffs)
  rank_y <- findInterval(absolute[, 2L], cutoffs)
  decision <- rank_x + rank_y >= inverse_alpha
  decision <- decision & apply(absolute, 1L, min) >= truncation
  names(decision) <- rep("rejection", length(decision))

  pvalue <- rep(NA_real_, nrow(statistic))
  if (isTRUE(compute_pvals)) {
    hi <- distribution$cdf(pmax(absolute[, 1L], absolute[, 2L]))
    lo <- distribution$cdf(pmin(absolute[, 1L], absolute[, 2L]))
    interval <- pmax(2 * lo - 1, .Machine$double.eps)
    tail <- pmax(1 - hi, 0)
    k <- floor(tail / interval)
    harmonic <- digamma(k + 1) - digamma(1)
    pvalue <- pmin(1, 2 * tail / (k + 1) + 2 * interval * harmonic)
  }
  .new_test_result(original, alpha, truncation, sample_size, decision,
                   pvalue, "minimax")
}

#' Adaptive Benjamini-Hochberg procedure using the minimax test
#'
#' @param BH Select either the statistic-based or conservative-p-value rule.
#' @param K Number of grid points used by the statistic-based search.
#' @inheritParams mediation_test_minimax
#' @export
mediation_test_minimax_BH <- function(t, alpha = 0.05, truncation = 0,
                                      BH = c("statistics", "pval"),
                                      sample_size = Inf, K = 10L) {
  BH <- match.arg(BH)
  statistic <- .as_test_matrix(t)
  m <- nrow(statistic)
  if (m == 1L) return(mediation_test_minimax(statistic, alpha, truncation, sample_size))
  if (BH == "pval") {
    result <- mediation_test_minimax(statistic, alpha, truncation, sample_size)
    result$decision <- stats::p.adjust(result$pvals, method = "BH") <= alpha
    names(result$decision) <- rep("rejection", m)
    result$method <- "minimax_BH"
    result$BH <- BH
    result$K <- as.integer(K)
    return(result)
  }

  K <- max(1L, min(as.integer(K), m - 1L))
  levels <- unique(seq(alpha / m, alpha, length.out = max(20L, K * m)))
  counts <- vapply(levels, function(level) {
    sum(mediation_test_minimax(statistic, level, truncation, sample_size, FALSE)$decision)
  }, integer(1L))
  valid <- which(counts >= ceiling(levels * m / alpha))
  adjusted <- if (length(valid)) levels[[max(valid)]] else alpha / m
  result <- mediation_test_minimax(statistic, adjusted, truncation, sample_size)
  if (!length(valid)) result$decision[] <- FALSE
  result$alpha <- alpha
  result$adjusted_alpha <- adjusted
  result$method <- "minimax_BH"
  result$BH <- BH
  result$K <- K
  result
}
