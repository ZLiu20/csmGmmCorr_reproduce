#' Tests for a two-parameter mediation null
#'
#' The package supplies single-test minimax and Bayes procedures and an
#' adaptive multiple-testing wrapper.
#' @keywords internal
"_PACKAGE"
