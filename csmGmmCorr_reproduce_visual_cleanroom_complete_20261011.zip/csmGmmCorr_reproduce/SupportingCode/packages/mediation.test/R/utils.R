.as_test_matrix <- function(t) {
  if (is.null(dim(t))) {
    value <- as.numeric(t)
    if (length(value) %% 2L) stop("The test statistics must occur in pairs.", call. = FALSE)
    return(matrix(value, ncol = 2L, byrow = TRUE))
  }
  value <- as.matrix(t)
  storage.mode(value) <- "double"
  if (ncol(value) != 2L) stop("The test-statistic matrix must have two columns.", call. = FALSE)
  value
}

.distribution_functions <- function(sample_size) {
  if (is.infinite(sample_size)) {
    list(cdf = stats::pnorm, quantile = stats::qnorm, df = Inf)
  } else {
    n <- as.integer(sample_size)
    if (n <= 1L) stop("sample_size must exceed one.", call. = FALSE)
    list(
      cdf = function(x) stats::pt(x, df = n - 1L),
      quantile = function(p) stats::qt(p, df = n - 1L),
      df = n - 1L
    )
  }
}

.new_test_result <- function(t, alpha, truncation, sample_size, decision, pvals,
                             method, extra = list()) {
  output <- c(list(t = t, alpha = alpha, truncation = truncation,
                   sample_size = sample_size, decision = decision,
                   pvals = pvals, method = method), extra)
  class(output) <- "mediation.test"
  output
}

print.mediation.test <- function(x, ...) {
  cat("Mediation composite-null test\n")
  cat("Method:", x$method, "\n")
  cat("Level:", format(x$alpha), "\n")
  cat("Rejections:", sum(x$decision, na.rm = TRUE), "of", length(x$decision), "\n")
  invisible(x)
}

plot.mediation.test <- function(x, ...) {
  point <- as.matrix(x$t)
  graphics::plot(point[, 1L], point[, 2L], col = ifelse(x$decision, 2L, 1L),
                 xlab = expression(t[1]), ylab = expression(t[2]), ...)
  invisible(x)
}

plot.map.rejection.probabilities <- function(x, ...) {
  graphics::image(x, col = grDevices::hcl.colors(40L, "YlOrRd"),
                  xlab = expression(t[1]), ylab = expression(t[2]), ...)
  invisible(x)
}
