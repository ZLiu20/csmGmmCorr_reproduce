#' Bayes-risk test based on a rejection-probability map
#'
#' @param t A two-column matrix or length-two vector.
#' @param map A map from `compute_map_rejection_probs`.
#' @param sample_size Sample size used for the test statistics.
#' @param truncation Inner non-rejection boundary.
#' @export
mediation_test_Bayes <- function(t, map, sample_size = Inf, truncation = 0) {
  if (!inherits(map, "map.rejection.probabilities") && !is.matrix(map)) {
    stop("map must be a rejection-probability matrix.", call. = FALSE)
  }
  statistic <- .as_test_matrix(t)
  alpha <- attr(map, "alpha")
  if (is.null(alpha)) alpha <- 0.05
  stored_sample <- attr(map, "sample_size")
  if (!is.null(stored_sample) && !identical(stored_sample, sample_size)) {
    warning("sample_size differs from the value used to construct map.", call. = FALSE)
  }
  grid <- attr(map, "grid")
  if (is.null(grid)) {
    boundary <- 2 * .distribution_functions(sample_size)$quantile(1 - alpha / 2)
    grid <- seq(-boundary, boundary, length.out = nrow(map))
  }
  clipped <- statistic
  clipped[] <- pmax(min(grid), pmin(max(grid), clipped))
  row_index <- findInterval(clipped[, 1L], grid, all.inside = TRUE)
  col_index <- findInterval(clipped[, 2L], grid, all.inside = TRUE)
  rejection_probability <- map[cbind(row_index, col_index)]
  deterministic <- pmin(abs(statistic[, 1L]), abs(statistic[, 2L])) > max(abs(grid)) / 2
  decision <- deterministic | rejection_probability >= 0.5
  decision <- decision & apply(abs(statistic), 1L, min) >= truncation
  names(decision) <- rep("rejection", length(decision))
  .new_test_result(t, alpha, truncation, sample_size, decision,
                   rep(NA_real_, length(decision)), "Bayes",
                   list(map = map, rejection_probability = rejection_probability))
}
