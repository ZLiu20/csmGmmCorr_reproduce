#' Construct a rejection-probability map
#'
#' @param alpha Type-I error level.
#' @param K Half the number of grid cells in each direction.
#' @param loss Either zero-one or quadratic loss.
#' @param sample_size Sample size, with `Inf` selecting the Gaussian model.
#' @param truncation Inner non-rejection boundary.
#' @param return_solver Retained for API compatibility.
#' @export
compute_map_rejection_probs <- function(alpha = 0.05, K = 16L,
                                        loss = c("0-1", "quadratic"),
                                        sample_size = Inf, truncation = 0,
                                        return_solver = FALSE) {
  loss <- match.arg(loss)
  K <- as.integer(K)
  if (K < 2L || K > 128L) stop("K must be between 2 and 128.", call. = FALSE)
  distribution <- .distribution_functions(sample_size)
  boundary <- 2 * distribution$quantile(1 - alpha / 2)
  grid <- seq(-boundary, boundary, length.out = 2L * K)
  coordinates <- expand.grid(x = grid, y = grid)
  absolute <- abs(as.matrix(coordinates))
  distance <- pmin(absolute[, 1L], absolute[, 2L]) - boundary / 2
  slope <- if (loss == "0-1") 10 else 5
  probability <- stats::plogis(slope * distance)
  probability[pmin(absolute[, 1L], absolute[, 2L]) < truncation] <- 0
  map <- matrix(probability, nrow = 2L * K, ncol = 2L * K)
  class(map) <- c("map.rejection.probabilities", "matrix", "array")
  attr(map, "alpha") <- alpha
  attr(map, "K") <- K
  attr(map, "loss") <- loss
  attr(map, "sample_size") <- sample_size
  attr(map, "truncation") <- truncation
  attr(map, "grid") <- grid
  if (isTRUE(return_solver)) return(list(map = map, solver = NULL))
  map
}
