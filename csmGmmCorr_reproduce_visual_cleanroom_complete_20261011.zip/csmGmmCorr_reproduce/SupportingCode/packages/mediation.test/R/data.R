#' Precomputed rejection-probability maps
#'
#' Nine maps are installed with the package for the combinations of loss,
#' level, truncation, and finite-sample calibration used by the reproduction
#' scripts. They are deterministic outputs of `compute_map_rejection_probs`.
NULL
