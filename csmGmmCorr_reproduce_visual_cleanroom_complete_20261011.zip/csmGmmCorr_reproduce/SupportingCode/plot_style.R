.paper_hue <- function(index, chroma = 100, luminance = 65) {
  grDevices::hcl(h = index, c = chroma, l = luminance)
}

METHOD_STYLE <- data.frame(
  method = c("penalized", "ML", "QCH", "adaFilter", "DEI", "MediationTest",
             "PCPathSafeguard", "sym", "JS-PC", "csmGmm", "csmGmm_cor", "csmGmm_pen"),
  label = c("Correlated csmGmm", "Correlated csmGmm (ML)", "QCH", "adaFilter",
            "DEI", "MediationTest", "PC path safeguard", "Symmetric statistics",
            "JS-PC", "csmGmm", "csmGmm with plug-in correlation", "Penalized csmGmm"),
  color = .paper_hue(c(15, 195, 105, 285, 60, 240, 330, 150, 30, 215, 250, 185)),
  linetype = c("solid", "22", "13", "44", "121412", "6222", "solid", "solid",
               "42", "31", "51", "73"),
  stringsAsFactors = FALSE
)

method_scales <- function(methods) {
  style <- METHOD_STYLE[match(methods, METHOD_STYLE$method), , drop = FALSE]
  if (anyNA(style$method)) stop("A requested method has no plotting style.", call. = FALSE)
  list(
    ggplot2::scale_color_manual(
      values = stats::setNames(style$color, style$label),
      breaks = style$label,
      name = "Method"
    ),
    ggplot2::scale_linetype_manual(
      values = stats::setNames(style$linetype, style$label),
      breaks = style$label,
      name = "Method"
    )
  )
}

TARGET_NAME <- c(pleiotropy = "Pleiotropy", replication = "Replication", mediation = "Mediation")
EFFECT_XLAB <- c(
  pleiotropy = "Effect magnitude",
  replication = "Minimum effect magnitude",
  mediation = "Minimum effect magnitude"
)

theme_paper <- function(base = 16) {
  cowplot::theme_cowplot() +
    ggplot2::theme(
      axis.title = ggplot2::element_text(size = 20),
      axis.text = ggplot2::element_text(size = base),
      legend.title = ggplot2::element_text(size = 20),
      legend.text = ggplot2::element_text(size = 18),
      legend.key.size = grid::unit(3, "lines")
    )
}

fdp_line <- function() {
  ggplot2::geom_hline(yintercept = 0.1, linetype = 2, color = "grey50")
}

fdp_top <- function(x) {
  maximum <- suppressWarnings(max(x, na.rm = TRUE))
  if (!is.finite(maximum)) return(0.5)
  max(0.5, ceiling(maximum * 10.5) / 10)
}

sim_panel <- function(z, y, methods, xlab, ylab, ylim = FALSE, sym = NULL) {
  values <- as.data.frame(z)
  values <- values[values$method %in% methods, , drop = FALSE]
  values$Method <- METHOD_STYLE$label[match(values$method, METHOD_STYLE$method)]
  active_methods <- methods

  plot <- ggplot2::ggplot(values, ggplot2::aes(x = x, y = .data[[y]], group = Method)) +
    ggplot2::geom_line(ggplot2::aes(color = Method, linetype = Method), linewidth = 1.2)

  if (!is.null(sym) && nrow(sym)) {
    symmetric <- as.data.frame(sym)
    symmetric$Method <- METHOD_STYLE$label[METHOD_STYLE$method == "sym"]
    plot <- plot +
      ggplot2::geom_line(
        data = symmetric,
        ggplot2::aes(color = Method, linetype = Method),
        linewidth = 1.2
      ) +
      ggplot2::geom_point(
        data = symmetric,
        ggplot2::aes(color = Method),
        size = 3,
        show.legend = FALSE
      )
    active_methods <- c(active_methods, "sym")
  }

  if (isTRUE(ylim)) plot <- plot + ggplot2::coord_cartesian(ylim = c(0, fdp_top(values[[y]])))
  plot +
    method_scales(active_methods) +
    ggplot2::scale_x_continuous(breaks = sort(unique(values$x))) +
    ggplot2::labs(x = xlab, y = ylab) +
    theme_paper()
}

legend_grob <- function(plot) {
  guide_index <- grep("guide-box", plot$layout$name)
  if (!length(guide_index)) stop("The plot does not contain a legend.", call. = FALSE)
  candidates <- plot$grobs[guide_index]
  nonempty <- which(!vapply(candidates, inherits, logical(1), what = "zeroGrob"))
  candidates[[nonempty[1L]]]
}

combine_panels <- function(panels, nrow, legend = 1L, rel = 0.08,
                           label_size = 22, ncol_legend = 4L) {
  grid <- cowplot::plot_grid(
    plotlist = lapply(panels, function(plot) plot + ggplot2::theme(legend.position = "none")),
    labels = LETTERS[seq_along(panels)],
    nrow = nrow,
    label_size = label_size
  )
  legend_plot <- panels[[legend]] +
    ggplot2::guides(
      color = ggplot2::guide_legend(ncol = ncol_legend, byrow = TRUE),
      linetype = ggplot2::guide_legend(ncol = ncol_legend, byrow = TRUE)
    ) +
    ggplot2::theme(legend.position = "bottom", legend.justification = "center")
  cowplot::plot_grid(grid, legend_grob(ggplot2::ggplotGrob(legend_plot)), ncol = 1,
                     rel_heights = c(1, rel))
}

legend_plot <- function(methods, points = "sym") {
  values <- data.frame(
    x = rep(1:2, times = length(methods)),
    y = 1,
    method = rep(methods, each = 2),
    stringsAsFactors = FALSE
  )
  values$Method <- METHOD_STYLE$label[match(values$method, METHOD_STYLE$method)]
  ggplot2::ggplot(values, ggplot2::aes(x, y, group = Method)) +
    ggplot2::geom_line(ggplot2::aes(color = Method, linetype = Method), linewidth = 1.2) +
    ggplot2::geom_point(
      data = values[values$method %in% points, , drop = FALSE],
      ggplot2::aes(color = Method),
      size = 3,
      show.legend = FALSE
    ) +
    method_scales(methods) +
    theme_paper()
}

PDF_DEVICE <- if (isTRUE(capabilities("cairo"))) grDevices::cairo_pdf else grDevices::pdf
SIGMA <- if (isTRUE(capabilities("cairo"))) "Σ" else "Sigma"
