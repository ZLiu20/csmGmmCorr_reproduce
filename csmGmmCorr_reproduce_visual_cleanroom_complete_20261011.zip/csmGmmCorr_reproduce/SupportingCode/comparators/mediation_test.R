.minimax_pair_p_R1 <- function(two_column_z) {
  value <- abs(as.matrix(two_column_z))
  lo <- pmin(value[, 1L], value[, 2L])
  hi <- pmax(value[, 1L], value[, 2L])
  upper <- stats::pnorm(hi, lower.tail = FALSE)
  delta <- stats::pnorm(lo) - stats::pnorm(-lo)
  ratio <- ifelse(delta > 0, floor(upper / delta), Inf)
  harmonic <- digamma(ratio + 1) - digamma(1)
  pmin(1, 2 * upper / (ratio + 1) + 2 * delta * harmonic)
}

run_mediation_test_R1 <- function(z, t_value, q_value) {
  z <- as.matrix(z)
  if (ncol(z) %% 2L != 0L) stop("Mediation needs an even K.", call. = FALSE)
  pairs <- matrix(seq_len(ncol(z)), ncol = 2L, byrow = TRUE)
  pair_p <- vapply(
    seq_len(nrow(pairs)),
    function(j) .minimax_pair_p_R1(z[, pairs[j, ], drop = FALSE]),
    numeric(nrow(z))
  )
  if (is.null(dim(pair_p))) pair_p <- matrix(pair_p, ncol = 1L)
  combined <- combine_mediation_target_pvalues_R1(z, pair_p, t_value)
  adjusted <- stats::p.adjust(combined$global, method = "BH")
  list(
    rejected = adjusted <= q_value,
    score = combined$global,
    rankingScoreType = "mediation_intersection_global_p",
    tuning = sprintf("sample_size=Inf;pathways=%d;support_r=%d;FDR=BH", nrow(pairs), as.integer(t_value) + 1L)
  )
}
