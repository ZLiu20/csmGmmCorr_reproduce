run_mediation_safeguard_R1 <- function(z, t_value, q_value) {
  z <- as.matrix(z)
  if (ncol(z) %% 2L != 0L) stop("Mediation needs an even K.", call. = FALSE)
  p <- two_sided_p_R1(z)
  pairs <- matrix(seq_len(ncol(z)), ncol = 2L, byrow = TRUE)
  pair_p <- vapply(
    seq_len(nrow(pairs)),
    function(j) pmax(p[, pairs[j, 1L]], p[, pairs[j, 2L]]),
    numeric(nrow(z))
  )
  if (is.null(dim(pair_p))) pair_p <- matrix(pair_p, ncol = 1L)
  combined <- combine_mediation_target_pvalues_R1(z, pair_p, t_value)
  adjusted <- stats::p.adjust(combined$global, method = "BH")
  list(
    rejected = adjusted <= q_value,
    score = combined$global,
    rankingScoreType = "parameter_free_mediation_safeguard_p",
    tuning = sprintf("support_r=%d;pathways=%d;FDR=BH", as.integer(t_value) + 1L, nrow(pairs))
  )
}
