.dei_pair_pvalue_R1 <- function(px, py) {
  px <- clamp_probability_R1(px)
  py <- clamp_probability_R1(py)
  low <- pmin(px, py)
  high <- pmax(px, py)
  ordering <- order(low)
  high_sorted <- high[ordering]
  estimate <- rep(1, length(low))
  previous <- 0
  location <- 1L
  for (i in seq_along(low)) {
    epsilon <- high_sorted[i]
    if (!is.finite(epsilon) || epsilon >= 0.4) break
    while (location <= length(low) && low[ordering[location]] <= epsilon) location <- location + 1L
    remaining <- location - 1L
    scale <- epsilon / max(1 - 2 * epsilon, .Machine$double.eps)
    current <- high_sorted[i] * scale * remaining / length(low)
    estimate[i] <- min(1, max(previous, current))
    previous <- estimate[i]
  }
  out <- rep(1, length(low))
  out[ordering] <- estimate
  clamp_probability_R1(out)
}

run_dei_mediation_R1 <- function(z, t_value, q_value) {
  z <- as.matrix(z)
  if (ncol(z) %% 2L != 0L) stop("Mediation needs an even K.", call. = FALSE)
  p <- two_sided_p_R1(z)
  pairs <- matrix(seq_len(ncol(z)), ncol = 2L, byrow = TRUE)
  pair_p <- vapply(
    seq_len(nrow(pairs)),
    function(j) .dei_pair_pvalue_R1(p[, pairs[j, 1L]], p[, pairs[j, 2L]]),
    numeric(nrow(z))
  )
  if (is.null(dim(pair_p))) pair_p <- matrix(pair_p, ncol = 1L)
  combined <- combine_mediation_target_pvalues_R1(z, pair_p, t_value)
  adjusted <- stats::p.adjust(combined$global, method = "BH")
  list(
    rejected = adjusted <= q_value,
    score = combined$global,
    rankingScoreType = "mediation_intersection_global_p",
    tuning = sprintf("pathways=%d;support_r=%d;FDR=BH", nrow(pairs), as.integer(t_value) + 1L)
  )
}
