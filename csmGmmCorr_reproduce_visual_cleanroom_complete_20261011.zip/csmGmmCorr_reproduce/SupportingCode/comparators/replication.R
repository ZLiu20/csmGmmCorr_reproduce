run_repfdr_replication_R1 <- function(z, t_value, q_value) {
  if (!requireNamespace("repfdr", quietly = TRUE)) stop("Package 'repfdr' is required.", call. = FALSE)
  z <- as.matrix(z)
  K <- ncol(z)
  binned <- repfdr::ztobins(z, n.association.status = 3, n.bins = 120,
                           plot.diagnostics = FALSE, trim.z = TRUE,
                           trim.z.upper = 8, trim.z.lower = -8)
  config <- as.matrix(repfdr::hconfigs(K, n.association.status = 3))
  active <- rowSums(config != 0)
  same_direction <- abs(rowSums(sign(config))) == active
  non_null <- which(active > as.integer(t_value) & same_direction)
  fit <- repfdr::repfdr(binned$binned.z, binned$binned.z.mat,
                        non.null = "user.defined", non.null.rows = non_null,
                        clusters.verbose = FALSE)
  fdr <- clamp_probability_R1(fit$mat[, "fdr"])
  list(rejected = fdr <= q_value, score = fdr, rankingScoreType = "local_fdr",
       tuning = sprintf("user_defined_replication;t=%d", as.integer(t_value)))
}

.partial_conjunction_one_sided_R1 <- function(p, rank) {
  ordered <- t(apply(p, 1L, sort))
  pmin(1, (ncol(p) - rank + 1L) * ordered[, rank])
}

run_dirpc_replication_R1 <- function(z, t_value, q_value) {
  z <- as.matrix(z)
  rank <- as.integer(t_value) + 1L
  positive <- stats::pnorm(-z)
  negative <- stats::pnorm(z)
  p_positive <- .partial_conjunction_one_sided_R1(positive, rank)
  p_negative <- .partial_conjunction_one_sided_R1(negative, rank)
  p <- pmin(1, 2 * pmin(p_positive, p_negative))
  adjusted <- stats::p.adjust(p, method = "BH")
  list(rejected = adjusted <= q_value, score = p, rankingScoreType = "p_value",
       tuning = sprintf("directional_PC;t=%d", as.integer(t_value)))
}
