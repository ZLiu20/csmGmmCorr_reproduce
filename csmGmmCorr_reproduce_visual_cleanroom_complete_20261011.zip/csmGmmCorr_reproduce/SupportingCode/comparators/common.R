clamp_probability_R1 <- function(x, replacement = 1) {
  value <- as.numeric(x)
  value[!is.finite(value)] <- replacement
  pmin(1, pmax(0, value))
}

two_sided_p_R1 <- function(z) {
  z <- as.matrix(z)
  p <- 2 * stats::pnorm(-abs(z))
  p[p < .Machine$double.xmin] <- .Machine$double.xmin
  p[p > 1 - .Machine$double.eps] <- 1 - .Machine$double.eps
  p
}

truth_for_comparison_R1 <- function(beta, analysis, t_value, pair_mat = NULL) {
  beta <- as.matrix(beta)
  support <- rowSums(beta != 0)
  t_value <- as.integer(t_value)
  if (analysis == "pleiotropy") return(support > t_value)
  if (analysis == "replication") {
    same_direction <- support == abs(rowSums(sign(beta)))
    return(support > t_value & same_direction)
  }
  if (analysis != "mediation") stop("Unsupported analysis: ", analysis, call. = FALSE)
  if (is.null(pair_mat)) {
    if (ncol(beta) %% 2L != 0L) stop("Mediation needs an even number of statistics.", call. = FALSE)
    pair_mat <- matrix(seq_len(ncol(beta)), ncol = 2L, byrow = TRUE)
  }
  complete <- vapply(
    seq_len(nrow(pair_mat)),
    function(j) rowSums(beta[, pair_mat[j, ], drop = FALSE] != 0) == 2L,
    logical(nrow(beta))
  )
  if (is.null(dim(complete))) complete <- matrix(complete, ncol = 1L)
  support > t_value & rowSums(complete) > 0L
}

score_comparison_decisions_R1 <- function(rejected, score, beta, analysis,
                                          t_value, pair_mat = NULL) {
  rejected <- as.logical(rejected)
  score <- clamp_probability_R1(score)
  beta <- as.matrix(beta)
  if (length(rejected) != nrow(beta) || length(score) != nrow(beta)) {
    stop("Decision, score, and truth dimensions do not agree.", call. = FALSE)
  }
  alternative <- truth_for_comparison_R1(beta, analysis, t_value, pair_mat)
  active <- rowSums(beta != 0)
  structural_null <- if (analysis == "mediation") {
    active > t_value & !alternative
  } else {
    rep(FALSE, nrow(beta))
  }
  true_positive <- sum(rejected & alternative)
  false_positive <- sum(rejected & !alternative)
  discoveries <- sum(rejected)
  n_alternative <- sum(alternative)
  list(
    summary = data.frame(
      nAlternative = n_alternative,
      nRej = discoveries,
      truePositive = true_positive,
      falsePositive = false_positive,
      structuralNullFalsePositive = sum(rejected & structural_null),
      FDP = if (discoveries) false_positive / discoveries else 0,
      Power = if (n_alternative) true_positive / n_alternative else 0,
      stringsAsFactors = FALSE
    ),
    rejected = rejected,
    score = score,
    truthAlternative = alternative
  )
}

combine_pathway_pvalues_R1 <- function(pair_pvalues, r = 1L) {
  p <- as.matrix(pair_pvalues)
  p[!is.finite(p)] <- 1
  p[] <- pmin(1, pmax(0, p))
  r <- as.integer(r)
  if (r < 1L || r > ncol(p)) stop("r must be between 1 and the number of pathways.", call. = FALSE)
  ordered <- t(apply(p, 1L, sort))
  pmin(1, (ncol(p) - r + 1L) * ordered[, r])
}

coordinate_partial_conjunction_p_R1 <- function(z, t_value) {
  p <- two_sided_p_R1(z)
  rank <- as.integer(t_value) + 1L
  if (rank < 1L || rank > ncol(p)) stop("t_value must be smaller than K.", call. = FALSE)
  ordered <- t(apply(p, 1L, sort))
  pmin(1, (ncol(p) - as.integer(t_value)) * ordered[, rank])
}

combine_any_pathway_pvalues_R1 <- function(pair_pvalues) {
  p <- as.matrix(pair_pvalues)
  p[!is.finite(p)] <- 1
  p[] <- pmin(1, pmax(0, p))
  pmin(1, ncol(p) * apply(p, 1L, min))
}

combine_mediation_target_pvalues_R1 <- function(z, pair_pvalues, t_value) {
  coordinate <- coordinate_partial_conjunction_p_R1(z, t_value)
  pathway <- combine_any_pathway_pvalues_R1(pair_pvalues)
  list(global = pmax(coordinate, pathway), coordinate = coordinate, pathway = pathway)
}
