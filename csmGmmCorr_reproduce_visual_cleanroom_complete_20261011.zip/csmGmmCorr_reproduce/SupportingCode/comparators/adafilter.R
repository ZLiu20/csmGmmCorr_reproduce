.adafilter_fallback_R1 <- function(p_matrix, r, alpha = 0.1) {
  p <- as.matrix(p_matrix)
  p[!is.finite(p)] <- NA_real_
  total <- nrow(p)
  available <- rowSums(!is.na(p))
  eligible <- which(available >= r)
  ans <- data.frame(
    decision = rep(FALSE, total), adjusted.p = rep(NA_real_, total),
    selection.p = rep(NA_real_, total), filter.p = rep(NA_real_, total),
    adj.number = rep(NA_real_, total)
  )
  if (!length(eligible)) return(ans)
  sorted <- t(apply(p[eligible, , drop = FALSE], 1L, sort, na.last = TRUE))
  n_available <- available[eligible]
  selection <- sorted[, 1L]
  filter <- sorted[, r] * (n_available - r + 1L)
  keep <- is.finite(selection) & is.finite(filter)
  rank_order <- order(selection, seq_along(selection))
  selected_sorted <- selection[rank_order]
  adjustment_number <- vapply(
    seq_along(selected_sorted),
    function(i) sum(filter <= selected_sorted[i], na.rm = TRUE),
    integer(1)
  )
  adjusted_sorted <- adjustment_number * selected_sorted / seq_along(selected_sorted)
  adjusted_sorted <- pmin(1, rev(cummin(rev(adjusted_sorted))))
  adjusted <- numeric(length(eligible))
  adjusted[rank_order] <- adjusted_sorted
  ans$decision[eligible] <- keep & adjusted <= alpha
  ans$adjusted.p[eligible] <- adjusted
  ans$selection.p[eligible] <- selection
  ans$filter.p[eligible] <- filter
  ans$adj.number[eligible] <- adjustment_number[order(rank_order)]
  ans
}

run_adafilter_pleiotropy_R1 <- function(z, t_value, q_value) {
  p <- two_sided_p_R1(z)
  r <- as.integer(t_value) + 1L
  result <- if (requireNamespace("adaFilter", quietly = TRUE)) {
    adaFilter::adaFilter(p.matrix = p, r = r, type.I.err = "FDR", alpha = q_value, fast = FALSE)
  } else {
    .adafilter_fallback_R1(p, r = r, alpha = q_value)
  }
  if (!is.data.frame(result) || nrow(result) != nrow(p)) stop("Invalid adaFilter output.", call. = FALSE)
  list(
    rejected = as.logical(result$decision %in% TRUE),
    score = clamp_probability_R1(result$adjusted.p),
    rankingScoreType = "adjusted_p",
    tuning = sprintf("r=%d;type=FDR", r)
  )
}
