run_qch_pleiotropy_R1 <- function(z, t_value, q_value, threads = 1L) {
  if (!requireNamespace("qch", quietly = TRUE)) stop("Package 'qch' is required.", call. = FALSE)
  p <- two_sided_p_R1(z)
  K <- ncol(p)
  at_least <- as.integer(t_value) + 1L
  h_config <- qch::GetHconfig(K)
  hl_config <- qch::GetHAtLeast(h_config, AtLeast = at_least)
  label <- paste0("AtLeast_", at_least)
  fit <- qch::qch.fit(
    pValMat = as.data.frame(p), Hconfig = h_config, copula = "gaussian",
    threads_nb = as.integer(threads), plotting = FALSE
  )
  tested <- qch::qch.test(
    res.qch.fit = fit, Hconfig = h_config, Hconfig.H1 = hl_config,
    Alpha = q_value, threads_nb = as.integer(threads)
  )
  list(
    rejected = as.logical(tested$Rejection[[label]]),
    score = clamp_probability_R1(tested$lFDR[[label]]),
    rankingScoreType = "local_fdr",
    tuning = sprintf("AtLeast=%d;copula=gaussian", at_least)
  )
}
