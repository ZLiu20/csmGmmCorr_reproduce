.csm_function <- function(name) {
  if (!requireNamespace("csmGmmCorr", quietly = TRUE)) {
    stop("Package 'csmGmmCorr' is required for the primary method.", call. = FALSE)
  }
  exports <- getNamespaceExports("csmGmmCorr")
  if (!name %in% exports) stop("csmGmmCorr does not export ", name, ". Install version 1.3.0.", call. = FALSE)
  getExportedValue("csmGmmCorr", name)
}

.target_from_scenario <- function(scenario) {
  switch(scenario, pl = "pleiotropy", rp = "replication", med = "mediation",
         stop("Unknown scenario: ", scenario, call. = FALSE))
}

.positive_definite_correlation <- function(value, floor = 0.05) {
  value <- as.matrix(value)
  value[!is.finite(value)] <- 0
  value <- (value + t(value)) / 2
  diag(value) <- 1
  decomposition <- eigen(value, symmetric = TRUE)
  decomposition$values <- pmax(decomposition$values, floor)
  repaired <- decomposition$vectors %*% (decomposition$values * t(decomposition$vectors))
  scale <- sqrt(diag(repaired))
  repaired <- repaired / tcrossprod(scale)
  diag(repaired) <- 1
  repaired
}

.safe_correlation <- function(z) {
  z <- as.matrix(z)
  candidate <- suppressWarnings(stats::cor(z))
  .positive_definite_correlation(candidate)
}

.decision_vector <- function(value, n) {
  if (is.list(value)) {
    for (field in c("rejected", "reject", "decision")) {
      if (!is.null(value[[field]])) return(rep_len(as.logical(value[[field]]), n))
    }
  }
  rep_len(as.logical(value), n)
}

.fit_with_capture <- function(z, specification, control) {
  fit_fun <- .csm_function("csm_fit")
  tryCatch(
    fit_fun(z, specification, starts = c("null", "shared"), control = control),
    error = function(error) structure(list(converged = FALSE, message = conditionMessage(error)),
                                     class = "csm_failed_fit")
  )
}

.fit_converged <- function(fit) {
  isTRUE(fit$converged) && !inherits(fit, "csm_failed_fit")
}

.fit_information <- function(fit, elapsed, generation_minutes, structure_label) {
  if (!.fit_converged(fit)) {
    return(list(
      converged = FALSE, iterations = NA_integer_, fit_min = elapsed / 60,
      gen_min = generation_minutes, sigma_min_eig = NA_real_, structure = structure_label,
      loglik = NA_real_, df = NA_real_
    ))
  }
  sigma <- fit$params$Sigma
  iterations <- if (!is.null(fit$runs)) sum(vapply(fit$runs, function(run) run$iterations %||% 0L, numeric(1))) else NA_integer_
  likelihood <- tryCatch(stats::logLik(fit), error = function(error) NA_real_)
  list(
    converged = TRUE,
    iterations = iterations,
    fit_min = elapsed / 60,
    gen_min = generation_minutes,
    sigma_min_eig = if (is.matrix(sigma)) min(eigen(sigma, symmetric = TRUE, only.values = TRUE)$values) else NA_real_,
    structure = structure_label,
    loglik = if (length(likelihood)) as.numeric(likelihood)[1L] else NA_real_,
    df = attr(likelihood, "df") %||% NA_real_
  )
}

`%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x

.result_row <- function(target, threshold, method, rejected, truth, z, score = NULL,
                        extra = list(), error = "") {
  rejected <- as.logical(rejected)
  truth <- as.logical(truth)
  discoveries <- sum(rejected, na.rm = TRUE)
  true_positive <- sum(rejected & truth, na.rm = TRUE)
  false_positive <- sum(rejected & !truth, na.rm = TRUE)
  base <- data.frame(
    target = target,
    t = as.integer(threshold),
    method = method,
    nAlt = sum(truth),
    R = discoveries,
    FP = false_positive,
    FDP = if (discoveries) false_positive / discoveries else 0,
    power = if (sum(truth)) true_positive / sum(truth) else NA_real_,
    incon_dec = incon_decision(z, rejected, target, threshold),
    incon_score = incon_score(z, score, target, threshold),
    error = error,
    stringsAsFactors = FALSE
  )
  if (length(extra)) base <- cbind(base, as.data.frame(extra, stringsAsFactors = FALSE))
  base
}

.variant_details <- function(type_name) {
  structure_label <- if (grepl("_[ABC](?:_|$)", type_name)) {
    sub(".*_([ABC])(?:_|$).*", "\\1", type_name)
  } else {
    "B"
  }
  components <- switch(structure_label, A = c(1L, 1L), B = c(2L, 1L), C = c(2L, 2L))
  penalized <- grepl("_pen(?:_|$)", type_name)
  lambda <- 30
  alpha <- 10
  matched <- regexec("L([0-9]+)A([0-9]+)", type_name)
  tokens <- regmatches(type_name, matched)[[1L]]
  if (length(tokens) == 3L) {
    lambda <- as.numeric(tokens[2L])
    alpha <- as.numeric(tokens[3L])
  }
  penalty_tag <- if (length(tokens) == 3L) sprintf("_L%sA%s", lambda, alpha) else ""
  method_label <- paste0(
    if (penalized) "penalized" else "ML",
    if (structure_label == "B") "" else paste0("_", structure_label),
    penalty_tag
  )
  if (grepl("_oracle(?:_|$)", type_name)) method_label <- "penalized_nullSigma"
  list(
    structure = structure_label,
    components = components,
    penalized = penalized,
    lambda = lambda,
    alpha = alpha,
    method = method_label
  )
}

.run_primary_fit <- function(train_z, test_z, target, threshold, type_name,
                             cores, max_iter, q_value, train_h = NULL) {
  details <- .variant_details(type_name)
  structure_fun <- .csm_function("csm_structure")
  spec_fun <- .csm_function("csm_spec")
  control_fun <- .csm_function("csm_control")
  structure <- structure_fun(ncol(train_z), details$components[1L], details$components[2L])
  specification <- spec_fun(ncol(train_z), M = structure, b_mu = 15)
  control_args <- list(
    cores = as.integer(cores), max_iter = as.integer(max_iter),
    penalty = if (details$penalized) details$lambda else 0,
    weight_penalty = if (details$penalized) details$alpha else 0
  )
  if (grepl("_oracle(?:_|$)", type_name)) {
    if (is.null(train_h) || nrow(train_h) != nrow(train_z)) {
      stop("Oracle-Sigma fitting requires the training configurations.", call. = FALSE)
    }
    null_rows <- which(rowSums(as.matrix(train_h) != 0L) == 0L)
    if (length(null_rows) <= ncol(train_z)) {
      stop("Too few all-null training features for oracle-Sigma fitting.", call. = FALSE)
    }
    empirical <- stats::cor(train_z[null_rows, , drop = FALSE])
    control_args$fix_sigma <- .csm_function("project_cor")(empirical, specification$kappa)
  }
  control <- do.call(control_fun, control_args)
  elapsed <- system.time(fit <- .fit_with_capture(train_z, specification, control))[["elapsed"]]
  list(fit = fit, elapsed = elapsed, details = details)
}

.score_primary_fit <- function(fit, z, target, threshold, q_value, cores,
                               method_label) {
  lfdr <- .csm_function("csm_lfdr")(fit, z, target, threshold, cores = as.integer(cores))
  step <- .csm_function("csm_stepup")(lfdr, q_value)
  raw_rejected <- .decision_vector(step, nrow(z))
  extrapolation <- tryCatch(
    .csm_function("csm_extrapolation")(fit, z, target, threshold, raw_rejected, q_value),
    error = function(error) NULL
  )
  flagged <- if (is.null(extrapolation)) NA_integer_ else
    sum(extrapolation$flag %in% TRUE, na.rm = TRUE)
  rows <- list(list(method = method_label, rejected = raw_rejected,
                    score = as.numeric(lfdr), flagged = flagged))
  adjustment <- tryCatch(.csm_function("csm_adjust")(z, lfdr, target, threshold, q_value),
                         error = function(error) NULL)
  if (!is.null(adjustment)) {
    adjusted_score <- adjustment$lfdr %||% adjustment$adjusted %||% adjustment
    rows[[length(rows) + 1L]] <- list(
      method = paste0(method_label, "_adjusted"),
      rejected = .decision_vector(adjustment$rejected %||% adjusted_score <= q_value, nrow(z)),
      score = as.numeric(adjusted_score), flagged = NA_integer_
    )
  }
  rows
}

.run_fixed_sigma_comparison <- function(train_z, test_z, target, threshold,
                                        cores, max_iter, q_value,
                                        train_h = NULL) {
  structure <- .csm_function("csm_structure")(ncol(train_z), 2L, 1L)
  specification <- .csm_function("csm_spec")(ncol(train_z), M = structure, b_mu = 15)
  null_rows <- integer(0)
  if (!is.null(train_h)) {
    train_h <- as.matrix(train_h)
    if (nrow(train_h) == nrow(train_z)) {
      null_rows <- which(rowSums(train_h != 0) == 0L)
    }
  }
  if (length(null_rows) < max(20L, ncol(train_z) + 1L)) {
    radius <- rowSums(train_z^2)
    null_rows <- which(radius <= stats::quantile(radius, 0.2, na.rm = TRUE))
  }
  sigma_plugin <- .safe_correlation(train_z[null_rows, , drop = FALSE])
  sigma_plugin <- tryCatch(
    .csm_function("project_cor")(stats::cor(train_z[null_rows, , drop = FALSE]), specification$kappa),
    error = function(error) sigma_plugin
  )
  variants <- list(
    csmGmm = list(sigma = TRUE, use_defaults = FALSE),
    csmGmm_cor = list(sigma = sigma_plugin, use_defaults = FALSE),
    csmGmm_pen = list(sigma = TRUE, use_defaults = TRUE)
  )
  out <- vector("list", length(variants))
  for (i in seq_along(variants)) {
    label <- names(variants)[i]
    args <- list(cores = as.integer(cores), max_iter = as.integer(max_iter),
                 fix_sigma = variants[[i]]$sigma)
    if (!variants[[i]]$use_defaults) {
      args$penalty <- 0
      args$weight_penalty <- 0
    }
    control <- do.call(.csm_function("csm_control"), args)
    elapsed <- system.time(fit <- .fit_with_capture(train_z, specification, control))[["elapsed"]]
    out[[i]] <- list(label = label, fit = fit, elapsed = elapsed, structure = "B")
  }
  out
}

run_sim_task <- function(array, aID, root = here::here()) {
  specification <- sim_array(array)
  aID <- as.integer(aID)
  if (aID < 1L || aID > nrow(specification$tasks)) stop("Array index is outside the task table.", call. = FALSE)
  task <- specification$tasks[aID, , drop = FALSE]
  study <- specification$study
  scenario <- specification$scen
  K <- task$K
  threshold_data <- task$t
  q_value <- 0.1
  N <- as.integer(Sys.getenv("SIM_N", "100000"))
  max_iter <- as.integer(Sys.getenv("MAX_ITER", "1500"))
  cores <- as.integer(Sys.getenv("LSB_DJOB_NUMPROC", "1"))
  output_root <- if (N == 100000L) "output" else "output_smoke"
  output_dir <- file.path(root, output_root, study, specification$type)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

  target <- .target_from_scenario(scenario)
  score_thresholds <- if (scenario == "med") threshold_data else 1:2
  design <- design_table(if (study == "split") "main" else study, scenario)
  design_row <- design[match(task$design, design$id), , drop = FALSE]

  common_metadata <- function(rep, generation_minutes) {
    data.frame(
      design = design_row$design, axis = design_row$axis, x = design_row$x,
      effect = design_row$effect %||% NA_real_, m = design_row$m,
      tau1 = design_row$tau1, a_min = design_row$a_min,
      rho = design_row$rho, K = K, rep = rep,
      stringsAsFactors = FALSE
    )
  }

  one_replicate <- function(rep) {
    total_start <- proc.time()[["elapsed"]]
    output_file <- file.path(output_dir, sprintf("%s_K%02d_t%d_rep%03d.csv", design_row$design, K, threshold_data, rep))
    if (file.exists(output_file)) return(invisible(output_file))
    generation_time <- system.time(dataset <- make_dataset(
      scenario, task$design, K, threshold_data, rep, N = N, study = study
    ))[["elapsed"]] / 60
    train_z <- dataset$train$z
    test_z <- dataset$test$z
    truth_matrix <- dataset$test$H
    metadata <- common_metadata(rep, generation_time)
    results <- list()

    append_result <- function(threshold, method, rejected, score, extra = list(), error = "") {
      truth <- truth_alt(truth_matrix, target, threshold)
      if (isTRUE(design_row$ld > 0)) {
        local_truth <- truth_alt_locus(truth, w = 5L)
        local_discoveries <- sum(rejected, na.rm = TRUE)
        extra$FP_loc <- sum(rejected & !local_truth, na.rm = TRUE)
        extra$FDP_loc <- if (local_discoveries) extra$FP_loc / local_discoveries else 0
        extra$power_loc <- if (sum(local_truth)) {
          sum(rejected & local_truth, na.rm = TRUE) / sum(local_truth)
        } else {
          NA_real_
        }
        for (window in c(1L, 2L, 5L)) {
          union_truth <- truth_alt(union_config(truth_matrix, w = window), target, threshold)
          extra[[paste0("FDP_union_", window)]] <- if (local_discoveries) {
            sum(rejected & !union_truth, na.rm = TRUE) / local_discoveries
          } else {
            0
          }
          extra[[paste0("power_union_", window)]] <- if (sum(union_truth)) {
            sum(rejected & union_truth, na.rm = TRUE) / sum(union_truth)
          } else {
            NA_real_
          }
        }
      }
      results[[length(results) + 1L]] <<- cbind(
        .result_row(target, threshold, method, rejected, truth, test_z, score, extra, error),
        metadata
      )
    }

    if (grepl("^ours_", specification$type)) {
      primary <- .run_primary_fit(train_z, test_z, target, threshold_data, specification$type,
                                  cores, max_iter, q_value, train_h = dataset$train$H)
      fit_info <- .fit_information(primary$fit, primary$elapsed, generation_time, primary$details$structure)
      if (!.fit_converged(primary$fit)) {
        for (threshold in score_thresholds) append_result(
          threshold, primary$details$method, rep(FALSE, N), rep(NA_real_, N), fit_info,
          primary$fit$message %||% "fit did not converge"
        )
      } else {
        for (threshold in score_thresholds) {
          scored <- .score_primary_fit(
            primary$fit, test_z, target, threshold, q_value, cores,
            primary$details$method
          )
          for (entry in scored) append_result(
            threshold, entry$method, entry$rejected, entry$score,
            c(fit_info, list(flagged = entry$flagged))
          )
        }
      }
    } else if (grepl("_csm$", specification$type)) {
      fits <- .run_fixed_sigma_comparison(
        train_z, test_z, target, threshold_data,
        cores, max_iter, q_value, train_h = dataset$train$H
      )
      for (entry in fits) {
        info <- .fit_information(entry$fit, entry$elapsed, generation_time, entry$structure)
        for (threshold in score_thresholds) {
          if (!.fit_converged(entry$fit)) {
            append_result(threshold, entry$label, rep(FALSE, N), rep(NA_real_, N), info,
                          entry$fit$message %||% "fit did not converge")
          } else {
            lfdr <- .csm_function("csm_lfdr")(entry$fit, test_z, target, threshold, cores = cores)
            rejected <- .decision_vector(.csm_function("csm_stepup")(lfdr, q_value), N)
            append_result(threshold, entry$label, rejected, lfdr, info)
          }
        }
      }
    } else {
      methods <- switch(
        specification$type,
        comp_pl = list(QCH = run_qch_pleiotropy_R1, adaFilter = run_adafilter_pleiotropy_R1),
        comp_rp = list(repfdr = run_repfdr_replication_R1, DirectionalPC = run_dirpc_replication_R1),
        comp_med = list(DEI = run_dei_mediation_R1, MediationTest = run_mediation_test_R1,
                        PCPathSafeguard = run_mediation_safeguard_R1),
        stop("Unknown simulation type: ", specification$type, call. = FALSE)
      )
      for (threshold in score_thresholds) {
        for (method_name in names(methods)) {
          value <- tryCatch(methods[[method_name]](test_z, threshold, q_value), error = identity)
          if (inherits(value, "error")) {
            append_result(threshold, method_name, rep(FALSE, N), rep(NA_real_, N),
                          list(converged = FALSE), conditionMessage(value))
          } else {
            append_result(threshold, method_name, value$rejected, value$score,
                          list(converged = TRUE, tuning = value$tuning %||% ""))
          }
        }
      }
    }

    output <- as.data.frame(data.table::rbindlist(results, fill = TRUE, use.names = TRUE))
    output$total_min <- (proc.time()[["elapsed"]] - total_start) / 60
    utils::write.csv(output, output_file, row.names = FALSE)
    invisible(output_file)
  }

  replicates <- seq.int(task$rep_from, task$rep_to)
  limit <- as.integer(Sys.getenv("SIM_MAX_REPS", "0"))
  if (limit > 0L) replicates <- head(replicates, limit)
  invisible(vapply(replicates, one_replicate, character(1)))
}
