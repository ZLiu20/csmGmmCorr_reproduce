.require_data_table <- function() {
  if (!requireNamespace("data.table", quietly = TRUE)) {
    stop("Package 'data.table' is required for simulation summaries.", call. = FALSE)
  }
}

read_sim <- function(folder, study, refresh = FALSE, root = here::here()) {
  .require_data_table()
  output_root <- file.path(root, folder, "output")
  cache <- file.path(output_root, sprintf("all_results_%s.csv.gz", study))
  if (file.exists(cache) && !refresh) return(data.table::fread(cache))

  result_files <- list.files(
    file.path(output_root, study),
    pattern = "[.]csv$",
    recursive = TRUE,
    full.names = TRUE
  )
  if (!length(result_files)) {
    stop("No simulation results found under ", file.path(output_root, study), call. = FALSE)
  }
  pieces <- lapply(result_files, data.table::fread)
  combined <- data.table::rbindlist(pieces, fill = TRUE, use.names = TRUE)
  data.table::fwrite(combined, cache)
  combined
}

sim_progress <- function(folder = NULL, root = here::here()) {
  .require_data_table()
  arrays <- sim_arrays()
  if (!is.null(folder)) {
    arrays <- arrays[vapply(arrays, function(spec) identical(spec$folder, folder), logical(1))]
  }
  records <- lapply(names(arrays), function(name) {
    spec <- arrays[[name]]
    tasks <- sim_task_table(spec$scen, spec$designs, spec$reps)
    directory <- file.path(root, spec$folder, "output", spec$study, spec$type)
    data.frame(
      array = name,
      folder = spec$folder,
      study = spec$study,
      type = spec$type,
      expected = sum(tasks$rep_to - tasks$rep_from + 1L),
      found = length(list.files(directory, pattern = "[.]csv$")),
      stringsAsFactors = FALSE
    )
  })
  data.table::rbindlist(records, fill = TRUE)
}

design_means <- function(d, by = c("target", "K", "t", "method", "design", "axis", "x")) {
  .require_data_table()
  values <- data.table::as.data.table(d)
  values[, .(
    FDP = mean(FDP, na.rm = TRUE),
    FDP_se = stats::sd(FDP, na.rm = TRUE) / sqrt(sum(is.finite(FDP))),
    n = .N,
    power = mean(power, na.rm = TRUE),
    R = mean(R, na.rm = TRUE),
    incon_dec = mean(incon_dec, na.rm = TRUE),
    incon_score = mean(incon_score, na.rm = TRUE)
  ), by = by]
}

overall_means <- function(d, by = c("target", "K", "t", "method")) {
  .require_data_table()
  values <- data.table::as.data.table(d)
  values[, .(
    FDP = mean(FDP, na.rm = TRUE),
    FDPmax = max(FDP, na.rm = TRUE),
    power = mean(power, na.rm = TRUE),
    ndes = .N,
    incon_dec = mean(incon_dec, na.rm = TRUE),
    incon_score = mean(incon_score, na.rm = TRUE)
  ), by = by]
}

three_designs <- function(d) {
  values <- data.table::as.data.table(d)
  values[
    design %in% c("effect_01", "effect_05") |
      (scen != "med" & design == "tau1_002") |
      (scen == "med" & design == "tau1_004")
  ]
}

f3 <- function(x, digits = 3L) {
  ifelse(is.na(x), "--", formatC(x, format = "f", digits = digits))
}

fcomma <- function(x) {
  ifelse(is.na(x), "--", formatC(x, format = "d", big.mark = ","))
}

tex_escape <- function(x) {
  gsub("_", "\\\\_", x, fixed = TRUE)
}

write_tex <- function(lines, file) {
  writeLines(lines, con = file, useBytes = TRUE)
  message("Wrote ", file)
  invisible(file)
}

SOURCE_ROWS <- list(
  c("pen", "Correlated csmGmm (penalized)"),
  c(NA, "\\textit{Estimation}"),
  c("ML", "Correlated csmGmm, maximum likelihood"),
  c("csm", "csmGmm ($\\Sigma=I$), maximum likelihood"),
  c("csm_cor", "csmGmm with plug-in $\\Sigma$, maximum likelihood"),
  c("csm_pen", "csmGmm ($\\Sigma=I$), penalized"),
  c("split", "Correlated csmGmm, independent test set"),
  c(NA, "\\textit{Data-generating process}"),
  c("sym", "Symmetric statistics"),
  c("quant", "Quantitative outcomes"),
  c("exch", "Exchangeable correlation 0.4"),
  c("ld", "Linkage disequilibrium (variant level)"),
  c(NA, "\\textit{Strong correlation}"),
  c("rho08", "Correlated csmGmm"),
  c("rho08_oracle", "Correlated csmGmm with null correlation supplied"),
  c("rho08_csm", "csmGmm ($\\Sigma=I$), maximum likelihood")
)

sources_means <- function(value = "FDP") {
  optional <- function(folder, study) {
    tryCatch(read_sim(folder, study), error = function(e) NULL)
  }
  main <- optional("Fig2", "main")
  symmetric <- optional("Fig2", "sym")
  table2_main <- optional("Tab2", "main")
  rho <- optional("Fig3", "rho")
  oracle <- optional("Tab2", "rho")

  average_method <- function(data, method) {
    if (is.null(data)) return(NULL)
    selected <- data.table::as.data.table(data)[method == ..method]
    if (!nrow(selected)) return(NULL)
    per_design <- selected[, .(v = mean(get(value), na.rm = TRUE)), by = .(target, K, t, design)]
    per_design[, .(v = mean(v, na.rm = TRUE)), by = .(target, K, t)]
  }

  trim_designs <- function(data) if (is.null(data)) NULL else three_designs(data)
  rho_at_point_eight <- function(data) {
    if (is.null(data)) NULL else data.table::as.data.table(data)[design == "rho_080"]
  }

  parts <- list(
    pen = average_method(trim_designs(main), "penalized"),
    ML = average_method(trim_designs(main), "ML"),
    csm = average_method(trim_designs(table2_main), "csmGmm"),
    csm_cor = average_method(trim_designs(table2_main), "csmGmm_cor"),
    csm_pen = average_method(trim_designs(table2_main), "csmGmm_pen"),
    split = average_method(trim_designs(optional("Tab2", "split")), "penalized"),
    sym = average_method(trim_designs(symmetric), "penalized"),
    quant = average_method(trim_designs(optional("Tab2", "quant")), "penalized"),
    exch = average_method(trim_designs(optional("Tab2", "exch")), "penalized"),
    ld = average_method(trim_designs(optional("Tab2", "ld")), "penalized"),
    rho08 = average_method(rho_at_point_eight(rho), "penalized"),
    rho08_oracle = average_method(rho_at_point_eight(oracle), "penalized_nullSigma"),
    rho08_csm = average_method(rho_at_point_eight(rho), "csmGmm")
  )

  available <- Filter(Negate(is.null), parts)
  if (!length(available)) {
    merged <- data.table::data.table(
      target = character(),
      K = integer(),
      t = integer()
    )
  } else {
    merged <- unique(data.table::rbindlist(available, fill = TRUE)[, .(target, K, t)])
  }
  for (name in names(parts)) {
    part <- parts[[name]]
    if (is.null(part)) {
      merged[, (name) := NA_real_]
    } else {
      data.table::setnames(part, "v", name)
      merged <- merge(merged, part, by = c("target", "K", "t"), all.x = TRUE)
    }
  }
  data.table::setorder(merged, target, K, t)
  merged
}

sources_tex <- function(summary_table, t0, label, caption) {
  lines <- c(
    "\\begin{table}[!htbp]",
    sprintf("\\caption{%s}\\label{%s}", caption, label),
    "\\small",
    "\\begin{tabular}{l cc cc cc}",
    "\\toprule",
    " & \\multicolumn{2}{c}{Pleiotropy} & \\multicolumn{2}{c}{Replication} & \\multicolumn{2}{c}{Mediation} \\\\",
    "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}",
    " & $K=4$ & $K=6$ & $K=4$ & $K=6$ & $K=4$ & $K=6$ \\\\",
    "\\midrule"
  )
  for (row in SOURCE_ROWS) {
    key <- row[1L]
    title <- row[2L]
    if (is.na(key)) {
      lines <- c(lines, sprintf("\\multicolumn{7}{l}{%s} \\\\", title))
      next
    }
    cells <- unlist(lapply(c("pleiotropy", "replication", "mediation"), function(target_value) {
      vapply(c(4L, 6L), function(K_value) {
        rows <- summary_table[
          target == target_value & K == K_value & t == t0
        ]
        value <- if (key %in% names(rows)) rows[[key]] else NA_real_
        f3(if (length(value)) value[1L] else NA_real_)
      }, character(1))
    }))
    lines <- c(lines, paste(c(title, cells), collapse = " & "), "\\\\")
  }
  c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}")
}
