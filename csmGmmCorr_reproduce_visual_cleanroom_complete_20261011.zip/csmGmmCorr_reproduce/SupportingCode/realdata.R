RD_ANALYSES <- list(
  glgc_replication = list(
    target = "replication", prep = "glgc_replication",
    cols = c("EUR_female", "EUR_male", "EAS_female", "EAS_male", "AFR_female", "AFR_male"),
    holdout = c("HIS_female", "HIS_male", "SAS_female", "SAS_male")
  ),
  ukb_pleiotropy = list(
    target = "pleiotropy", prep = "ukb_pleiotropy",
    cols = c("BMI", "SBP", "TG", "HDL", "HbA1c")
  ),
  glgc_pleiotropy = list(
    target = "pleiotropy", prep = "glgc_pleiotropy",
    cols = c("HDL", "LDL", "TC", "logTG", "nonHDL")
  )
)

RD_JOBS <- data.frame(
  analysis = c(rep("glgc_replication", 5L), rep("ukb_pleiotropy", 4L), rep("glgc_pleiotropy", 4L)),
  variant = c("main", "indep", "robust", "main", "indep",
              "main", "indep", "robust", "main",
              "main", "indep", "robust", "main"),
  a_mu = c(0.5, 0.5, 0.5, 1.5, 1.5, 0.5, 0.5, 0.5, 1.5, 0.5, 0.5, 0.5, 1.5),
  stringsAsFactors = FALSE
)

rd_label <- function(variant, a_mu) {
  paste0(variant, if (a_mu != 0.5) sprintf("_amu%g", 10 * a_mu) else "")
}

freadgz <- function(file, ...) {
  if (grepl("[.](gz|bgz)$", file)) {
    data.table::fread(cmd = paste("gzip -cd", shQuote(file)), ...)
  } else {
    data.table::fread(file, ...)
  }
}

say <- function(...) {
  cat(format(Sys.time(), "%H:%M:%S"), sprintf(...), "\n")
  flush.console()
}

capz <- function(z, cap) {
  storage.mode(z) <- "double"
  z[z > cap] <- cap
  z[z < -cap] <- -cap
  z
}

rd_load <- function(analysis, cap = 12, smoke = FALSE, extra = NULL) {
  config <- RD_ANALYSES[[analysis]]
  if (is.null(config)) stop("Unknown real-data analysis: ", analysis, call. = FALSE)
  directory <- here::here("Data", "prepared", config$prep)
  if (!file.exists(file.path(directory, "fit_sample.tsv.gz"))) stop("Prepared data not found: ", directory, call. = FALSE)
  fit <- freadgz(file.path(directory, "fit_sample.tsv.gz"), select = c("variant_id", config$cols))
  if (smoke && nrow(fit) > 20000L) {
    set.seed(1)
    fit <- fit[sort(sample.int(nrow(fit), 20000L))]
  }
  z_fit <- capz(as.matrix(fit[, config$cols, with = FALSE]), cap)
  manifest <- data.table::fread(file.path(directory, "chromosome_manifest.tsv"))
  if (smoke) manifest <- manifest[seq_len(min(1L, nrow(manifest)))]
  pieces <- lapply(seq_len(nrow(manifest)), function(i) {
    path <- file.path(directory, basename(manifest$path[i]))
    value <- freadgz(path, select = c("variant_id", "chr", "pos_b37", config$cols, extra))
    if (nrow(value) != manifest$n_rows[i]) stop("Chromosome row count mismatch: ", path, call. = FALSE)
    value[!duplicated(variant_id)]
  })
  all <- data.table::rbindlist(pieces, fill = TRUE)
  z <- capz(as.matrix(all[, config$cols, with = FALSE]), cap)
  info <- data.table::data.table(variant_id = all$variant_id, chr = as.character(all$chr), pos = all$pos_b37)
  if (length(extra)) info <- cbind(info, all[, extra, with = FALSE])
  list(Zfit = z_fit, Z = z, info = info,
       n_fit_excluded = sum(manifest$n_rows) - nrow(all))
}

robust_cor <- function(z) {
  z <- as.matrix(z)
  scale_iqr <- function(x) diff(stats::quantile(x, c(0.25, 0.75), na.rm = TRUE, names = FALSE)) / 1.349
  K <- ncol(z)
  result <- diag(K)
  if (K > 1L) for (i in seq_len(K - 1L)) for (j in (i + 1L):K) {
    a <- z[, i] / scale_iqr(z[, i])
    b <- z[, j] / scale_iqr(z[, j])
    value <- (scale_iqr(a + b)^2 - scale_iqr(a - b)^2) /
      (scale_iqr(a + b)^2 + scale_iqr(a - b)^2)
    result[i, j] <- result[j, i] <- value
  }
  dimnames(result) <- list(colnames(z), colnames(z))
  result
}

project_cor <- function(value, kappa = 0.05, margin = 1e-3) {
  value <- as.matrix(value)
  for (iteration in seq_len(100L)) {
    decomposition <- eigen((value + t(value)) / 2, symmetric = TRUE)
    if (min(decomposition$values) >= kappa + margin / 2) break
    value <- decomposition$vectors %*% (pmax(decomposition$values, kappa + margin) * t(decomposition$vectors))
    value <- stats::cov2cor(value)
  }
  value <- (value + t(value)) / 2
  diag(value) <- 1
  value
}

reference_cors <- function(z) {
  central <- rowSums(abs(z) < 2) == ncol(z)
  list(
    pearson = stats::cor(z),
    pearson_abs_lt2 = stats::cor(z[central, , drop = FALSE]),
    robust = robust_cor(z),
    iqr_sd = apply(z, 2L, function(x) diff(stats::quantile(x, c(.25, .75), na.rm = TRUE)) / 1.349)
  )
}

.target_mode <- function(target) if (target == "replication") 1L else 0L

rd_majorant <- function(z, score, target, t, leaf = 32L) {
  .Call("rd_majorant", z, as.double(score), .target_mode(target), as.integer(t), as.integer(leaf))
}

rd_incon_dec <- function(z, rejected, target, t, leaf = 32L) {
  .Call("rd_incon_dec", z, as.logical(rejected), .target_mode(target), as.integer(t), as.integer(leaf))
}

clump_leads <- function(chr, pos, score, selected, win = 5e5) {
  index <- which(selected)
  if (!length(index)) return(integer())
  index <- index[order(score[index], pos[index])]
  positions <- list()
  keep <- integer()
  for (i in index) {
    key <- as.character(chr[i])
    prior <- positions[[key]]
    if (length(prior) && any(abs(pos[i] - prior) <= win)) next
    positions[[key]] <- sort(c(prior, pos[i]))
    keep <- c(keep, i)
  }
  keep
}

clump <- function(chr, pos, score, selected, win = 5e5) {
  length(clump_leads(chr, pos, score, selected, win))
}

.stepup_parts <- function(value, n) {
  if (is.list(value)) {
    list(
      rejected = .decision_vector(value, n),
      cutoff = value$cutoff %||% NA_real_,
      average = value$average %||% NA_real_,
      n_rejected = value$n_rejected %||% sum(.decision_vector(value, n))
    )
  } else {
    rejected <- .decision_vector(value, n)
    list(rejected = rejected, cutoff = NA_real_, average = NA_real_, n_rejected = sum(rejected))
  }
}

.write_tsv <- function(value, file) {
  data.table::fwrite(value, file, sep = "\t")
}

.matrix_long <- function(matrix, analysis, variant, label) {
  index <- which(upper.tri(matrix), arr.ind = TRUE)
  data.table::data.table(
    analysis = analysis, variant = variant, what = label,
    stat1 = colnames(matrix)[index[, 1L]], stat2 = colnames(matrix)[index[, 2L]],
    value = matrix[index]
  )
}

run_realdata <- function(analysis, variant, a_mu = 0.5,
                         out_root = here::here("Fig4", "output"),
                         cores = as.integer(Sys.getenv("LSB_DJOB_NUMPROC", "8")),
                         q = 0.1, cap = 12, thresholds = 1:2,
                         smoke = Sys.getenv("SMOKE", "0") == "1") {
  config <- RD_ANALYSES[[analysis]]
  stopifnot(!is.null(config), variant %in% c("main", "indep", "robust"))
  label <- rd_label(variant, a_mu)
  max_iter <- if (smoke) 300L else 5000L
  output <- file.path(if (smoke) sub("output$", "output_smoke", out_root) else out_root,
                      paste0(analysis, "_", label))
  dir.create(output, recursive = TRUE, showWarnings = FALSE)
  if (file.exists(file.path(output, "DONE")) && Sys.getenv("RERUN", "0") != "1") return(invisible(output))
  data <- rd_load(analysis, cap, smoke)
  reference <- reference_cors(data$Zfit)
  fixed_sigma <- switch(variant, main = FALSE, indep = diag(ncol(data$Zfit)),
                        robust = project_cor(reference$robust, 0.05))
  specification <- .csm_function("csm_spec")(
    ncol(data$Zfit), M = .csm_function("csm_structure")(ncol(data$Zfit), 2L, 1L),
    a_mu = a_mu, b_mu = 15
  )
  control <- .csm_function("csm_control")(
    max_iter = max_iter, penalty = 30, weight_penalty = 10,
    fix_sigma = fixed_sigma, cores = cores
  )
  start <- proc.time()[3L]
  fit <- .csm_function("csm_fit")(data$Zfit, specification,
                                   starts = c("null", "shared"), control = control)
  fit_minutes <- (proc.time()[3L] - start) / 60
  saveRDS(fit, file.path(output, "fit.rds"))
  if (!is.null(fit$runs)) .write_tsv(data.table::rbindlist(fit$runs, fill = TRUE), file.path(output, "fit_runs.tsv"))
  fitted_sigma <- fit$params$Sigma %||% matrix(NA_real_, ncol(data$Zfit), ncol(data$Zfit))
  sigma_table <- data.table::rbindlist(list(
    .matrix_long(fitted_sigma, analysis, label, "fitted_Sigma"),
    .matrix_long(reference$pearson, analysis, label, "pearson"),
    .matrix_long(reference$pearson_abs_lt2, analysis, label, "pearson_abs_lt2"),
    .matrix_long(reference$robust, analysis, label, "robust")
  ))
  .write_tsv(sigma_table, file.path(output, "sigma.tsv"))
  .write_tsv(data.table::data.table(analysis = analysis, stat = names(reference$iqr_sd), iqr_sd = reference$iqr_sd),
             file.path(output, "iqr_sd.tsv"))

  rows <- list()
  plot_sample <- sort(sample.int(nrow(data$Z), min(nrow(data$Z), 200000L)))
  plot_data <- cbind(data$info[plot_sample], data.table::as.data.table(data$Z[plot_sample, , drop = FALSE]))
  for (threshold in thresholds) {
    if (!isTRUE(fit$converged)) break
    lfdr <- .csm_function("csm_lfdr")(fit, data$Z, config$target, threshold, cores = cores)
    raw <- .stepup_parts(.csm_function("csm_stepup")(lfdr, q), nrow(data$Z))
    adjusted_lfdr <- rd_majorant(data$Z, lfdr, config$target, threshold)
    adjusted <- .stepup_parts(.csm_function("csm_stepup")(adjusted_lfdr, q), nrow(data$Z))
    raw_incon <- rd_incon_dec(data$Z, raw$rejected, config$target, threshold)
    adjusted_incon <- rd_incon_dec(data$Z, adjusted$rejected, config$target, threshold)
    extrapolated <- if (raw$n_rejected > 0L) {
      tryCatch(.csm_function("csm_extrapolation")(fit, data$Z, config$target, threshold,
                                                   rejected = raw$rejected, cutoff = raw$cutoff)$flag,
               error = function(error) rep(NA, nrow(data$Z)))
    } else rep(NA, nrow(data$Z))
    both <- raw$rejected & adjusted$rejected
    rows[[length(rows) + 1L]] <- data.table::data.table(
      analysis = analysis, variant = label, a_mu = a_mu, target = config$target,
      K = ncol(data$Z), t = threshold, q = q, n_fit = nrow(data$Zfit), n_test = nrow(data$Z),
      converged = fit$converged, selected_start = fit$selected %||% NA_character_,
      iterations = if (!is.null(fit$runs)) sum(vapply(fit$runs, function(x) x$iterations %||% 0, numeric(1))) else NA_real_,
      loglik = fit$loglik %||% NA_real_, fit_minutes = round(fit_minutes, 2),
      R_raw = raw$n_rejected, R_adj = adjusted$n_rejected, R_both = sum(both),
      frac_raw = raw$n_rejected / nrow(data$Z), cutoff_raw = raw$cutoff, avg_lfdr_raw = raw$average,
      loci_raw = clump(data$info$chr, data$info$pos, lfdr, raw$rejected),
      loci_adj = clump(data$info$chr, data$info$pos, adjusted_lfdr, adjusted$rejected),
      n_adjusted_up = sum(adjusted_lfdr > lfdr + 1e-12),
      incon_score_raw = incon_score(data$Z, lfdr, config$target, threshold),
      incon_score_adj = incon_score(data$Z, adjusted_lfdr, config$target, threshold),
      incon_dec_raw = sum(raw_incon), incon_dec_adj = sum(adjusted_incon),
      extrap_flags = sum(extrapolated, na.rm = TRUE)
    )
    selected <- raw$rejected | adjusted$rejected | raw_incon
    discoveries <- cbind(
      data$info[selected], data.table::as.data.table(data$Z[selected, , drop = FALSE]),
      data.table::data.table(lfdr = lfdr[selected], lfdr_adj = adjusted_lfdr[selected],
                             rej_raw = raw$rejected[selected], rej_adj = adjusted$rejected[selected],
                             incon_dec = raw_incon[selected], extrap = extrapolated[selected])
    )
    .write_tsv(discoveries, file.path(output, sprintf("discoveries_t%d.tsv.gz", threshold)))
    plot_data[[paste0("lfdr_t", threshold)]] <- lfdr[plot_sample]
    plot_data[[paste0("lfdr_adj_t", threshold)]] <- adjusted_lfdr[plot_sample]
    rm(lfdr, adjusted_lfdr, raw_incon, adjusted_incon, extrapolated)
    gc(verbose = FALSE)
  }
  .write_tsv(plot_data, file.path(output, "plot_sample.tsv.gz"))
  if (length(rows)) .write_tsv(data.table::rbindlist(rows), file.path(output, "summary.tsv"))
  writeLines("DONE", file.path(output, "DONE"))
  invisible(output)
}

rd_fit_dirs <- function(out_root = here::here("Fig4", "output")) {
  file.path(out_root, paste0(RD_JOBS$analysis, "_", mapply(rd_label, RD_JOBS$variant, RD_JOBS$a_mu)))
}

rd_collect <- function(out_root = here::here("Fig4", "output")) {
  directories <- rd_fit_dirs(out_root)
  read_item <- function(filename) {
    data.table::rbindlist(lapply(directories[file.exists(file.path(directories, filename))], function(directory) {
      value <- data.table::fread(file.path(directory, filename))
      base <- basename(directory)
      analysis <- names(RD_ANALYSES)[startsWith(base, paste0(names(RD_ANALYSES), "_"))][1L]
      if (!"analysis" %in% names(value)) value[, analysis := analysis]
      value
    }), fill = TRUE)
  }
  list(summary = read_item("summary.tsv"), sigma = read_item("sigma.tsv"),
       fit_runs = read_item("fit_runs.tsv"), iqr_sd = read_item("iqr_sd.tsv"))
}

MEDLDL_COLS <- c("alpha1", "beta1", "alpha2", "beta2", "alpha3", "beta3")
MEDLDL_JOBS <- data.table::rbindlist(list(
  data.table::CJ(set = "noshare", variant = c("main", "indep", "robust"), a_mu = c(0.5, 1.5)),
  data.table::CJ(set = "nearest", variant = "main", a_mu = c(0.5, 1.5)),
  data.table::CJ(set = "noshare_dedup", variant = c("main", "indep", "robust"), a_mu = c(0.5, 1.5)),
  data.table::CJ(set = "noshare_cond", variant = c("main", "indep", "robust"), a_mu = c(0.5, 1.5)),
  data.table::CJ(set = "noshare", variant = c("main", "indep", "robust"), a_mu = 3)
))

medldl_dedup <- function(data) {
  value <- data.table::copy(data)
  value[, triplet := apply(.SD, 1L, function(x) paste(sort(x), collapse = "|")),
        .SDcols = c("gene1", "gene2", "gene3")]
  data.table::setorder(value, triplet, chr, pos_b38)
  value[, .SD[ceiling(.N / 2)], by = triplet][, triplet := NULL][]
}

run_mediation_ldl <- function(set, variant, a_mu = 0.5,
                              out_root = here::here("Fig4", "output", "mediation_ldl"),
                              cores = as.integer(Sys.getenv("LSB_DJOB_NUMPROC", "4")),
                              q = 0.1, cap = 12, thresholds = 1:2) {
  stopifnot(set %in% c("noshare", "nearest", "noshare_dedup", "noshare_cond"),
            variant %in% c("main", "indep", "robust"))
  source_set <- sub("_dedup$", "", set)
  data <- freadgz(here::here("Data", "mediation", sprintf("mediation_ldl_liver_%s.tsv.gz", source_set)))
  if (grepl("_dedup$", set)) data <- medldl_dedup(data)
  data <- data[stats::complete.cases(data[, MEDLDL_COLS, with = FALSE])]
  z <- capz(as.matrix(data[, MEDLDL_COLS, with = FALSE]), cap)
  label <- paste0(set, "_", rd_label(variant, a_mu))
  output <- file.path(out_root, label)
  dir.create(output, recursive = TRUE, showWarnings = FALSE)
  if (file.exists(file.path(output, "DONE")) && Sys.getenv("RERUN", "0") != "1") return(invisible(output))
  reference <- reference_cors(z)
  fixed_sigma <- switch(variant, main = FALSE, indep = diag(ncol(z)), robust = project_cor(reference$robust, 0.05))
  specification <- .csm_function("csm_spec")(ncol(z), M = .csm_function("csm_structure")(ncol(z), 2L, 1L),
                                               a_mu = a_mu, b_mu = 15)
  control <- .csm_function("csm_control")(max_iter = 5000L, penalty = 30, weight_penalty = 10,
                                            fix_sigma = fixed_sigma, cores = cores)
  start <- proc.time()[3L]
  fit <- .csm_function("csm_fit")(z, specification, starts = c("null", "shared"), control = control)
  fit_minutes <- (proc.time()[3L] - start) / 60
  saveRDS(fit, file.path(output, "fit.rds"))
  .write_tsv(data.table::data.table(stat = MEDLDL_COLS, iqr_sd = reference$iqr_sd), file.path(output, "iqr_sd.tsv"))
  rows <- list()
  discoveries <- list()
  for (threshold in thresholds) {
    if (!isTRUE(fit$converged)) break
    lfdr <- .csm_function("csm_lfdr")(fit, z, "mediation", threshold, cores = cores)
    raw <- .stepup_parts(.csm_function("csm_stepup")(lfdr, q), nrow(z))
    adjusted_lfdr <- rd_majorant(z, lfdr, "mediation", threshold)
    adjusted <- .stepup_parts(.csm_function("csm_stepup")(adjusted_lfdr, q), nrow(z))
    rows[[length(rows) + 1L]] <- data.table::data.table(
      variant = label, a_mu = a_mu, t = threshold, n_features = nrow(z),
      n_triplets = data.table::uniqueN(data[, .(gene1, gene2, gene3)]),
      converged = fit$converged, loglik = fit$loglik %||% NA_real_, fit_minutes = round(fit_minutes, 2),
      R_raw = raw$n_rejected, R_adj = adjusted$n_rejected,
      triplets_raw = data.table::uniqueN(data[raw$rejected, .(gene1, gene2, gene3)]),
      triplets_adj = data.table::uniqueN(data[adjusted$rejected, .(gene1, gene2, gene3)]),
      loci_raw = clump(data$chr, data$pos_b38, lfdr, raw$rejected),
      loci_adj = clump(data$chr, data$pos_b38, adjusted_lfdr, adjusted$rejected)
    )
    selected <- raw$rejected | adjusted$rejected
    discoveries[[length(discoveries) + 1L]] <- cbind(
      data.table::data.table(t = threshold), data[selected],
      data.table::as.data.table(z[selected, , drop = FALSE]),
      data.table::data.table(lfdr = lfdr[selected], lfdr_adj = adjusted_lfdr[selected],
                             rej = raw$rejected[selected], rej_adj = adjusted$rejected[selected])
    )
  }
  if (length(rows)) .write_tsv(data.table::rbindlist(rows), file.path(output, "summary.tsv"))
  if (length(discoveries)) .write_tsv(data.table::rbindlist(discoveries, fill = TRUE), file.path(output, "discoveries.tsv.gz"))
  writeLines("DONE", file.path(output, "DONE"))
  invisible(output)
}
