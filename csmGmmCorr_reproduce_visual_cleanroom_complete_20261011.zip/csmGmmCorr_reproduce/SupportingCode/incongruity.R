.evidence_representation <- function(z, target, t) {
  z <- as.matrix(z)
  if (!nrow(z) || !ncol(z)) stop("z must be a nonempty matrix.", call. = FALSE)

  if (identical(target, "replication")) {
    rank_index <- as.integer(t) + 1L
    if (rank_index > ncol(z)) stop("t must be smaller than the number of statistics.", call. = FALSE)
    branch_positive <- apply(z, 1L, function(row) sort(row, decreasing = TRUE)[rank_index] >= 0)
    direction <- ifelse(branch_positive, 1, -1)
    return(list(group = ifelse(branch_positive, "+", "-"), strength = z * direction))
  }

  sign_code <- apply(sign(z), 1L, paste, collapse = ":")
  list(group = sign_code, strength = abs(z))
}

.strictly_dominates <- function(candidate, reference) {
  all(candidate >= reference) && any(candidate > reference)
}

incon_decision <- function(z, rejected, target, t) {
  rejected <- as.logical(rejected)
  if (length(rejected) != nrow(z)) stop("rejected must have one value per row of z.", call. = FALSE)
  if (!any(rejected) || all(rejected)) return(0L)

  evidence <- .evidence_representation(z, target, t)
  flagged <- logical(length(rejected))
  for (group in unique(evidence$group[rejected])) {
    accepted_index <- which(!rejected & evidence$group == group)
    rejected_index <- which(rejected & evidence$group == group)
    if (!length(accepted_index) || !length(rejected_index)) next
    rejected_strength <- evidence$strength[rejected_index, , drop = FALSE]
    lower_bound <- apply(rejected_strength, 2L, min)
    accepted_strength <- evidence$strength[accepted_index, , drop = FALSE]
    possible <- accepted_index[rowSums(sweep(accepted_strength, 2L, lower_bound, `>=`)) == ncol(accepted_strength)]
    for (index in possible) {
      candidate <- evidence$strength[index, ]
      dominated <- apply(rejected_strength, 1L, function(reference) .strictly_dominates(candidate, reference))
      if (any(dominated)) flagged[index] <- TRUE
    }
  }
  as.integer(sum(flagged))
}

incon_score <- function(z, score, target, t,
                        max_n = as.integer(Sys.getenv("INCON_MAX", "5000"))) {
  if (is.null(score) || length(score) != nrow(z) || all(is.na(score))) return(NA_integer_)
  eligible <- which(is.finite(score) & score < 0.99)
  if (length(eligible) < 2L) return(0L)
  max_n <- max(2L, as.integer(max_n))
  eligible <- eligible[order(score[eligible], eligible)]
  if (length(eligible) > max_n) eligible <- eligible[seq_len(max_n)]

  evidence <- .evidence_representation(z[eligible, , drop = FALSE], target, t)
  ordered_score <- score[eligible]
  violations <- 0L

  for (group in unique(evidence$group)) {
    member <- which(evidence$group == group)
    if (length(member) < 2L) next
    member <- member[order(ordered_score[member], member)]
    strength <- evidence$strength[member, , drop = FALSE]
    for (position in 2:nrow(strength)) {
      current <- strength[position, ]
      earlier <- strength[seq_len(position - 1L), , drop = FALSE]
      dominated <- rowSums(sweep(earlier, 2L, current, `<=`)) == ncol(strength) &
        rowSums(sweep(earlier, 2L, current, `<`)) > 0L
      if (any(dominated)) violations <- violations + 1L
    }
  }
  as.integer(violations)
}
