CHUNK <- 10L

sim_task_table <- function(scen, designs, reps = c(1L, 200L), chunk = CHUNK) {
  first <- seq.int(reps[1L], reps[2L], by = chunk)
  replicate_blocks <- data.frame(
    rep_from = first,
    rep_to = pmin(reps[2L], first + chunk - 1L)
  )
  thresholds <- if (identical(scen, "med")) c(1L, 2L) else 0L
  grid <- expand.grid(
    K = c(4L, 6L),
    design = as.integer(designs),
    t = thresholds,
    block = seq_len(nrow(replicate_blocks)),
    KEEP.OUT.ATTRS = FALSE,
    stringsAsFactors = FALSE
  )
  tasks <- cbind(
    grid[c("design", "K", "t")],
    replicate_blocks[grid$block, , drop = FALSE]
  )
  tasks <- tasks[order(tasks$K, tasks$design, tasks$t, tasks$rep_from), , drop = FALSE]
  rownames(tasks) <- NULL
  tasks
}

.array_spec <- function(folder, study, type, scen, designs, reps,
                        cores = 4L, wall = "12:00", mem = 8L) {
  list(
    folder = folder,
    study = study,
    type = type,
    scen = scen,
    designs = as.integer(designs),
    reps = as.integer(reps),
    cores = as.integer(cores),
    wall = wall,
    mem = as.integer(mem)
  )
}

.register_array <- function(registry, name, ...) {
  registry[[name]] <- .array_spec(...)
  registry
}

sim_arrays <- function() {
  registry <- list()
  add <- function(name, ...) registry <<- .register_array(registry, name, ...)

  for (scen in c("pl", "rp", "med")) {
    add(sprintf("main_ours_%s_pen", scen), "Fig2", "main", sprintf("ours_%s_pen", scen),
        scen, 1:12, c(1L, 500L))
    add(sprintf("main_ours_%s_ml", scen), "Fig2", "main", sprintf("ours_%s_ml", scen),
        scen, 1:12, c(1L, 200L))
    add(sprintf("sym_ours_%s_pen", scen), "Fig2", "sym", sprintf("ours_%s_pen", scen),
        scen, 1:12, c(1L, 200L))
    add(sprintf("sym_ours_%s_ml", scen), "Fig2", "sym", sprintf("ours_%s_ml", scen),
        scen, 1:12, c(1L, 200L))

    add(sprintf("rho_ours_%s_pen", scen), "Fig3", "rho", sprintf("ours_%s_pen", scen),
        scen, 1:5, c(1L, 200L))
    add(sprintf("rho_ours_%s_ml", scen), "Fig3", "rho", sprintf("ours_%s_ml", scen),
        scen, 1:5, c(1L, 200L))
    add(sprintf("rho_comp_%s_csm", scen), "Fig3", "rho", sprintf("comp_%s_csm", scen),
        scen, 1:5, c(1L, 200L))

    add(sprintf("main_comp_%s_csm", scen), "Tab2", "main", sprintf("comp_%s_csm", scen),
        scen, 1:9, c(1L, 200L))
    for (study in c("quant", "exch", "ld", "split")) {
      add(sprintf("%s_ours_%s_pen", study, scen), "Tab2", study,
          sprintf("ours_%s_pen", scen), scen, c(1L, 5L, 7L), c(1L, 100L))
    }

    for (setting in c("L0A10", "L10A10", "L100A10", "L30A0", "L30A3", "L30A30")) {
      name <- sprintf("main_ours_%s_pen_%s", scen, setting)
      add(name, "SuppTab3", "main", sprintf("ours_%s_pen_%s", scen, setting),
          scen, c(1L, 5L, 7L), c(1L, 50L))
    }
    for (structure in c("A", "C")) {
      name <- sprintf("main_ours_%s_pen_%s", scen, structure)
      add(name, "SuppTab9", "main", sprintf("ours_%s_pen_%s", scen, structure),
          scen, c(1L, 5L, 7L), c(1L, 50L), wall = if (structure == "C") "16:00" else "12:00")
    }
  }

  add("main_comp_pl", "Fig2", "main", "comp_pl", "pl", 1:12, c(1L, 200L), wall = "4:00", mem = 4L)
  add("main_comp_med", "Fig2", "main", "comp_med", "med", 1:12, c(1L, 200L),
      cores = 1L, wall = "16:00", mem = 16L)
  add("main_comp_rp", "SuppTab12", "main", "comp_rp", "rp", 1:12, c(1L, 200L),
      cores = 1L, wall = "12:00", mem = 16L)
  add("rho_ours_med_pen_oracle", "Tab2", "rho", "ours_med_pen_oracle", "med", 4:5,
      c(1L, 50L))

  registry
}

sim_array <- function(name) {
  registry <- sim_arrays()
  if (!name %in% names(registry)) stop("Unknown simulation array: ", name, call. = FALSE)
  specification <- registry[[name]]
  specification$tasks <- sim_task_table(
    specification$scen,
    specification$designs,
    specification$reps
  )
  specification
}
