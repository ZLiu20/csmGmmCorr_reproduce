.base_designs <- list(
  pl = list(effect = c(0.38, 0.43, 0.48, 0.53, 0.58), tau1 = c(0.01, 0.02, 0.03, 0.04)),
  rp = list(effect = c(0.48, 0.54, 0.60, 0.66, 0.72), tau1 = c(0.01, 0.02, 0.03, 0.04)),
  med = list(m = c(8L, 10L, 12L, 14L, 16L), reference_m = 12L,
             tau1 = c(0.02, 0.04, 0.06, 0.08))
)

.extended_effects <- list(
  pl = c(0.63, 0.68, 0.73),
  rp = c(0.78, 0.84, 0.90),
  med = c(18L, 20L, 22L)
)

.scenario_name <- function(scen) {
  match.arg(scen, c("pl", "rp", "med"))
}

.effect_rows <- function(scen, values, first_index = 1L) {
  count <- length(values)
  labels <- sprintf("effect_%02d", seq.int(first_index, length.out = count))
  if (scen == "med") {
    m <- as.integer(values)
    data.frame(
      design = labels,
      axis = "effect",
      x = m,
      tau1 = 0,
      m = m,
      a_min = 0.01 * m,
      a_max = 0.18 + 0.01 * m,
      b_min = 0.14 + 0.01 * m,
      b_max = 0.24 + 0.01 * m,
      stringsAsFactors = FALSE
    )
  } else {
    data.frame(
      design = labels,
      axis = "effect",
      x = values,
      tau1 = 0,
      m = NA_integer_,
      a_min = NA_real_, a_max = NA_real_, b_min = NA_real_, b_max = NA_real_,
      stringsAsFactors = FALSE
    )
  }
}

.tau_rows <- function(scen, values) {
  labels <- sprintf("tau1_%03d", round(100 * values))
  if (scen == "med") {
    m <- rep.int(.base_designs$med$reference_m, length(values))
    data.frame(
      design = labels,
      axis = "tau1",
      x = values,
      tau1 = values,
      m = m,
      a_min = 0.01 * m,
      a_max = 0.18 + 0.01 * m,
      b_min = 0.14 + 0.01 * m,
      b_max = 0.24 + 0.01 * m,
      stringsAsFactors = FALSE
    )
  } else {
    reference_effect <- max(.base_designs[[scen]]$effect)
    data.frame(
      design = labels,
      axis = "tau1",
      x = values,
      effect = reference_effect,
      tau1 = values,
      m = NA_integer_,
      a_min = NA_real_, a_max = NA_real_, b_min = NA_real_, b_max = NA_real_,
      stringsAsFactors = FALSE
    )
  }
}

design_table <- function(study = "main", scen = "pl") {
  scen <- .scenario_name(scen)
  if (study == "split") study <- "main"

  base <- if (scen == "med") {
    rbind(
      .effect_rows(scen, .base_designs$med$m),
      .tau_rows(scen, .base_designs$med$tau1)
    )
  } else {
    effect_rows <- .effect_rows(scen, .base_designs[[scen]]$effect)
    effect_rows$effect <- effect_rows$x
    rbind(effect_rows, .tau_rows(scen, .base_designs[[scen]]$tau1))
  }
  extension <- .effect_rows(scen, .extended_effects[[scen]], first_index = 6L)
  if (scen != "med") extension$effect <- extension$x
  base <- rbind(base, extension[names(base)])
  base$id <- seq_len(nrow(base))
  base$rho <- 0.2
  base$b0 <- -1
  base$outcome <- "logit"
  base$corr <- "ar1"

  if (study %in% c("main", "split")) return(base)
  if (study == "sym") {
    base$b0 <- 0
    return(base)
  }
  if (study == "quant") {
    base$outcome <- "linear"
    return(base)
  }
  if (study %in% c("ld", "ldloc", "ldu")) {
    base$ld <- 0.5
    return(base)
  }
  if (study == "exch") {
    base$rho <- 0.4
    base$corr <- "exchangeable"
    return(base)
  }
  if (study == "rho") {
    rho <- c(0, 0.2, 0.4, 0.6, 0.8)
    out <- base[rep(5L, length(rho)), , drop = FALSE]
    out$id <- seq_along(rho)
    out$rho <- rho
    out$x <- out$rho
    out$axis <- "rho"
    out$design <- sprintf("rho_%03d", round(100 * out$rho))
    rownames(out) <- NULL
    return(out)
  }
  if (study == "extension") {
    out <- extension
    out$id <- seq_len(nrow(out))
    out$rho <- 0.2
    out$b0 <- -1
    out$outcome <- "logit"
    out$corr <- "ar1"
    return(out)
  }
  stop("Unknown study: ", study, call. = FALSE)
}

size_probs <- function(K, tau1 = 0) {
  stopifnot(length(K) == 1L, K >= 1L, length(tau1) == 1L, tau1 >= 0)
  first <- if (tau1 > 0) {
    p1 <- 3 * tau1^2
    c(3 * tau1, p1, p1 / 2, p1 / 4)
  } else {
    c(0.04, 0.0012, 0.0006, 0.0003)
  }
  signal <- first[seq_len(min(K, length(first)))]
  if (K > length(first)) {
    signal <- c(signal, tail(first, 1L) * 0.5^seq_len(K - length(first)))
  }
  null <- 1 - sum(signal)
  if (!is.finite(null) || null <= 0) stop("Signal probabilities must sum to less than one.", call. = FALSE)
  c(null, signal)
}

complete_pair_fraction <- function(K, s) {
  if (K %% 2L != 0L) stop("Mediation requires an even number of statistics.", call. = FALSE)
  if (s < 2L) return(0)
  pairs <- K / 2L
  pair_free <- if (s <= pairs) choose(pairs, s) * 2^s else 0
  1 - pair_free / choose(K, s)
}

size_probs_mediation <- function(K, t, tau1 = 0) {
  probabilities <- size_probs(K, tau1)
  support <- 0:K
  eligible_fraction <- vapply(
    support,
    function(s) if (s > t) complete_pair_fraction(K, s) else 0,
    numeric(1)
  )
  target <- if (tau1 > 0) 0.025 * tau1 else 0.001
  current <- sum(probabilities * eligible_fraction)
  eligible <- which(eligible_fraction > 0)
  if (!length(eligible) || current <= 0) stop("The mediation alternative has zero prior mass.", call. = FALSE)
  probabilities[eligible] <- probabilities[eligible] * target / current
  probabilities[1L] <- 1 - sum(probabilities[-1L])
  if (probabilities[1L] <= 0) stop("Mediation calibration leaves no global-null mass.", call. = FALSE)
  probabilities
}

draw_configs <- function(N, K, probabilities) {
  if (length(probabilities) != K + 1L) stop("Expected K + 1 support probabilities.", call. = FALSE)
  support <- sample.int(K + 1L, N, replace = TRUE, prob = probabilities) - 1L
  state <- matrix(0L, nrow = N, ncol = K)
  for (row in which(support > 0L)) {
    active <- sample.int(K, support[row], replace = FALSE)
    state[row, active] <- sample(c(-1L, 1L), support[row], replace = TRUE)
  }
  state
}

ar1 <- function(K, rho) {
  rho^abs(outer(seq_len(K), seq_len(K), `-`))
}

corr_mat <- function(K, rho, corr = c("ar1", "exchangeable")) {
  corr <- match.arg(corr)
  if (corr == "ar1") return(ar1(K, rho))
  out <- matrix(rho, K, K)
  diag(out) <- 1
  out
}

LIN_SCALE <- sqrt(stats::plogis(-1) * (1 - stats::plogis(-1)))

gen_geno <- function(n, m, maf, ld = 0) {
  if (ld == 0) return(matrix(stats::rbinom(n * m, 2L, maf), nrow = n, ncol = m))
  if (abs(ld) >= 1) stop("ld must lie strictly between -1 and 1.", call. = FALSE)
  cutoff <- stats::qnorm(maf)
  innovation_sd <- sqrt(1 - ld^2)
  one_haplotype <- function() {
    latent <- matrix(stats::rnorm(n * m), nrow = n, ncol = m)
    if (m > 1L) {
      for (column in 2:m) latent[, column] <- ld * latent[, column - 1L] + innovation_sd * latent[, column]
    }
    latent < cutoff
  }
  one_haplotype() + one_haplotype()
}

.safe_standardize <- function(x) {
  centered <- sweep(x, 2L, colMeans(x), "-")
  scale <- sqrt(colSums(centered^2))
  scale[scale == 0] <- NA_real_
  sweep(centered, 2L, scale, "/")
}

lin_score_z <- function(G, y) {
  gy <- .safe_standardize(G)
  yy <- as.numeric(scale(y, center = TRUE, scale = FALSE))
  z <- sqrt(length(yy)) * as.numeric(crossprod(gy, yy)) / sqrt(sum(yy^2))
  z[!is.finite(z)] <- 0
  z
}

lin_wald_batch <- function(Xs, Y) {
  n <- nrow(Y)
  outcomes <- ncol(Y)
  covariates <- length(Xs)
  z <- matrix(0, nrow = covariates, ncol = outcomes)
  for (column in seq_len(outcomes)) {
    design <- vapply(Xs, function(x) x[, column], numeric(n))
    fit <- stats::lm.fit(design, Y[, column])
    if (fit$rank != ncol(design)) next
    residual_df <- n - fit$rank
    if (residual_df <= 0) next
    sigma2 <- sum(fit$residuals^2) / residual_df
    covariance <- chol2inv(fit$qr$qr[seq_len(fit$rank), seq_len(fit$rank), drop = FALSE]) * sigma2
    standard_error <- sqrt(diag(covariance))
    value <- fit$coefficients / standard_error
    value[!is.finite(value)] <- 0
    z[, column] <- value
  }
  z
}

.logistic_fit <- function(design, response, maxit, tol) {
  fit <- stats::glm.fit(
    x = design,
    y = response,
    family = stats::binomial(),
    control = stats::glm.control(epsilon = tol, maxit = maxit)
  )
  if (!fit$converged || fit$rank != ncol(design)) return(rep(0, ncol(design)))
  weight <- fit$weights
  information <- crossprod(design, design * weight)
  inverse <- tryCatch(solve(information), error = function(e) NULL)
  if (is.null(inverse)) return(rep(0, ncol(design)))
  se <- sqrt(pmax(diag(inverse), 0))
  z <- fit$coefficients / se
  z[!is.finite(z)] <- 0
  z
}

logit_wald_batch <- function(Xs, Y, maxit = 25L, tol = 1e-8) {
  n <- nrow(Y)
  outcomes <- ncol(Y)
  covariates <- length(Xs)
  z <- matrix(0, nrow = covariates, ncol = outcomes)
  for (column in seq_len(outcomes)) {
    design <- vapply(Xs, function(x) x[, column], numeric(n))
    z[, column] <- .logistic_fit(design, Y[, column], maxit = maxit, tol = tol)
  }
  z
}

logit_wald_geno <- function(G, y, maxit = 50L, tol = 1e-10) {
  out <- numeric(ncol(G))
  for (column in seq_len(ncol(G))) {
    design <- cbind(1, G[, column])
    out[column] <- .logistic_fit(design, y, maxit = maxit, tol = tol)[2L]
  }
  out
}

Z_MAX <- 8.1

.clip_z <- function(z) {
  z[!is.finite(z)] <- 0
  z[z > Z_MAX] <- Z_MAX
  z[z < -Z_MAX] <- -Z_MAX
  z
}

gen_pleio <- function(N, K, probabilities, effect, n = 1000L, maf = 0.3,
                      b0 = -1, rho = 0.2, set_size = 1000L,
                      outcome = c("logit", "linear"), ld = 0,
                      corr = c("ar1", "exchangeable")) {
  outcome <- match.arg(outcome)
  corr <- match.arg(corr)
  H <- draw_configs(N, K, probabilities)
  beta <- H * effect
  latent_chol <- chol(corr_mat(K, rho, corr))
  z <- matrix(0, nrow = N, ncol = K)

  for (first in seq.int(1L, N, by = set_size)) {
    index <- first:min(first + set_size - 1L, N)
    G <- gen_geno(n, length(index), maf, ld)
    noise <- matrix(stats::rnorm(n * K), nrow = n) %*% latent_chol
    if (outcome == "linear") {
      y <- G %*% beta[index, , drop = FALSE] + noise
      for (dimension in seq_len(K)) z[index, dimension] <- lin_score_z(G, y[, dimension])
    } else {
      eta <- G %*% beta[index, , drop = FALSE] + b0
      y <- matrix(stats::rbinom(length(eta), 1L, stats::plogis(eta)), nrow = n)
      for (dimension in seq_len(K)) z[index, dimension] <- logit_wald_geno(G, y[, dimension])
    }
  }
  list(z = .clip_z(z), H = H, B = beta)
}

gen_mediation <- function(N, K, probabilities, a_rng, b_rng, n = 1000L,
                          maf = 0.3, b0 = -1, rho = 0.2,
                          set_size = 1000L, outcome = c("logit", "linear"),
                          ld = 0, corr = c("ar1", "exchangeable")) {
  if (K %% 2L != 0L) stop("Mediation requires paired statistics and therefore even K.", call. = FALSE)
  outcome <- match.arg(outcome)
  corr <- match.arg(corr)
  mediators <- K / 2L
  H <- draw_configs(N, K, probabilities)
  beta <- matrix(0, nrow = N, ncol = K)
  odd <- seq.int(1L, K, by = 2L)
  even <- odd + 1L
  beta[, odd] <- H[, odd] * matrix(stats::runif(N * mediators, a_rng[1L], a_rng[2L]), N)
  beta[, even] <- H[, even] * matrix(stats::runif(N * mediators, b_rng[1L], b_rng[2L]), N)
  mediator_chol <- chol(corr_mat(mediators, rho, corr))
  z <- matrix(0, nrow = N, ncol = K)

  for (first in seq.int(1L, N, by = set_size)) {
    index <- first:min(first + set_size - 1L, N)
    features <- length(index)
    G <- gen_geno(n, features, maf, ld)
    errors <- matrix(stats::rnorm(n * mediators), nrow = n) %*% mediator_chol
    M <- lapply(seq_len(mediators), function(g) {
      sweep(G, 2L, beta[index, odd[g]], "*") + errors[, g]
    })
    eta <- matrix(if (outcome == "linear") 0 else b0, nrow = n, ncol = features)
    for (g in seq_len(mediators)) eta <- eta + sweep(M[[g]], 2L, beta[index, even[g]], "*")

    G_centered <- sweep(G, 2L, colMeans(G), "-")
    G_scale <- sqrt(colSums(G_centered^2))
    for (g in seq_len(mediators)) {
      M_centered <- sweep(M[[g]], 2L, colMeans(M[[g]]), "-")
      denom <- G_scale * sqrt(colSums(M_centered^2))
      alpha_z <- sqrt(n) * colSums(G_centered * M_centered) / denom
      alpha_z[!is.finite(alpha_z)] <- 0
      z[index, odd[g]] <- alpha_z
    }

    design_blocks <- c(list(matrix(1, n, features), G), M)
    if (outcome == "linear") {
      y <- eta + matrix(stats::rnorm(n * features), nrow = n)
      fitted_z <- lin_wald_batch(design_blocks, y)
    } else {
      y <- matrix(stats::rbinom(n * features, 1L, stats::plogis(eta)), nrow = n)
      fitted_z <- logit_wald_batch(design_blocks, y)
    }
    for (g in seq_len(mediators)) z[index, even[g]] <- fitted_z[2L + g, ]
  }
  list(z = .clip_z(z), H = H, B = beta)
}

sim_seed <- function(scen, design_id, K, t, rep, role) {
  scenario_code <- match(.scenario_name(scen), c("pl", "med", "rp"))
  if (rep <= 200L) {
    raw <- (((scenario_code * 10L + design_id) * 11L + K) * 3L + t) * 100L + rep
  } else {
    raw <- 100000000L + (((scenario_code * 10L + design_id) * 11L + K) * 3L + t) * 1000L + rep
  }
  as.integer((raw * 2L + role) %% .Machine$integer.max)
}

make_dataset <- function(scen, design_id, K, t, rep, N = 100000L, study = "main") {
  scen <- .scenario_name(scen)
  split_sample <- identical(study, "split")
  design_study <- if (split_sample) "main" else study
  table <- design_table(design_study, scen)
  if (!design_id %in% table$id) stop("Unknown design id: ", design_id, call. = FALSE)
  design <- table[match(design_id, table$id), , drop = FALSE]
  stream_code <- c(pl = 1L, med = 2L, rp = 7L)[[scen]] +
    switch(design_study, main = 0L, rho = 2L, sym = 4L, quant = 20L,
           ld = 40L, ldloc = 40L, ldu = 40L, exch = 60L, extension = 80L, 0L)

  generate <- function(role) {
    set.seed(sim_seed(scen, design_id, K, t, rep, role + stream_code))
    if (scen %in% c("pl", "rp")) {
      gen_pleio(
        N, K, size_probs(K, design$tau1), design$effect,
        rho = design$rho, b0 = design$b0, outcome = design$outcome,
        ld = if (!is.null(design$ld)) design$ld else 0,
        corr = design$corr
      )
    } else {
      gen_mediation(
        N, K, size_probs_mediation(K, t, design$tau1),
        c(design$a_min, design$a_max), c(design$b_min, design$b_max),
        rho = design$rho, b0 = design$b0, outcome = design$outcome,
        ld = if (!is.null(design$ld)) design$ld else 0,
        corr = design$corr
      )
    }
  }

  train <- generate(1L)
  test <- if (split_sample) generate(2L) else train
  list(train = train, test = test, design = design)
}

truth_alt <- function(H, target = c("pleiotropy", "replication", "mediation"), t = 1L) {
  target <- match.arg(target)
  active <- rowSums(H != 0)
  if (target == "pleiotropy") return(active > t)
  if (target == "replication") return(active > t & abs(rowSums(sign(H))) == active)
  if (ncol(H) %% 2L != 0L) stop("Mediation truth requires paired columns.", call. = FALSE)
  pairs <- array(H != 0, dim = c(nrow(H), 2L, ncol(H) / 2L))
  complete_path <- apply(pairs, c(1L, 3L), all)
  active > t & rowSums(complete_path) > 0L
}

truth_alt_locus <- function(alt, w = 5L, set_size = 1000L) {
  N <- length(alt)
  out <- logical(N)
  for (first in seq.int(1L, N, by = set_size)) {
    index <- first:min(first + set_size - 1L, N)
    values <- as.integer(alt[index])
    cumulative <- c(0L, cumsum(values))
    lo <- pmax(1L, seq_along(index) - w)
    hi <- pmin(length(index), seq_along(index) + w)
    out[index] <- cumulative[hi + 1L] - cumulative[lo] > 0L
  }
  out
}

union_config <- function(H, w = 2L, set_size = 1000L) {
  N <- nrow(H)
  K <- ncol(H)
  out <- matrix(0L, nrow = N, ncol = K)
  for (first in seq.int(1L, N, by = set_size)) {
    index <- first:min(first + set_size - 1L, N)
    block <- H[index, , drop = FALSE]
    for (dimension in seq_len(K)) {
      values <- block[, dimension]
      for (position in seq_along(index)) {
        neighborhood <- values[pmax(1L, position - w):pmin(length(index), position + w)]
        nonzero <- neighborhood[neighborhood != 0L]
        if (length(nonzero)) out[index[position], dimension] <- sign(sum(nonzero))
      }
    }
  }
  out
}
