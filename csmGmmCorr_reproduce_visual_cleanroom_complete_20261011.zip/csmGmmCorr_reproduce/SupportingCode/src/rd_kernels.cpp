#define R_NO_REMAP
#include <R.h>
#include <Rinternals.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <map>
#include <numeric>
#include <vector>

namespace {

struct Evidence {
  std::vector<std::int64_t> group;
  std::vector<double> value;
};

Evidence transform(const double* z, int n, int k, int mode, int threshold) {
  Evidence result;
  result.group.resize(n);
  result.value.resize(static_cast<std::size_t>(n) * k);
  std::vector<double> row(k);
  for (int i = 0; i < n; ++i) {
    if (mode == 0) {
      std::int64_t code = 0;
      for (int d = 0; d < k; ++d) {
        const double x = z[i + static_cast<std::size_t>(d) * n];
        const int digit = x < 0 ? 0 : (x > 0 ? 2 : 1);
        code = code * 3 + digit;
        result.value[static_cast<std::size_t>(i) * k + d] = std::abs(x);
      }
      result.group[i] = code;
    } else {
      for (int d = 0; d < k; ++d) row[d] = z[i + static_cast<std::size_t>(d) * n];
      const int rank = threshold;
      std::vector<double> ordered(row);
      std::sort(ordered.begin(), ordered.end());
      const double positive = ordered[k - rank - 1];
      const double negative = -ordered[rank];
      const double direction = positive >= negative ? 1.0 : -1.0;
      result.group[i] = direction > 0 ? 1 : -1;
      for (int d = 0; d < k; ++d) {
        result.value[static_cast<std::size_t>(i) * k + d] = direction * row[d];
      }
    }
  }
  return result;
}

class OrthantTree {
 public:
  OrthantTree(const std::vector<double>& points, int dimensions,
              const std::vector<double>& score, std::vector<int> rows,
              int leaf_size)
      : points_(points), dimensions_(dimensions), score_(score), rows_(std::move(rows)),
        leaf_size_(std::max(2, leaf_size)) {
    nodes_.reserve(rows_.size() / leaf_size_ + 8);
    root_ = rows_.empty() ? -1 : build(0, static_cast<int>(rows_.size()));
  }

  double maximum_dominating(const double* query, double baseline) const {
    return root_ < 0 ? baseline : query_max(root_, query, baseline);
  }

  bool has_strictly_dominated(const double* query) const {
    return root_ >= 0 && query_dominated(root_, query);
  }

 private:
  struct Node {
    int begin = 0;
    int end = 0;
    int left = -1;
    int right = -1;
    double max_score = -std::numeric_limits<double>::infinity();
    std::vector<double> low;
    std::vector<double> high;
  };

  const std::vector<double>& points_;
  int dimensions_;
  const std::vector<double>& score_;
  std::vector<int> rows_;
  int leaf_size_;
  int root_;
  std::vector<Node> nodes_;

  double coordinate(int row, int dimension) const {
    return points_[static_cast<std::size_t>(row) * dimensions_ + dimension];
  }

  int build(int begin, int end) {
    const int id = static_cast<int>(nodes_.size());
    nodes_.push_back(Node{});
    Node& node = nodes_.back();
    node.begin = begin;
    node.end = end;
    node.low.assign(dimensions_, std::numeric_limits<double>::infinity());
    node.high.assign(dimensions_, -std::numeric_limits<double>::infinity());
    for (int pos = begin; pos < end; ++pos) {
      const int row = rows_[pos];
      node.max_score = std::max(node.max_score, score_[row]);
      for (int d = 0; d < dimensions_; ++d) {
        const double x = coordinate(row, d);
        node.low[d] = std::min(node.low[d], x);
        node.high[d] = std::max(node.high[d], x);
      }
    }
    if (end - begin <= leaf_size_) return id;
    int split_dimension = 0;
    double widest = -1;
    for (int d = 0; d < dimensions_; ++d) {
      const double width = node.high[d] - node.low[d];
      if (width > widest) {
        widest = width;
        split_dimension = d;
      }
    }
    if (!(widest > 0)) return id;
    const int middle = begin + (end - begin) / 2;
    std::nth_element(rows_.begin() + begin, rows_.begin() + middle, rows_.begin() + end,
                     [&](int a, int b) {
                       const double xa = coordinate(a, split_dimension);
                       const double xb = coordinate(b, split_dimension);
                       return xa == xb ? a < b : xa < xb;
                     });
    const int left = build(begin, middle);
    const int right = build(middle, end);
    nodes_[id].left = left;
    nodes_[id].right = right;
    return id;
  }

  double query_max(int node_id, const double* query, double best) const {
    const Node& node = nodes_[node_id];
    if (node.max_score <= best) return best;
    bool entirely_valid = true;
    for (int d = 0; d < dimensions_; ++d) {
      if (node.high[d] < query[d]) return best;
      if (node.low[d] < query[d]) entirely_valid = false;
    }
    if (entirely_valid) return std::max(best, node.max_score);
    if (node.left < 0) {
      for (int pos = node.begin; pos < node.end; ++pos) {
        const int row = rows_[pos];
        bool valid = true;
        for (int d = 0; d < dimensions_; ++d) {
          if (coordinate(row, d) < query[d]) { valid = false; break; }
        }
        if (valid) best = std::max(best, score_[row]);
      }
      return best;
    }
    int first = node.left;
    int second = node.right;
    if (nodes_[second].max_score > nodes_[first].max_score) std::swap(first, second);
    best = query_max(first, query, best);
    return query_max(second, query, best);
  }

  bool query_dominated(int node_id, const double* query) const {
    const Node& node = nodes_[node_id];
    bool all_below = true;
    bool strict_possible = false;
    for (int d = 0; d < dimensions_; ++d) {
      if (node.low[d] > query[d]) return false;
      if (node.high[d] > query[d]) all_below = false;
      if (node.low[d] < query[d]) strict_possible = true;
    }
    if (all_below && strict_possible) return true;
    if (node.left < 0) {
      for (int pos = node.begin; pos < node.end; ++pos) {
        const int row = rows_[pos];
        bool weak = true;
        bool strict = false;
        for (int d = 0; d < dimensions_; ++d) {
          const double x = coordinate(row, d);
          if (x > query[d]) { weak = false; break; }
          if (x < query[d]) strict = true;
        }
        if (weak && strict) return true;
      }
      return false;
    }
    return query_dominated(node.left, query) || query_dominated(node.right, query);
  }
};

}  // namespace

extern "C" SEXP rd_majorant(SEXP z_sexp, SEXP score_sexp, SEXP mode_sexp,
                            SEXP threshold_sexp, SEXP leaf_sexp) {
  const int n = Rf_nrows(z_sexp);
  const int k = Rf_ncols(z_sexp);
  Evidence evidence = transform(REAL(z_sexp), n, k, Rf_asInteger(mode_sexp),
                                Rf_asInteger(threshold_sexp));
  std::vector<double> score(REAL(score_sexp), REAL(score_sexp) + n);
  SEXP answer = PROTECT(Rf_allocVector(REALSXP, n));
  std::copy(score.begin(), score.end(), REAL(answer));
  std::map<std::int64_t, std::vector<int>> groups;
  for (int i = 0; i < n; ++i) groups[evidence.group[i]].push_back(i);
  for (const auto& entry : groups) {
    OrthantTree tree(evidence.value, k, score, entry.second, Rf_asInteger(leaf_sexp));
    for (int row : entry.second) {
      REAL(answer)[row] = tree.maximum_dominating(&evidence.value[static_cast<std::size_t>(row) * k], score[row]);
    }
  }
  UNPROTECT(1);
  return answer;
}

extern "C" SEXP rd_incon_dec(SEXP z_sexp, SEXP rejected_sexp, SEXP mode_sexp,
                             SEXP threshold_sexp, SEXP leaf_sexp) {
  const int n = Rf_nrows(z_sexp);
  const int k = Rf_ncols(z_sexp);
  Evidence evidence = transform(REAL(z_sexp), n, k, Rf_asInteger(mode_sexp),
                                Rf_asInteger(threshold_sexp));
  std::vector<double> dummy(n, 0.0);
  std::map<std::int64_t, std::vector<int>> accepted;
  std::map<std::int64_t, std::vector<int>> rejected;
  for (int i = 0; i < n; ++i) {
    (LOGICAL(rejected_sexp)[i] ? rejected : accepted)[evidence.group[i]].push_back(i);
  }
  SEXP answer = PROTECT(Rf_allocVector(LGLSXP, n));
  std::fill(LOGICAL(answer), LOGICAL(answer) + n, 0);
  for (const auto& entry : rejected) {
    auto found = accepted.find(entry.first);
    if (found == accepted.end()) continue;
    OrthantTree tree(evidence.value, k, dummy, entry.second, Rf_asInteger(leaf_sexp));
    for (int row : found->second) {
      LOGICAL(answer)[row] = tree.has_strictly_dominated(
        &evidence.value[static_cast<std::size_t>(row) * k]) ? 1 : 0;
    }
  }
  UNPROTECT(1);
  return answer;
}
