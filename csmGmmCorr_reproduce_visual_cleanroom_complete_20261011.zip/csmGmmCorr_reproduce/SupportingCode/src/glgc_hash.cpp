#define R_NO_REMAP
#include <R.h>
#include <Rinternals.h>
#include <string>
#include "blake2b8.h"

extern "C" SEXP glgc_blake2b_hex(SEXP values) {
  const R_xlen_t n = XLENGTH(values);
  SEXP result = PROTECT(Rf_allocVector(STRSXP, n));
  for (R_xlen_t i = 0; i < n; ++i) {
    if (STRING_ELT(values, i) == NA_STRING) {
      SET_STRING_ELT(result, i, NA_STRING);
      continue;
    }
    const char* text = Rf_translateCharUTF8(STRING_ELT(values, i));
    const std::string input(text);
    const std::uint64_t hash = csmhash::blake2b64(
      reinterpret_cast<const unsigned char*>(input.data()), input.size());
    const std::string hex = csmhash::hex64(hash);
    SET_STRING_ELT(result, i, Rf_mkCharLenCE(hex.data(), static_cast<int>(hex.size()), CE_UTF8));
  }
  UNPROTECT(1);
  return result;
}
