#ifndef CSMGMMCORR_BLAKE2B8_H
#define CSMGMMCORR_BLAKE2B8_H

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string>

namespace csmhash {

inline std::uint64_t rotate_right(std::uint64_t x, unsigned shift) {
  return (x >> shift) | (x << (64 - shift));
}

inline std::uint64_t load64(const unsigned char* p) {
  std::uint64_t value = 0;
  for (int i = 0; i < 8; ++i) value |= static_cast<std::uint64_t>(p[i]) << (8 * i);
  return value;
}

inline void mix(std::uint64_t& a, std::uint64_t& b, std::uint64_t& c,
                std::uint64_t& d, std::uint64_t x, std::uint64_t y) {
  a = a + b + x;
  d = rotate_right(d ^ a, 32);
  c += d;
  b = rotate_right(b ^ c, 24);
  a = a + b + y;
  d = rotate_right(d ^ a, 16);
  c += d;
  b = rotate_right(b ^ c, 63);
}

inline std::uint64_t blake2b64(const unsigned char* input, std::size_t length) {
  static const std::uint64_t iv[8] = {
    0x6a09e667f3bcc908ULL, 0xbb67ae8584caa73bULL,
    0x3c6ef372fe94f82bULL, 0xa54ff53a5f1d36f1ULL,
    0x510e527fade682d1ULL, 0x9b05688c2b3e6c1fULL,
    0x1f83d9abfb41bd6bULL, 0x5be0cd19137e2179ULL
  };
  static const unsigned char sigma[12][16] = {
    {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},
    {14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3},
    {11,8,12,0,5,2,15,13,10,14,3,6,7,1,9,4},
    {7,9,3,1,13,12,11,14,2,6,5,10,4,0,15,8},
    {9,0,5,7,2,4,10,15,14,1,11,12,6,8,3,13},
    {2,12,6,10,0,11,8,3,4,13,7,5,15,14,1,9},
    {12,5,1,15,14,13,4,10,0,7,6,3,9,2,8,11},
    {13,11,7,14,12,1,3,9,5,0,15,4,8,6,2,10},
    {6,15,14,9,11,3,0,8,12,2,13,7,1,4,10,5},
    {10,2,8,4,7,6,1,5,15,11,9,14,3,12,13,0},
    {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},
    {14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3}
  };
  std::array<std::uint64_t, 8> h;
  std::copy(iv, iv + 8, h.begin());
  h[0] ^= 0x01010008ULL;
  std::uint64_t counter = 0;
  std::size_t offset = 0;
  while (length - offset > 128) {
    const unsigned char* block = input + offset;
    counter += 128;
    std::uint64_t m[16];
    for (int i = 0; i < 16; ++i) m[i] = load64(block + 8 * i);
    std::uint64_t v[16];
    for (int i = 0; i < 8; ++i) { v[i] = h[i]; v[i + 8] = iv[i]; }
    v[12] ^= counter;
    for (int r = 0; r < 12; ++r) {
      mix(v[0],v[4],v[8],v[12],m[sigma[r][0]],m[sigma[r][1]]);
      mix(v[1],v[5],v[9],v[13],m[sigma[r][2]],m[sigma[r][3]]);
      mix(v[2],v[6],v[10],v[14],m[sigma[r][4]],m[sigma[r][5]]);
      mix(v[3],v[7],v[11],v[15],m[sigma[r][6]],m[sigma[r][7]]);
      mix(v[0],v[5],v[10],v[15],m[sigma[r][8]],m[sigma[r][9]]);
      mix(v[1],v[6],v[11],v[12],m[sigma[r][10]],m[sigma[r][11]]);
      mix(v[2],v[7],v[8],v[13],m[sigma[r][12]],m[sigma[r][13]]);
      mix(v[3],v[4],v[9],v[14],m[sigma[r][14]],m[sigma[r][15]]);
    }
    for (int i = 0; i < 8; ++i) h[i] ^= v[i] ^ v[i + 8];
    offset += 128;
  }
  unsigned char final_block[128] = {0};
  const std::size_t final_length = length - offset;
  if (final_length) std::memcpy(final_block, input + offset, final_length);
  counter += final_length;
  std::uint64_t m[16];
  for (int i = 0; i < 16; ++i) m[i] = load64(final_block + 8 * i);
  std::uint64_t v[16];
  for (int i = 0; i < 8; ++i) { v[i] = h[i]; v[i + 8] = iv[i]; }
  v[12] ^= counter;
  v[14] = ~v[14];
  for (int r = 0; r < 12; ++r) {
    mix(v[0],v[4],v[8],v[12],m[sigma[r][0]],m[sigma[r][1]]);
    mix(v[1],v[5],v[9],v[13],m[sigma[r][2]],m[sigma[r][3]]);
    mix(v[2],v[6],v[10],v[14],m[sigma[r][4]],m[sigma[r][5]]);
    mix(v[3],v[7],v[11],v[15],m[sigma[r][6]],m[sigma[r][7]]);
    mix(v[0],v[5],v[10],v[15],m[sigma[r][8]],m[sigma[r][9]]);
    mix(v[1],v[6],v[11],v[12],m[sigma[r][10]],m[sigma[r][11]]);
    mix(v[2],v[7],v[8],v[13],m[sigma[r][12]],m[sigma[r][13]]);
    mix(v[3],v[4],v[9],v[14],m[sigma[r][14]],m[sigma[r][15]]);
  }
  for (int i = 0; i < 8; ++i) h[i] ^= v[i] ^ v[i + 8];
  return h[0];
}

inline std::string hex64(std::uint64_t value) {
  static const char* digits = "0123456789abcdef";
  std::string result(16, '0');
  for (int byte = 0; byte < 8; ++byte) {
    unsigned char x = static_cast<unsigned char>(value >> (8 * byte));
    result[2 * byte] = digits[x >> 4];
    result[2 * byte + 1] = digits[x & 15];
  }
  return result;
}

}  // namespace csmhash

#endif
