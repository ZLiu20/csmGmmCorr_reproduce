supporting_code_dir <- function() {
  if (!requireNamespace("here", quietly = TRUE)) {
    stop("Package 'here' is required to locate repository files.", call. = FALSE)
  }
  here::here("SupportingCode")
}

source_supporting_code <- function(envir = parent.frame()) {
  root <- supporting_code_dir()
  modules <- c(
    "sim_data.R",
    "incongruity.R",
    "sim_tasks.R",
    "run_sim_task.R",
    "summarize.R",
    "realdata.R",
    "glgc_prepare.R",
    "plot_style.R",
    "floor_study.R"
  )

  missing <- modules[!file.exists(file.path(root, modules))]
  if (length(missing)) {
    stop("Missing supporting modules: ", paste(missing, collapse = ", "), call. = FALSE)
  }

  for (module in modules) {
    sys.source(file.path(root, module), envir = envir)
  }

  comparator_files <- sort(list.files(
    file.path(root, "comparators"),
    pattern = "[.]R$",
    full.names = TRUE
  ))
  for (module in comparator_files) {
    sys.source(module, envir = envir)
  }

  invisible(c(modules, comparator_files))
}

load_kernels <- function() {
  root <- supporting_code_dir()
  library_path <- file.path(root, "src", paste0("reprokernels", .Platform$dynlib.ext))
  if (!file.exists(library_path)) {
    stop("Native kernels are unavailable; run Rscript setup.R first.", call. = FALSE)
  }
  if (!is.loaded("rd_majorant")) {
    dyn.load(library_path)
  }
  invisible(normalizePath(library_path, mustWork = TRUE))
}

source_supporting_code(environment())
