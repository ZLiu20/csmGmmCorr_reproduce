FLOOR_DESIGN <- list(
  K = 4L,
  probs = c(0.93, 0.05, 0.012, 0.005, 0.003),
  mu = c(2.5, 3, 2.5, 3),
  rho = 0.3,
  N = 20000L,
  J = 20000L,
  t = 1L,
  q = 0.1
)

floor_configs <- function(K) {
  grid <- expand.grid(rep(list(c(-1L, 0L, 1L)), K), KEEP.OUT.ATTRS = FALSE)
  H <- as.matrix(grid)
  storage.mode(H) <- "integer"
  list(H = H, support = rowSums(H != 0L))
}

floor_simulate <- function(n, probs, mu, Sigma) {
  K <- length(mu)
  support <- sample.int(K + 1L, n, replace = TRUE, prob = probs) - 1L
  H <- matrix(0L, nrow = n, ncol = K)
  for (i in which(support > 0L)) {
    active <- sample.int(K, support[i])
    H[i, active] <- sample(c(-1L, 1L), support[i], replace = TRUE)
  }
  noise <- matrix(stats::rnorm(n * K), nrow = n) %*% chol(Sigma)
  list(Z = sweep(H, 2L, mu, `*`) + noise, H = H)
}

.floor_config_weights <- function(omega, support, K) {
  denominator <- choose(K, support) * 2^support
  omega[support + 1L] / denominator
}

floor_logdens <- function(Z, config, omega, mu, Sigma) {
  Z <- as.matrix(Z)
  H <- config$H
  K <- ncol(Z)
  weights <- .floor_config_weights(omega, config$support, K)
  chol_sigma <- chol(Sigma)
  constant <- -sum(log(diag(chol_sigma))) - K * log(2 * pi) / 2
  out <- matrix(NA_real_, nrow = nrow(Z), ncol = nrow(H))
  for (j in seq_len(nrow(H))) {
    residual <- sweep(Z, 2L, H[j, ] * mu, `-`)
    standardized <- backsolve(chol_sigma, t(residual), transpose = TRUE)
    out[, j] <- log(weights[j]) + constant - colSums(standardized^2) / 2
  }
  out
}

.row_softmax <- function(log_value) {
  maximum <- apply(log_value, 1L, max)
  shifted <- exp(log_value - maximum)
  shifted / rowSums(shifted)
}

floor_weights <- function(counts, lower) {
  counts <- as.numeric(counts)
  lower <- as.numeric(lower)
  if (lower < 0 || lower * length(counts) >= 1) stop("Invalid lower weight bound.", call. = FALSE)
  if (!sum(counts)) return(rep(1 / length(counts), length(counts)))
  objective <- function(lambda) sum(pmax(lower, counts / lambda)) - 1
  upper <- max(counts) / lower + sum(counts)
  lambda <- stats::uniroot(objective, c(.Machine$double.eps, upper), tol = 1e-12)$root
  pmax(lower, counts / lambda)
}

.floor_update_mu <- function(Z, H, responsibility, Sigma, lower) {
  K <- ncol(Z)
  precision <- solve(Sigma)
  lhs <- matrix(0, K, K)
  rhs <- numeric(K)
  weighted_sum <- crossprod(responsibility, Z)
  mass <- colSums(responsibility)
  for (j in seq_len(nrow(H))) {
    selector <- diag(H[j, ], K)
    lhs <- lhs + mass[j] * selector %*% precision %*% selector
    rhs <- rhs + selector %*% precision %*% weighted_sum[j, ]
  }
  candidate <- tryCatch(solve(lhs, rhs), error = function(error) rep(lower, K))
  pmax(lower, as.numeric(candidate))
}

.floor_update_sigma <- function(Z, H, responsibility, mu) {
  K <- ncol(Z)
  scatter <- matrix(0, K, K)
  for (j in seq_len(nrow(H))) {
    residual <- sweep(Z, 2L, H[j, ] * mu, `-`)
    scatter <- scatter + crossprod(residual, residual * responsibility[, j])
  }
  covariance <- scatter / nrow(Z)
  scale <- sqrt(diag(covariance))
  correlation <- covariance / tcrossprod(scale)
  .positive_definite_correlation(correlation, floor = 1e-6)
}

floor_fit <- function(Z, a_omega, max_iter = 2000L, tol = 1e-9, a_mu = 0.5) {
  Z <- as.matrix(Z)
  K <- ncol(Z)
  config <- floor_configs(K)
  initial <- c(0.8, 0.1, 0.05, 0.03, 0.02)
  omega <- floor_weights(rep_len(initial, K + 1L) * nrow(Z), a_omega)
  mu <- rep(2, K)
  Sigma <- diag(K)
  previous <- -Inf

  for (iteration in seq_len(max_iter)) {
    log_joint <- floor_logdens(Z, config, omega, mu, Sigma)
    row_max <- apply(log_joint, 1L, max)
    loglik <- sum(row_max + log(rowSums(exp(log_joint - row_max))))
    responsibility <- .row_softmax(log_joint)
    support_mass <- vapply(0:K, function(s) sum(responsibility[, config$support == s, drop = FALSE]), numeric(1))
    omega <- floor_weights(support_mass, a_omega)
    mu <- .floor_update_mu(Z, config$H, responsibility, Sigma, a_mu)
    Sigma <- .floor_update_sigma(Z, config$H, responsibility, mu)
    if (is.finite(previous) && abs(loglik - previous) <= tol * (1 + abs(previous))) break
    previous <- loglik
  }
  list(omega = omega, mu = mu, Sigma = Sigma, loglik = loglik, iterations = iteration)
}

floor_lfdr <- function(Z, omega, mu, Sigma, target, t = 1L) {
  config <- floor_configs(ncol(Z))
  probability <- .row_softmax(floor_logdens(Z, config, omega, mu, Sigma))
  null <- !truth_alt(config$H, target, t)
  rowSums(probability[, null, drop = FALSE])
}

csm_truth <- function(H, target, t) truth_alt(H, target, t)

floor_stepup <- function(lfdr, q) {
  order_index <- order(lfdr)
  eligible <- which(cumsum(lfdr[order_index]) / seq_along(order_index) <= q)
  rejected <- rep(FALSE, length(lfdr))
  if (length(eligible)) rejected[order_index[seq_len(max(eligible))]] <- TRUE
  rejected
}

floor_study_rep <- function(rep, floors = c(1 / 64, 1e-4)) {
  design <- FLOOR_DESIGN
  Sigma <- matrix(design$rho, design$K, design$K)
  diag(Sigma) <- 1
  set.seed(20261007L + as.integer(rep))
  train <- floor_simulate(design$N, design$probs, design$mu, Sigma)
  test <- floor_simulate(design$J, design$probs, design$mu, Sigma)
  fits <- lapply(floors, function(bound) floor_fit(train$Z, bound))
  names(fits) <- paste0("floor_", format(floors, scientific = TRUE))
  output <- list()
  for (fit_name in names(fits)) {
    fit <- fits[[fit_name]]
    for (target in c("pleiotropy", "replication", "mediation")) {
      lfdr <- floor_lfdr(test$Z, fit$omega, fit$mu, fit$Sigma, target, design$t)
      rejected <- floor_stepup(lfdr, design$q)
      alternative <- csm_truth(test$H, target, design$t)
      output[[length(output) + 1L]] <- data.frame(
        rep = rep, fit = fit_name, target = target,
        R = sum(rejected), FDP = if (any(rejected)) mean(!alternative[rejected]) else 0,
        power = if (any(alternative)) mean(rejected[alternative]) else NA_real_,
        omega2to4 = sum(fit$omega[3:5]), iterations = fit$iterations,
        stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, output)
}
