suppressPackageStartupMessages(library(data.table))
source(file.path("SupportingCode", "load_all.R"))
d <- design_means(read_sim("Fig2", "main"))[K == 4L]
fwrite(d, file.path("SuppTab2", "SuppTab2.csv"))
rows <- d[, .(FDP = mean(FDP), power = mean(power), incongruity = mean(incon_dec)), by = .(target, t, method)]
lines <- c("\\begin{table}[!htbp]", "\\centering", "\\caption{Main simulation summary for $K=4$.}",
           "\\begin{tabular}{lllrrr}", "\\toprule", "Target & $t$ & Method & FDP & Power & Incongruity\\\\", "\\midrule")
for (i in seq_len(nrow(rows))) lines <- c(lines, sprintf("%s & %d & %s & %s & %s & %.1f\\\\",
  TARGET_NAME[[rows$target[i]]], rows$t[i], tex_escape(rows$method[i]), f3(rows$FDP[i]), f3(rows$power[i]), rows$incongruity[i]))
write_tex(c(lines, "\\bottomrule", "\\end{tabular}", "\\end{table}"), file.path("SuppTab2", "SuppTab2.tex"))
