# Simulation entry point for main_ours_med_pen_L0A10.
here::i_am("SuppTab3/main_ours_med_pen_L0A10_sim.R")
source(here::here("SupportingCode", "load_all.R"))
args <- commandArgs(trailingOnly = TRUE)
if (!length(args)) stop("An LSF task index is required")
run_sim_task("main_ours_med_pen_L0A10", as.integer(args[[1L]]))
