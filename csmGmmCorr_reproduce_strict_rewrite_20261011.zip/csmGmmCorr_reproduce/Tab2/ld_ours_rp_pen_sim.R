# Simulation entry point for ld_ours_rp_pen.
here::i_am("Tab2/ld_ours_rp_pen_sim.R")
source(here::here("SupportingCode", "load_all.R"))
args <- commandArgs(trailingOnly = TRUE)
if (!length(args)) stop("An LSF task index is required")
run_sim_task("ld_ours_rp_pen", as.integer(args[[1L]]))
